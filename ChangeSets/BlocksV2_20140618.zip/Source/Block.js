var Block = function () {
	this.identity = null;
	this.x = 0;
	this.y = 0;
	this.z = 0;

	this.homeX = undefined;
	this.homeY = undefined;
	this.homeZ = undefined;

	this.width = 0;
	this.height = 0;

	this.scaleX = 1;
	this.scaleY = 1;

	this.rotation = 0;

	this.visible = true;

	this.parent = null;
	this.children = new Array();

	this.showDebugDisplay = false;

	this.isMarkedForDestruction = false;
};

Block.prototype.globalX = function() {
	if (this.parent == null) {
		return 0;
	}
	else {
		return this.parent.globalX()+this.x;
	}
}

Block.prototype.globalY = function() {
	if (this.parent == null) {
		return 0;
	}
	else {
		return this.parent.globalY()+this.y;
	}
}

Block.prototype.globalZ = function() {
	if (this.parent == null) {
		return 0;
	}
	else {
		return this.parent.globalZ()+this.z;
	}
}

Block.prototype.globalScaleX = function() {
	if (this.parent == null) {
		return 0;
	}
	else {
		return this.parent.globalScaleX()+this.scaleX;
	}
}

Block.prototype.globalScaleY = function() {
	if (this.parent == null) {
		return 0;
	}
	else {
		return this.parent.globalScaleY()+this.scaleY;
	}
}

Block.prototype.adoptChild = function(childBlock) {
	if (childBlock.parent != null) {
		childBlock.parent.orphanChild(childBlock);
	}
	this.children.push(childBlock);
	childBlock.parent = this;

	if (childBlock.identity == null) {
		childBlock.identity = "Block" + CANVASMANAGER.getIdentityNumber();
		LOG.write("Child " + childBlock.identity + " adopted by " + this.identity, LOG.VERBOSE);
	}
}

Block.prototype.orphanChild = function(childBlock) {
	var orphanIndex = this.children.indexOf(childBlock);

	if (orphanIndex >= 0) {
		this.children.splice(orphanIndex,1);
	}

}

Block.prototype.toggleDebugDisplay = function(propagateToChildren) {
	this.showDebugDisplay = !this.showDebugDisplay;
	if (propagateToChildren != undefined && propagateToChildren) {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].showDebugDisplay = this.showDebugDisplay;
		}
	}
}

Block.prototype.draw = function(dest) {
	if (this.visible) {
		var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
		var zratio = 1;
		if ((this.z + zscale) != 0) {
			zratio = 1 / ((this.z + zscale) / zscale);
		} 

		drawx = Math.round(-this.width / 2 + zratio*this.x);
		drawy = Math.round(-this.height / 2 + zratio*this.y);

		dest.save();
		dest.translate(drawx + this.width/2 - 1,drawy+this.height/2 - 1);
		dest.scale(zratio*this.scaleX,zratio*this.scaleY);
		dest.rotate(this.rotation*Math.PI/180);

		this.children.sort(function(a,b) { return b.z - a.z });
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].draw(dest);
		}
		
		dest.restore();
	}
};

Block.prototype.undraw = function(dest) {
	if (this.visible) {
		var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
		var zratio = 1
		if ((this.z + zscale) != 0) {
			zratio = 1 / ((this.z + zscale) / zscale);
		} 

		drawx = Math.round(-this.width / 2 + zratio*this.x);
		drawy = Math.round(-this.height / 2 + zratio*this.y);

		dest.save();
		dest.translate(drawx + this.width/2 - 1,drawy+this.height/2 - 1);
		dest.scale(zratio*this.scaleX,zratio*this.scaleY);
		dest.rotate(this.rotation*Math.PI/180);

		//dest.clearRect(-this.width/2, -this.height/2, this.width + 2/(zratio*this.scaleX), this.height + 2/(zratio*this.scaleY));

		for (var i = 0; i < this.children.length; i++) {
			this.children[i].undraw(dest);
		}

		dest.restore();
	}
};

Block.prototype.destroy = function() {
	if (this.isMarkedForDestruction) {
		this.identity = undefined;
		this.x = undefined;
		this.y = undefined;
		this.z = undefined;

		this.homeX = undefined;
		this.homeY = undefined;
		this.homeZ = undefined;

		this.width = undefined;
		this.height = undefined;

		this.scaleX = undefined;
		this.scaleY = undefined;

		this.rotation = undefined;

		this.visible = undefined;

		for (var i = 0; i < this.children.length; i++) {
			this.children[i].destroy();
		}
		this.children.splice(0,this.children.length);
		this.children = undefined;

		this.showDebugDisplay = undefined;

		this.parent.orphanChild(this);

		this.parent = undefined;
	}
	else {
		this.isMarkedForDestruction = true;
	}
}