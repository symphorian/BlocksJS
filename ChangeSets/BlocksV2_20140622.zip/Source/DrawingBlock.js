// Public Constructor function
// Input parameter(s):  
// Returns: DrawingBlock object 
// Description: utilizes the native canvas drawing functions to draw...whatever you want
// User is responsible for undrawing what they have drawn
// Example: var myDB = new DrawingBlock()
var DrawingBlock = function(width,height) {
	PARAMS.initializeValidation();
	width = PARAMS.validateParam(PARAMS.INTEGER, width);
	height = PARAMS.validateParam(PARAMS.INTEGER, height);

	LOG.write("DrawingBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);

	this.width = width;
	this.height = height;

	this.drawingCommands = new Array();
	this.undrawingCommands = new Array();
}

DrawingBlock.prototype = new ActorBlock();

// Private function
// Input parameters: none
// Returns: the modified memory object
// Description: overrides ActorBlock.recordMemory
DrawingBlock.prototype.recordMemory = function() {
	var memory = ActorBlock.prototype.recordMemory.call(this);

	// note to self: can we use extend here?
	if (memory.drawingCommands == undefined) {
		memory.drawingCommands = new Array();
	}
	else {
		memory.drawingCommands.splice(0,memory.drawingCommands.length);
	}
	for (var i = 0; i < this.drawingCommands.length; i++) {
		if (memory.drawingCommands[i] == undefined) {
			memory.drawingCommands[i] = new Object();
		}
		memory.drawingCommands[i].command = this.drawingCommands[i].command;

		if (this.drawingCommands[i].parameters != undefined) {
			if (memory.drawingCommands[i].parameters == undefined) {
				memory.drawingCommands[i].parameters = new Array();
			}
			else {
				memory.drawingCommands[i].parameters.splice(0,memory.drawingCommands[i].parameters.length);
			}
			for (var j = 0; j < this.drawingCommands[i].parameters.length; j++) {
				memory.drawingCommands[i].parameters[j] = this.drawingCommands[i].parameters[j];
			}
		}
		
	}
	
	if (memory.undrawingCommands == undefined) {
		memory.undrawingCommands = new Array();
	}
	else {
		memory.undrawingCommands.splice(0,memory.undrawingCommands.length);
	}
	for (var i = 0; i < this.undrawingCommands.length; i++) {
		if (memory.undrawingCommands[i] == undefined) {
			memory.undrawingCommands[i] = new Object();
		}
		memory.undrawingCommands[i].command = this.undrawingCommands[i].command;

		if (this.undrawingCommands[i].parameters != undefined) {
			if (memory.undrawingCommands[i].parameters == undefined) {
				memory.undrawingCommands[i].parameters = new Array();
			}
			else {
				memory.undrawingCommands[i].parameters.splice(0,memory.undrawingCommands[i].parameters.length);
			}
			for (var j = 0; j < this.undrawingCommands[i].parameters.length; j++) {
				memory.undrawingCommands[i].parameters[j] = this.undrawingCommands[i].parameters[j];
			}
		}
		
	}

	return memory;
}

// Private function
// Input parameters: a memory object
// Returns: nothing
// Description: overrides ActorBlock.changeMemoryIntoReality
DrawingBlock.prototype.changeMemoryIntoReality = function(memory) {
	PARAMS.initializeValidation();
	memory = PARAMS.validateParam(PARAMS.MEMORY, memory);

	ActorBlock.prototype.changeMemoryIntoReality.call(this,memory);
	this.drawingCommands = memory.drawingCommands;
	this.undrawingCommands = memory.undrawingCommands;
}

// Private function
// Input parameters: boolean, whether or not changes in the parent class' properties are checked
// Returns: boolean, whether or not the current object state has changed from the last memory
// Description: overrides ActorBlock.hasChangedFromLatestMemory
DrawingBlock.prototype.hasChangedFromLatestMemory = function(excludeParentProperties) {
	PARAMS.initializeValidation();
	excludeParentProperties = PARAMS.validateParam(PARAMS.BOOLEAN, excludeParentProperties);

	var memory = this.getLatestMemory();
	var hasDifferentDrawingCommands = false;
	var hasDifferentUndrawingCommands = false;

	if (memory != null) {
		if (memory.drawingCommands != this.drawingCommands) {
			hasDifferentDrawingCommands = true;
		}
		for (var dc in memory.drawingCommands) {
			if (this.drawingCommands[dc] == undefined) {
				hasDifferentDrawingCommands = true;
				break;
			}
			else if (this.drawingCommands[dc].command != memory.drawingCommands[dc].command) {
				hasDifferentDrawingCommands = true;
				break;
			}
			else if (this.drawingCommands[dc].parameters != null && memory.drawingCommands[dc].parameters != null && 
					 	this.drawingCommands[dc].parameters.length != memory.drawingCommands[dc].parameters.length) {
				hasDifferentDrawingCommands = true;
				break;
			}
			else if (this.drawingCommands[dc].parameters != null && memory.drawingCommands[dc].parameters != null) {
				for (var i = 0; i < this.drawingCommands[dc].parameters.length; i++) {
					if (this.drawingCommands[dc].parameters[i] != memory.drawingCommands[dc].parameters[i]) {
						hasDifferentDrawingCommands = true;
						break;
					}
				}
			}
		}

		if (memory.undrawingCommands != this.undrawingCommands) {
			hasDifferentUndrawingCommands = true;
		}
		for (var uc in memory.undrawingCommands) {
			if (this.undrawingCommands[uc] == undefined) {
				hasDifferentUndrawingCommands = true;
				break;
			}
			else if (this.undrawingCommands[uc].command != memory.undrawingCommands[uc].command) {
				hasDifferentUndrawingCommands = true;
				break;
			}
			else if (this.undrawingCommands[uc].parameters != null && memory.undrawingCommands[uc].parameters != null && 
					 	this.undrawingCommands[uc].parameters.length != memory.undrawingCommands[uc].parameters.length) {
				hasDifferentUndrawingCommands = true;
				break;
			}
			else if (this.undrawingCommands[uc].parameters != null && memory.undrawingCommands[uc].parameters != null) {
				for (var i = 0; i < this.undrawingCommands[uc].parameters.length; i++) {
					if (this.undrawingCommands[uc].parameters[i] != memory.undrawingCommands[uc].parameters[i]) {
						hasDifferentUndrawingCommands = true;
						break;
					}
				}
			}
		}
	}
	else {
		hasDifferentDrawingCommands = true;
		hasDifferentUndrawingCommands = true;
	}

	if (memory == null) {
		return true;
	}
	else if (excludeParentProperties) {
		return hasDifferentDrawingCommands || hasDifferentUndrawingCommands;
	}
	else {
		return ActorBlock.prototype.hasChangedFromLatestMemory.call(this) || hasDifferentDrawingCommands || hasDifferentUndrawingCommands;
	}
}

DrawingBlock.prototype.addDrawingCommand = function(command, parameters) {
	PARAMS.initializeValidation();
	command = PARAMS.validateParam(PARAMS.STRING,command);
	parameters = PARAMS.validateParam(PARAMS.ARRAY,parameters);

	if (command.length > 0) {
		var drawingCommand = new Object();
		drawingCommand.command = command;
		drawingCommand.parameters = parameters;

		this.drawingCommands.push(drawingCommand);
	}
}

DrawingBlock.prototype.addUndrawingCommand = function(command, parameters) {
	PARAMS.initializeValidation();
	command = PARAMS.validateParam(PARAMS.STRING,command);
	parameters = PARAMS.validateParam(PARAMS.ARRAY,parameters);

	if (command.length > 0) {
		var undrawingCommand = new Object();
		undrawingCommand.command = command;
		undrawingCommand.parameters = parameters;

		this.undrawingCommands.push(undrawingCommand);
	}
}

DrawingBlock.prototype.addDrawingCommands = function() {
	PARAMS.initializeValidation();
	PARAMS.validateArguments([PARAMS.REST, PARAMS.STRING, PARAMS.ARRAYOFOBJECT],
							 arguments);

	for (var i = 0; i < arguments.length; i += 2) {
		var command = arguments[i];
		var parameters = arguments[i+1];

		if (command.length > 0) {
			var drawingCommand = new Object();
			drawingCommand.command = command;
			drawingCommand.parameters = parameters;

			this.drawingCommands.push(drawingCommand);
		}
	}
}

DrawingBlock.prototype.setDrawingCommands = function(drawingCommands) {
	PARAMS.initializeValidation();
	drawingCommands = PARAMS.validateParam(PARAMS.ARRAYOFOBJECT,drawingCommands);

	this.clearDrawingCommands();
	for (var i = 0; i < drawingCommands.length; i ++) {
		this.drawingCommands.push(drawingCommands[i]);
	}
}

DrawingBlock.prototype.getDrawingCommands = function() {
	var drawingCommands = new Array();

	for (var i = 0; i < this.drawingCommands.length; i++) {
		if (drawingCommands[i] == undefined) {
			drawingCommands[i] = new Object();
		}
		drawingCommands[i].command = this.drawingCommands[i].command;

		if (this.drawingCommands[i].parameters != undefined) {
			if (drawingCommands[i].parameters == undefined) {
				drawingCommands[i].parameters = new Array();
			}
			for (var j = 0; j < this.drawingCommands[i].parameters.length; j++) {
				drawingCommands[i].parameters[j] = this.drawingCommands[i].parameters[j];
			}
		}
	}

	return drawingCommands;
}

DrawingBlock.prototype.clearDrawingCommands = function() {
	this.drawingCommands.splice(0,this.drawingCommands.length);
}

DrawingBlock.prototype.clearUndrawingCommands = function() {
	this.undrawingCommands.splice(0,this.undrawingCommands.length);
}

// Private function
// Input parameters: canvas context where the undrawing should occur
// Returns: nothing
// Description: overrides Block.undraw,
// used to perform the undraw operations specified by the user
DrawingBlock.prototype.undraw = function(dest) {
	PARAMS.initializeValidation();
	dest = PARAMS.validateParam(PARAMS.CANVAS2DCONTEXT, dest);

	var drawx = 0;
	var drawy = 0;
	
	try {
		if (this.visible) {
			var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
			var zratio = 1;
			if ((this.z + zscale) != 0) {
				zratio = 1 / ((this.z + zscale) / zscale);
			} 

			drawx = Math.round(-this.width / 2 + zratio*this.x);
			drawy = Math.round(-this.height / 2 + zratio*this.y);

			dest.save();
			dest.translate(drawx+this.width/2,drawy+this.height/2);
			dest.scale(zratio*this.scaleX,zratio*this.scaleY);
			dest.rotate(this.rotation*Math.PI/180);
			
			dest.clearRect(-this.width/2-1,-this.height/2-1,this.width+2,this.height+2);
			parseCanvasCommands(dest,this.undrawingCommands);

			for (var i = 0; i < this.children.length; i++) {
				this.children[i].undraw(dest);
			}

			dest.restore();
		}
	}
	catch (err) {
		LOG.write("error in TextBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
		LOG.writeBlock(this, LOG.ERROR);
		LOG.writeObject(err, LOG.ERROR);
		debugger;
	}
}

// Private function
// Input parameters: canvas context where updates may occur
// Returns: nothing
// Description: overrides ActorBlock.update,
// handles text and font updates
DrawingBlock.prototype.update = function() {
	ActorBlock.prototype.update.call(this);
}

// Private function
// Input parameters: canvas context where the drawing should occur
// Returns: nothing
// Description: overrides Block.draw,
// used to perform the draw operations specified by the user
DrawingBlock.prototype.draw = function(dest) {
	PARAMS.initializeValidation();
	dest = PARAMS.validateParam(PARAMS.CANVAS2DCONTEXT, dest);
	
	var drawx = 0;
	var drawy = 0;
	try {
		if (this.visible) {
			var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
			var zratio = 1;
			if ((this.z + zscale) != 0) {
				zratio = 1 / ((this.z + zscale) / zscale);
			} 

			drawx = Math.round(-this.width / 2 + zratio*this.x);
			drawy = Math.round(-this.height / 2 + zratio*this.y);

			dest.save();
			dest.translate(drawx+this.width/2,drawy+this.height/2);
			dest.scale(zratio*this.scaleX,zratio*this.scaleY);
			dest.rotate(this.rotation*Math.PI/180);
			dest.translate(-this.width/2,-this.height/2);

			// switch(this.maskMode) {
			// 	case "window":
			// 		dest.globalCompositeOperation = "destination-in";
			// 	break;

			// 	case "wall":
			// 		dest.globalCompositeOperation = "destination-out";
			// 	break;
			// }
			

			// if (this.parent.shattered && this.homeX != undefined && this.homeY != undefined) {
			// 	var currentFrame = this.parent.getCurrentFrame();
			// 	if (currentFrame != null) {
			// 		dest.drawImage(currentFrame,this.homeX+this.parent.width/2-this.width/2,this.homeY+this.parent.height/2-this.height/2,this.width,this.height,
			// 									-this.width/2,-this.height/2,this.width,this.height);
			// 	}
			// }
			// else if (!this.shattered) {
			// 	var currentFrame = this.getCurrentFrame();
			// 	if (currentFrame != null) {	
			// 		dest.drawImage(currentFrame,-this.width/2,-this.height/2);
			// 	}
			// }

			parseCanvasCommands(dest,this.drawingCommands);

			dest.translate(this.width/2,this.height/2);

			if (this.showDebugDisplay) {
				dest.save();
				dest.strokeStyle = "Green";
				dest.lineWidth = 1;
				dest.beginPath();
				dest.moveTo(0,0);
				dest.lineTo(0,-this.height/2);
				dest.stroke();
				dest.closePath();
				dest.fillStyle = "Red";
				dest.fillRect(-4,-4,8,8);
				dest.beginPath();
				dest.strokeStyle = "Blue";
				dest.lineWidth = 1;
				dest.rect(-this.width/2,-this.height/2,this.width,this.height);
				dest.stroke();
				dest.restore();
			}

			this.children.sort(function(a,b) { return b.z - a.z });
			for (var i = 0; i < this.children.length; i++) {
				this.children[i].draw(dest);
			}
			
			dest.restore();
		}
	}
	catch (err) {
		LOG.write("error in TextBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
		LOG.writeBlock(this, LOG.ERROR);
		LOG.writeObject(err, LOG.ERROR);
		debugger;
	}
}