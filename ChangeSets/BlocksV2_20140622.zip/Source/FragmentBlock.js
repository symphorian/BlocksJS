// Public Constructor function
// Input parameter(s):  Block capable of being shattered, integer, integer, integer, integer, integer
// Returns: FragmentBlock object instantiated with the specified height and width at the specified home location
// in order to display the image from the provided source Block that implements the Shatterable interface
// Example: var myFB = new FragmentBlock(this,10,10, -100, -50, 0);
var FragmentBlock = function(sourceBlock, width, height, homeX, homeY, homeZ) {
	PARAMS.initializeValidation();
	PARAMS.validateArguments([PARAMS.BLOCK, PARAMS.INTEGER, PARAMS.INTEGER, PARAMS.INTEGER, PARAMS.INTEGER, PARAMS.INTEGER], arguments);

	LOG.write("FragmentBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);

	this.sourceBlock = sourceBlock;

	this.width = width;
	this.height = height;

	this.x = homeX;
	this.y = homeY;
	this.z = homeZ;

	this.homeX = homeX;
	this.homeY = homeY;
	this.homeZ = homeZ;

	// this.maskMode = "none";

	this.shattered = false;
}

FragmentBlock.prototype = new ActorBlock();

// Private function
// Input parameters: none
// Returns: the modified memory object
// Description: overrides ActorBlock.recordMemory
FragmentBlock.prototype.recordMemory = function() {
	var memory = ActorBlock.prototype.recordMemory.call(this);

	memory.homeX = this.homeX;
	memory.homeY = this.homeY;
	memory.homeZ = this.homeZ;

	return memory;
}

// Private function
// Input parameters: a memory object
// Returns: nothing
// Description: overrides ActorBlock.changeMemoryIntoReality
FragmentBlock.prototype.changeMemoryIntoReality = function(memory) {
	PARAMS.initializeValidation();
	memory = PARAMS.validateParam(PARAMS.MEMORY, memory);

	ActorBlock.prototype.changeMemoryIntoReality.call(this,memory);
	this.homeX = memory.homeX;
	this.homeY = memory.homeY;
	this.homeZ = memory.homeZ;
}

// Private function
// Input parameters: none
// Returns: boolean, whether or not the current object state has changed from the last memory
// Description: overrides ActorBlock.hasChangedFromLatestMemory
FragmentBlock.prototype.hasChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return ActorBlock.prototype.hasChangedFromLatestMemory.call(this) || !(memory.homeX == this.homeX && memory.homeY == this.homeY && memory.homeZ == this.homeZ);
	}
}

// Public function
// Input parameters: the new size for the shattered blocks (integer)
// Returns: nothing
// Description: shatters the current block's frames into an an array of new child blocks, 
// each with a small part of the original image/animation
FragmentBlock.prototype.shatter = function(newBlockSize) {
	PARAMS.initializeValidation(); 
	newBlockSize = PARAMS.validateParam(PARAMS.INTEGER, newBlockSize);

	if (newBlockSize > this.width || newBlockSize > this.height) {
		LOG.write("Tried to shatter FragmentBlock into blocks of size: " + newBlockSize + ", but FragmentBlock only has a width of " + this.width + ".", LOG.WARN);
		return;
	}
	
	if (!this.shattered) {
		var blockClusterPositions = new Array();
		var maxWidth = this.width;
		var maxHeight = this.height;

		for (var i = 0; i < maxWidth; i += newBlockSize) {
			for (var j = 0; j < maxHeight; j += newBlockSize) {
				blockClusterPositions.push({"x":Math.floor(i - maxWidth/2 + newBlockSize/2), "y":Math.floor(j - maxHeight/2 + newBlockSize/2)});
			}
		}

		for (var i = 0; i < blockClusterPositions.length; i++) {
			var newBlock = new FragmentBlock(this.sourceBlock, newBlockSize, newBlockSize, blockClusterPositions[i].x, blockClusterPositions[i].y, 0);
			newBlock.setMemoryCapacity(this.memoryCapacity);
			
			this.adoptChild(newBlock);
		}

		this.shattered = true;
	}
}

// Public function
// Input parameters: none
// Returns: nothing
// Description: removes child FragmentBlocks resulting from shatter
FragmentBlock.prototype.unshatter = function() {
	for (var i = 0; i < this.children.length; i++) {
		if (this.children[i] instanceof FragmentBlock) {
			this.children[i].destroy();
			this.children.splice(i,1);
			i--;
		}
	}
	this.shattered = false;
}

FragmentBlock.prototype.getCurrentFrameFromSourceBlock = function() {
	if (this.sourceBlock) {
		if (this.sourceBlock.getCurrentFrameFromSourceBlock) {
			return this.sourceBlock.getCurrentFrameFromSourceBlock();
		}
		else {
			return this.sourceBlock.getCurrentFrame();
		}
	}
	else {
		return null;
	}
}

// Private function
// Input parameters: canvas context where the undrawing should occur
// Returns: nothing
// Description: overrides Block.undraw,
// used to clear the rectangle occupied by the object's image after applying necessary transformations
FragmentBlock.prototype.undraw = function(dest) {
	PARAMS.initializeValidation();
	dest = PARAMS.validateParam(PARAMS.CANVAS2DCONTEXT, dest);

	if (this.sourceBlock) {
		var drawx = 0;
		var drawy = 0;
		
		try {
			if (this.visible) {
				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
				var zratio = 1;
				if ((this.z + zscale) > 0) {
					zratio = 1 / ((this.z + zscale) / zscale);
				} 

				drawx = Math.round(-this.width / 2 + zratio*this.x);
				drawy = Math.round(-this.height / 2 + zratio*this.y);

				dest.save();
				dest.translate(drawx + this.width/2,drawy+this.height/2);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);

				if (!this.shattered) {
					dest.clearRect(-this.width/2 - 1,-this.height/2 - 1,this.width + 2,this.height + 2);
				}

				for (var i = 0; i < this.children.length; i++) {
					this.children[i].undraw(dest);
				}

				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in FragmentBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
}

// Private function
// Input parameters: none
// Returns: nothing
// Description: overrides ActorBlock.update,
// handles frame updates and filter/mask application
FragmentBlock.prototype.update = function() {
	ActorBlock.prototype.update.call(this);
}

// Private function
// Input parameters: canvas context where the drawing should occur
// Returns: nothing
// Description: overrides Block.draw,
// used to draw the object's current frame image after applying necessary transformations
FragmentBlock.prototype.draw = function(dest) {
	PARAMS.initializeValidation();
	dest = PARAMS.validateParam(PARAMS.CANVAS2DCONTEXT, dest);

	if (this.sourceBlock) {
		var drawx = 0;
		var drawy = 0;
		
		try {
			if (this.visible) {
				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
				var zratio = 1;
				if ((this.z + zscale) != 0) {
					zratio = 1 / ((this.z + zscale) / zscale);
				} 

				drawx = Math.round(-this.width / 2 + zratio*this.x);
				drawy = Math.round(-this.height / 2 + zratio*this.y);

				dest.save();
				dest.translate(drawx + this.width/2,drawy+this.height/2);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);

				// switch(this.maskMode) {
				// 	case "window":
				// 		dest.globalCompositeOperation = "destination-in";
				// 	break;

				// 	case "wall":
				// 		dest.globalCompositeOperation = "destination-out";
				// 	break;
				// }
				

				if (!this.shattered) {
					var currentFrame = this.getCurrentFrameFromSourceBlock();

					if (currentFrame != null) {
						dest.drawImage(currentFrame,
										(this.getWidthInSourceBlock()-this.width/2)/this.getHorizontalVideoScalingInSourceBlock(),
										(this.getHeightInSourceBlock()-this.height/2)/this.getVerticalVideoScalingInSourceBlock(),
										this.width/this.getHorizontalVideoScalingInSourceBlock(),
										this.height/this.getVerticalVideoScalingInSourceBlock(),
										-this.width/2,
										-this.height/2,
										this.width,
										this.height);
					}

				}
				 

				if (this.showDebugDisplay) {
					dest.save();
					dest.strokeStyle = "Green";
					dest.lineWidth = 1;
					dest.beginPath();
					dest.moveTo(0,0);
					dest.lineTo(0,-this.height/2);
					dest.stroke();
					dest.fillStyle = "Red";
					dest.fillRect(-4,-4,8,8);
					dest.beginPath();
					dest.strokeStyle = "Blue";
					dest.lineWidth = 1;
					dest.rect(-this.width/2,-this.height/2,this.width,this.height);
					dest.stroke();
					dest.restore();
				}

				this.children.sort(function(a,b) { return b.z - a.z });
				for (var i = 0; i < this.children.length; i++) {
					this.children[i].draw(dest);
				}
				
				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in FragmentBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
}

FragmentBlock.prototype.getWidthInSourceBlock = function() {
	if (this.sourceBlock) {
		if (this.sourceBlock.getWidthInSourceBlock) {
			return this.sourceBlock.getWidthInSourceBlock() + this.homeX;
		}
		else {
			return this.sourceBlock.width/2 + this.homeX;
		}
	}
	else {
		return this.width/2;
	}
}

FragmentBlock.prototype.getHeightInSourceBlock = function() {
	if (this.sourceBlock) {
		if (this.sourceBlock.getHeightInSourceBlock) {
			return this.sourceBlock.getHeightInSourceBlock() + this.homeY;
		}
		else {
			return this.sourceBlock.height/2 + this.homeY;
		}
		
	}
	else {
		return this.height/2;
	}
}

FragmentBlock.prototype.getHorizontalVideoScalingInSourceBlock = function() {
	if (this.sourceBlock) {
		if (this.sourceBlock.getHorizontalVideoScalingInSourceBlock) {
			return this.sourceBlock.getHorizontalVideoScalingInSourceBlock();
		}
		else if (this.sourceBlock.getHorizontalVideoScaling) {
			return this.sourceBlock.getHorizontalVideoScaling();
		}
		else {
			return 1;
		}
	}
	else {
		return 1;
	}
}

FragmentBlock.prototype.getVerticalVideoScalingInSourceBlock = function() {
	if (this.sourceBlock) {
		if (this.sourceBlock.getVerticalVideoScalingInSourceBlock) {
			return this.sourceBlock.getVerticalVideoScalingInSourceBlock();
		}
		else if (this.sourceBlock.getVerticalVideoScaling) {
			return this.sourceBlock.getVerticalVideoScaling();
		}
		else {
			return 1;
		}
	}
	else {
		return 1;
	}
}


FragmentBlock.prototype.destroy = function() {
	if (this.isMarkedForDestruction) {

		// this.maskMode = undefined;

		this.sourceBlock = undefined;

		this.shattered = undefined;
	}

	ActorBlock.prototype.destroy.call(this);
}