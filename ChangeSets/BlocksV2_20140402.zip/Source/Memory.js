var Memory = function() {
	
}