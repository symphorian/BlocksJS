// Public Constructor function
// Input parameter(s):  image alias string, image alias string, ...
// Returns: VideoBlock object instantiated with the images matching the supplied input parameters
// Example: var myVB = new VideoBlock("img1", "img2", "img3", "img4");
var VideoBlock = function(videoAlias, width, height) {
	PARAMS.initializeValidation();
	videoAlias = PARAMS.validateParam(PARAMS.STRING, videoAlias);
	width = PARAMS.validateParam(PARAMS.UNSIGNEDINTEGER, width);
	height = PARAMS.validateParam(PARAMS.UNSIGNEDINTEGER, height);

	LOG.write("VideoBlock constructor called", LOG.VERBOSE);
	PlayerBlock.call(this);

	this.video = CANVASMANAGER.getVideoAsset(videoAlias);
	this.width = width;
	this.height = height;

	this.currentTime = this.video.getCurrentTime();
}

VideoBlock.prototype = new PlayerBlock();

// Private function
// Input parameters: none
// Returns: the modified memory object
// Description: overrides ActorBlock.sleep
VideoBlock.prototype.sleep = function() {
	ActorBlock.prototype.sleep.call(this);

	this.video.pause();
}

// Private function
// Input parameters: none
// Returns: the modified memory object
// Description: overrides ActorBlock.wake
VideoBlock.prototype.wake = function() {
	ActorBlock.prototype.wake.call(this);

	this.video.unpause();
}

// Private function
// Input parameters: none
// Returns: the modified memory object
// Description: overrides ActorBlock.recordMemory
VideoBlock.prototype.recordMemory = function() {
	var memory = ActorBlock.prototype.recordMemory.call(this);

	memory.currentTime = this.video.getCurrentTime();

	return memory;
}

// Private function
// Input parameters: a memory object
// Returns: nothing
// Description: overrides ActorBlock.changeMemoryIntoReality
VideoBlock.prototype.changeMemoryIntoReality = function(memory) {
	PARAMS.initializeValidation();
	memory = PARAMS.validateParam(PARAMS.MEMORY, memory);

	ActorBlock.prototype.changeMemoryIntoReality.call(this,memory);
	this.currentTime = memory.currentTime;
	this.video.setCurrentTime(this.currentTime);
}

// Private function
// Input parameters: none
// Returns: boolean, whether or not the current object state has changed from the last memory
// Description: overrides ActorBlock.hasChangedFromLatestMemory
VideoBlock.prototype.hasChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return ActorBlock.prototype.hasChangedFromLatestMemory.call(this) || !(memory.currentTime == this.currentTime);
	}
}

// Public function
// Input parameter(s): none
// Returns: nothing
// Description: plays the loaded video from the beginning
VideoBlock.prototype.play = function() {
	if (this.awake) {
		this.video.play();
	}
}

// Public function
// Input parameter(s): none
// Returns: nothing
// Description: pauses progression of the loaded video
VideoBlock.prototype.pause = function() {
	if (this.awake) {
		this.video.pause();
	}
}

// Public function
// Input parameter(s): none
// Returns: nothing
// Description: resumes progression of the loaded video
VideoBlock.prototype.unpause = function() {
	if (this.awake) {
		this.video.unpause();
	}
}

// Public function
// Input parameter(s): none
// Returns: nothing
// Description: toggles the play/pause state of the loaded video
VideoBlock.prototype.playPause = function() {
	if (this.awake) {
		this.video.playPause();
	}
}

// Public function
// Input parameter(s): none
// Returns: nothing
// Description: halts progression of the loaded video and returns to the beginning of the video
VideoBlock.prototype.stop = function() {
	if (this.awake) {
		this.video.play();
		this.video.pause();
	}
}

// Public function
// Input parameter(s): none
// Returns: integer between 0 and 100
// Description: returns the current volume the loaded video will play at
VideoBlock.prototype.getVolume = function() {
	return this.video.getVolume();
}

// Public function
// Input parameter(s): integer between 0 and 100
// Returns: nothing
// Description: sets the current volume the loaded video will play at
VideoBlock.prototype.setVolume = function(percent) {
	PARAMS.initializeValidation();
	percent = PARAMS.validateParam(PARAMS.NUMBER, percent);

	if (this.awake) {
		this.video.setVolume(percent);
	}
}

// Public function
// Input parameter(s): boolean
// Returns: nothing
// Description: sets whether or not the loaded video should loop
VideoBlock.prototype.setLooping = function(shouldLoop) {
	PARAMS.initializeValidation();
	shouldLoop = PARAMS.validateParam(PARAMS.BOOLEAN, shouldLoop);

	if (this.awake) {
		this.video.setLooping(shouldLoop);
	}
}

// Private function
// Input parameters: canvas context where the undrawing should occur
// Returns: nothing
// Description: overrides Block.undraw,
// used to clear the rectangle occupied by the object's image after applying necessary transformations
VideoBlock.prototype.undraw = function(dest) {
	PARAMS.initializeValidation();
	dest = PARAMS.validateParam(PARAMS.CANVAS2DCONTEXT, dest);

	if (this.video != undefined) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
				var zratio = 1
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 

				drawx = Math.round(-this.width / 2 + zratio*this.x);
				drawy = Math.round(-this.height / 2 + zratio*this.y);

				dest.save();
				dest.translate(drawx + this.width/2,drawy+this.height/2);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);

				dest.clearRect(-this.width/2 - 1, -this.height/2 - 1, this.width + 2, this.height + 2);

				for (var i = 0; i < this.children.length; i++) {
					this.children[i].undraw(dest);
				}

				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in VideoBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
}

// Private function
// Input parameters: none
// Returns: nothing
// Description: overrides ActorBlock.update,
// handles frame updates and filter/mask application
VideoBlock.prototype.update = function() {
	ActorBlock.prototype.update.call(this);

	// if (this.isPlaying) {
	// 	this.currentFrameIndex++;

	// 	if ((this.frameAliases.length > 0 && this.currentFrameIndex >= this.frameAliases.length) ||
	// 		 (this.frameData.length > 0 && this.currentFrameIndex >= this.frameData.length)) {
	// 		 this.currentFrameIndex = 0;
	// 	}
	// }

	// var currentFrame = this.getCurrentFrame();

	// if (currentFrame != null) {
	// 	this.width = currentFrame.width;
	// 	this.height = currentFrame.height;
	// }

	// this.applyFiltersAndMasks();
}

// Private function
// Input parameters: canvas context where the drawing should occur
// Returns: nothing
// Description: overrides Block.draw,
// used to draw the object's current frame image after applying necessary transformations
VideoBlock.prototype.draw = function(dest) {
	PARAMS.initializeValidation();
	dest = PARAMS.validateParam(PARAMS.CANVAS2DCONTEXT, dest);
	
	if (this.video != undefined) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
				var zratio = 1;
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 

				drawx = Math.round(-this.width / 2 + zratio*this.x);
				drawy = Math.round(-this.height / 2 + zratio*this.y);

				dest.save();
				dest.translate(drawx + this.width/2,drawy+this.height/2);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);

				// switch(this.maskMode) {
				// 	case "window":
				// 		dest.globalCompositeOperation = "destination-in";
				// 	break;

				// 	case "wall":
				// 		dest.globalCompositeOperation = "destination-out";
				// 	break;
				// }
				
				// var currentFrame = this.getCurrentFrame();
				// if (currentFrame != null) {	
				// 	dest.drawImage(currentFrame,-this.width/2,-this.height/2);
				// }

				dest.drawImage(this.video.video,-this.width/2,-this.height/2,this.width,this.height);

				if (this.showDebugDisplay) {
					dest.save();
					dest.strokeStyle = "Green";
					dest.lineWidth = 1;
					dest.beginPath();
					dest.moveTo(0,0);
					dest.lineTo(0,-this.height/2);
					dest.stroke();
					dest.fillStyle = "Red";
					dest.fillRect(-4,-4,8,8);
					dest.beginPath();
					dest.strokeStyle = "Blue";
					dest.lineWidth = 1;
					dest.rect(-this.width/2,-this.height/2,this.width,this.height);
					dest.stroke();
					dest.restore();
				}

				this.children.sort(function(a,b) { return b.z - a.z });
				for (var i = 0; i < this.children.length; i++) {
					this.children[i].draw(dest);
				}
				
				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in MovieBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
}