// Public Constructor function
// Input parameter(s):  none
// Returns: ActorBlock object
// Description: Inherited class for any block object that uses behaviors, constraints, reactions, and memories
var ActorBlock = function () {
	LOG.write("ActorBlock constructor called", LOG.VERBOSE);
	var that = this;
	Block.call(this);

	this.xvel = 0;
	this.yvel = 0;
	this.zvel = 0;

	this.xacc = 0;
	this.yacc = 0;
	this.zacc = 0;

	this.rotationVel = 0;
	this.rotationAcc = 0;

	this.behaviors = new Array();
	this.behaviorVars = new Array();
	//this.behaviorLock

	this.constraints = new Array();
	this.constraintVars = new Array();

	this.isMouseOver = false;
	this.mouseOverReactions = new Array();
	this.mouseOutReactions = new Array();
	this.mouseClickReactions = new Array();
	this.mouseDownReactions = new Array();
	this.mouseUpReactions = new Array();

	this.keyPressReactions = new Object();
	this.keyDownReactions = new Object();
	this.keyUpReactions = new Object();

	this.isSubscribedToMouseMove = false;
	this.isSubscribedToMouseClick = false;
	this.isSubscribedToMouseDown = false;
	this.isSubscribedToMouseUp = false;

	this.keysPressedSubscribedTo = new Array();
	this.keysDownSubscribedTo = new Array();
	this.keysUpSubscribedTo = new Array();

	this.awake = true;
	this.memoryCapacity = 1;
	this.oldestMemoryIndex = 0;
	this.currentMemoryIndex = 0;

	this.memories = new Array(new Memory());
}

ActorBlock.prototype = new Block();

// Public function
// Input parameters: none
// Returns: nothing
// Description: puts the object to sleep (stops behavior updates)
ActorBlock.prototype.sleep = function() {
	this.awake = false;
	this.currentMemoryIndex = this.oldestMemoryIndex - 1;

	if (this.currentMemoryIndex < 0) {
		this.currentMemoryIndex += this.memoryCapacity;
	}
}

// Public function
// Input parameters: none
// Returns: nothing
// Description: wakes up the object (restarts behavior updates)
ActorBlock.prototype.wake = function() {
	this.awake = true;

	var currentMemoryIndex = this.currentMemoryIndex + 1;
	if (currentMemoryIndex >= this.memoryCapacity) {
		currentMemoryIndex -= this.memoryCapacity;
	}
	while (currentMemoryIndex != this.oldestMemoryIndex) {
		this.forgetMemory(this.memories[currentMemoryIndex]);

		currentMemoryIndex++;
		if (currentMemoryIndex >= this.memoryCapacity) {
			currentMemoryIndex -= this.memoryCapacity;
		}
	}

	this.oldestMemoryIndex = this.currentMemoryIndex + 1;
	if (this.oldestMemoryIndex >= this.memoryCapacity) {
		this.oldestMemoryIndex -= this.memoryCapacity;
	}
}


// Private function
// Input parameters: memory to forget
// Returns: nothing
// Description: replaces all memory properties with null values
ActorBlock.prototype.forgetMemory = function(memory) {
	PARAMS.initializeValidation();
	memory = PARAMS.validateParam(PARAMS.MEMORY, memory);

	memory.x = null;
	memory.y = null;
	memory.z = null;
	memory.xvel = null;
	memory.yvel = null;
	memory.zvel = null;
	memory.xacc = null;
	memory.yacc = null;
	memory.zacc = null;
	memory.rotation = null;
	memory.rotationVel = null;
	memory.rotationAcc = null;
}

// Private function
// Input parameters: memory to check
// Returns: boolean
// Description: checks if the memory object has been cleared of its properties
// (if x is null, then all the properties must be null as well)
ActorBlock.prototype.isMemoryForgotten = function(memory) {
	PARAMS.initializeValidation();
	memory = PARAMS.validateParam(PARAMS.MEMORY, memory);

	return memory.x == null;
}

// TODO(?): currentMemoryIndex is not what you think, fix how you use it

// Public function
// Input parameters: integer (the number of memories to retain)
// Returns: nothing
// Description: clears all current memories and sets the maximum memory capacity
ActorBlock.prototype.setMemoryCapacity = function(memCap) {
	PARAMS.initializeValidation();
	memCap = PARAMS.validateParam(PARAMS.INTEGER, memCap);

	if (memCap > 0) {
		//this.memories.splice(0,this.memories.length);
		this.memoryCapacity = memCap;
		this.oldestMemoryIndex = 0;

		for (var i = 0; i < this.memoryCapacity; i++) {
			if (this.memories[i] == null) {
				this.memories[i] = new Memory();
			}
			else {
				this.forgetMemory(this.memories[i]);
			}
		}
	}
}


// Private function
// Input parameters: none
// Returns: the modified memory object
// Description: Records this object's rememberable properties into the next available space in memory
ActorBlock.prototype.recordMemory = function() {
	var memory = this.memories[this.oldestMemoryIndex];

	memory.x = this.x;
	memory.y = this.y;
	memory.z = this.z;
	memory.xvel = this.xvel;
	memory.yvel = this.yvel;
	memory.zvel = this.zvel;
	memory.xacc = this.xacc;
	memory.yacc = this.yacc;
	memory.zacc = this.zacc;
	memory.rotation = this.rotation;
	memory.rotationVel = this.rotationVel;
	memory.rotationAcc = this.rotationAcc;

	return memory;
}

// Private function
// Input parameters: none
// Returns: nothing
// Description: records the current state of the block object into a memory, advances the oldest memory index
ActorBlock.prototype.updateMemory = function() {
	this.recordMemory();
	this.oldestMemoryIndex++;
	if (this.oldestMemoryIndex >= this.memoryCapacity) {
		this.oldestMemoryIndex = 0;
	}
}

// Private function
// Input parameters: the memory with the properties to imprint onto this object
// Returns: nothing
// Description: Alters this object's properties to match the properties in the input memory
ActorBlock.prototype.changeMemoryIntoReality = function(memory) {
	PARAMS.initializeValidation();
	memory = PARAMS.validateParam(PARAMS.MEMORY, memory);

	this.x = memory.x;
	this.y = memory.y;
	this.z = memory.z;
	this.xvel = memory.xvel;
	this.yvel = memory.yvel;
	this.zvel = memory.zvel;
	this.xacc = memory.xacc;
	this.yacc = memory.yacc;
	this.zacc = memory.zacc;
	this.rotation = memory.rotation;
	this.rotationVel = memory.rotationVel;
	this.rotationAcc = memory.rotationAcc;
}

// Public/Private function (?)
// Input parameters: memory index to set as current
// Returns: nothing
// Description: Sets the current memory index as the input parameter
ActorBlock.prototype.setCurrentMemoryIndex = function(index) {
	PARAMS.initializeValidation();
	index = PARAMS.validateParam(PARAMS.INTEGER, index);

	this.currentMemoryIndex = index;
}

// Private function
// Input parameters: integer for the nth memory from the most recent memory
// Returns: nth memory from the most recent memory (by decreasing memory index from current memory index)
ActorBlock.prototype.getNthLatestMemory = function(n) {
	PARAMS.initializeValidation();
	n = PARAMS.validateParam(PARAMS.INTEGER, n);

	if (n >= 0 && n < this.memoryCapacity) {
		var nthNewestMemoryIndex = this.oldestMemoryIndex - 1 - n;
		if (nthNewestMemoryIndex < 0) {
			nthNewestMemoryIndex += this.memoryCapacity;
		}

		var memory = this.memories[nthNewestMemoryIndex];

		while(this.isMemoryForgotten(memory) && nthNewestMemoryIndex != this.oldestMemoryIndex) {
			nthNewestMemoryIndex--;
			if (nthNewestMemoryIndex < 0) {
				nthNewestMemoryIndex += this.memoryCapacity;
			}
			memory = this.memories[nthNewestMemoryIndex];
		}

		if (this.isMemoryForgotten(memory)) {
			return null;
		}
		else {
			return memory;
		}
	}
	else {
		return null;
	}
}

// Private function
// Input parameters: none
// Returns: the most recent memory
ActorBlock.prototype.getLatestMemory = function() {
	return this.getNthLatestMemory(0);
}

// Private function
// Input parameters: integer for the nth memory from the oldest memory
// Returns: nth memory from the oldest memory (by increasing memory index from current memory index)
ActorBlock.prototype.getNthEarliestMemory = function(n) {
	PARAMS.initializeValidation();
	n = PARAMS.validateParam(PARAMS.INTEGER, n);

	if (n >= 0 && n < this.memoryCapacity) {
		var nthOldestMemoryIndex = this.oldestMemoryIndex + n;
		if (nthOldestMemoryIndex >= this.memoryCapacity) {
			nthOldestMemoryIndex -= this.memoryCapacity;
		}

		var memory = this.memories[nthOldestMemoryIndex];
		
		while(this.isMemoryForgotten(memory) && nthOldestMemoryIndex != this.oldestMemoryIndex - 1) {
			nthOldestMemoryIndex++;
			if (nthOldestMemoryIndex >= this.memoryCapacity) {
				nthOldestMemoryIndex -= this.memoryCapacity;
			}
			memory = this.memories[nthOldestMemoryIndex];
		}

		if (this.isMemoryForgotten(memory)) {
			return null;
		}
		else {
			return memory;
		}
	}
	else {
		return null;
	}
}

// Private function
// Input parameters: none
// Returns: the oldest memory 
ActorBlock.prototype.getEarliestMemory = function() {
	return this.getNthEarliestMemory(0);
}

// Public function
// Input parameters: none
// Returns: one memory later than the current one being remembered
// Description: used to iterate forward through an object's chain of memories while object is not awake
ActorBlock.prototype.recallLaterMemory = function() {
	if (this.currentMemoryIndex != this.oldestMemoryIndex - 1) {

		var laterMemoryIndex = this.currentMemoryIndex;
		laterMemoryIndex++;
		
		if (laterMemoryIndex >= this.memoryCapacity) {
			laterMemoryIndex -= this.memoryCapacity;
		}

		
		var memory = this.memories[laterMemoryIndex];

		while(this.isMemoryForgotten(memory) && laterMemoryIndex != this.oldestMemoryIndex - 1) {
			laterMemoryIndex++;
			if (laterMemoryIndex >= this.memoryCapacity) {
				laterMemoryIndex -= this.memoryCapacity;
			}
			memory = this.memories[laterMemoryIndex];
		}

		if (this.isMemoryForgotten(memory)) {
			return null;
		}
		else {
			this.currentMemoryIndex = laterMemoryIndex;
			return memory;
		}
	}
	else {
		return null;
	}
}


// Public function
// Input parameters: none
// Returns: one memory earlier than the current one being remembered
// Description: used to iterate backward through an object's chain of memories
ActorBlock.prototype.recallEarlierMemory = function() {
	if (this.currentMemoryIndex != this.oldestMemoryIndex) {

		var earlierMemoryIndex = this.currentMemoryIndex;
		earlierMemoryIndex--;

		if (earlierMemoryIndex < 0) {
			earlierMemoryIndex += this.memoryCapacity;
		}

		
		var memory = this.memories[earlierMemoryIndex];

		while(this.isMemoryForgotten(memory) && earlierMemoryIndex != this.oldestMemoryIndex) {
			earlierMemoryIndex--;
			if (earlierMemoryIndex < 0) {
				earlierMemoryIndex += this.memoryCapacity;
			}
			
			memory = this.memories[earlierMemoryIndex];
		}

		if (this.isMemoryForgotten(memory)) {
			return null;
		}
		else {
			this.currentMemoryIndex = earlierMemoryIndex;
			return memory;
		}
	}
	else {
		return null;
	}
}

// Private function
// Input parameters: none
// Returns: Boolean, whether or not the current object state has changed from the last memory
ActorBlock.prototype.hasChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return !(memory.x == this.x && memory.y == this.y && memory.z == this.z && memory.xvel == this.xvel && memory.yvel == this.yvel && memory.zvel == this.zvel && memory.xacc == this.xacc && memory.yacc == this.yacc && memory.zacc == this.zacc && memory.rotation == this.rotation && memory.rotationVel == this.rotationVel && memory.rotationAcc == this.rotationAcc);
	}
}

// Private function
// Input parameters: none
// Returns: Boolean, whether or not the current object position has changed from the last memory
ActorBlock.prototype.hasPositionChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return !(memory.x == this.x && memory.y == this.y && memory.z == this.z && memory.rotation == this.rotation);
	}
}

// Private function
// Input parameters: none
// Returns: nothing
// Description: if the object is awake, this function records an object's current state as a memory, 
// runs its behaviors, and applies its constraints
ActorBlock.prototype.update = function() {
	if (this.awake) {
		this.updateMemory();

		for (var i = 0; i < this.behaviors.length; i++) {
			this.behaviors[i](this);
		}

		for (var i = 0; i < this.constraints.length; i++) {
			this.constraints[i](this);
		}

		for (var i = 0; i < this.children.length; i++) {
			this.children[i].update();
		}
	}
	else {
		if (this.currentMemoryIndex >= 0 && this.currentMemoryIndex < this.memoryCapacity) {
			var currentMemory = this.memories[this.currentMemoryIndex];
			if (currentMemory != null) {
				this.changeMemoryIntoReality(currentMemory);
			}
		}
	}

	this.x = Math.round(this.x);
	this.y = Math.round(this.y);
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: add a behavior to an object, with optional variables associated with it
// Example: myblockCluster.addBehavior(animate, {framesPerImage:2, frameRate:30}, false);
ActorBlock.prototype.addBehavior = function (behavior, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	behavior = PARAMS.validateParam(PARAMS.FUNCTION, behavior);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	if (propagateToChildren == true) {
		for (var i = 0; i < this.children.length; i++) {
			if (this.children[i].children.length == 0) {
				this.children[i].addBehavior(behavior, extend(vars, {}));
			}
			else {
				this.children[i].addBehavior(behavior, extend(vars, {}), true);
			}
		}
	}
	else {
		if (this.behaviorLock == undefined && this.behaviors.indexOf(behavior) == -1) {
			this.behaviors.push(behavior);
			if (vars != undefined) {
				this.behaviorVars[getFunctionName(behavior)] = vars;
			}
		}
	}
}

// Public function
// Input parameters: a function
// Returns: nothing
// Description: removes a behavior from an object, leaving the behavior variables untouched
// Example: myblockCluster.removeBehavior(animate);
ActorBlock.prototype.removeBehavior = function (behavior) {
	PARAMS.initializeValidation();
	behavior = PARAMS.validateParam(PARAMS.FUNCTION, behavior);

	var index = this.behaviors.indexOf(behavior);
	if (index > -1) {
		this.behaviors.splice(index,1);
		//this.behaviorVars[getFunctionName(behavior)] = undefined;
	}
	//if (this.behaviorLock == behavior) {
	//	this.behaviorLock = undefined;
	//}

	for (var i = 0; i < this.children.length; i++) {
		this.children[i].removeBehavior(behavior);
	}
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: add a constraint to an object, with optional variables associated with it
// Example: myblockCluster.addConstraint(checkForCrossedBoundaries, {leftMostX:200, topMostY:200}, false);
ActorBlock.prototype.addConstraint = function (constraint, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	constraint = PARAMS.validateParam(PARAMS.FUNCTION, constraint);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	if (propagateToChildren == true) {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].addConstraint(constraint, extend(vars,{}));
		}
	}
	else {
		if (this.constraints.indexOf(constraint) == -1) {
			this.constraints.push(constraint);
			if (vars != undefined) {
				this.constraintVars[getFunctionName(constraint)] = vars;
			}
		}
	}
}

// Public function
// Input parameters: a function
// Returns: nothing
// Description: removes a constraint from an object, leaving the constraint variables untouched
// Example: myblockCluster.removeConstraint(checkForCrossedBoundaries);
ActorBlock.prototype.removeConstraint = function (constraint) {
	PARAMS.initializeValidation();
	constraint = PARAMS.validateParam(PARAMS.FUNCTION, constraint);

	var index = this.constraints.indexOf(constraint);
	if (index > -1) {
		this.constraints.splice(index,1);
		//this.constraintVars[getFunctionName(constraint)] = undefined;
	}

	for (var i = 0; i < this.children.length; i++) {
		this.children[i].removeConstraint(constraint);
	}
}

// Private function
// Input parameters: a matrix object
// Returns: nothing
// Description: adds the Translation, Scale, and Rotation of an object to the matrix passed into the function,
// accounts for the transformations of the parents before applying transformations
ActorBlock.prototype.addTransformationsToMatrix = function(matrix) {
	PARAMS.initializeValidation();
	matrix = PARAMS.validateParam(PARAMS.MATRIX, matrix);

	if (this.parent != null) {
		this.parent.addTransformationsToMatrix(matrix);
	}
	var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
	var zratio = 1;
	if (this.z > 0) {
		zratio = 1 / (this.z / zscale);
	} 

	var drawx = Math.round(-this.width / 2 + zratio*this.x);
	var drawy = Math.round(-this.height / 2 + zratio*this.y);

	matrix.addTranslation(drawx + this.width/2,drawy+this.height/2);
	matrix.addScale(zratio*this.scaleX, zratio*this.scaleY);
	matrix.addRotation(this.rotation);
}


// Private function
// Input parameters: a matrix object
// Returns: nothing
// Description: adds the inverse Translation, Scale, and Rotation of an object to the matrix passed into the function,
// accounts for the inverse transformations of the parents before applying transformations.
// Typically used to convert global coordinates into local coordinates of an object
ActorBlock.prototype.addInverseTransformationsToMatrix = function(matrix) {
	PARAMS.initializeValidation();
	matrix = PARAMS.validateParam(PARAMS.MATRIX, matrix);

	if (this.parent != null) {
		this.parent.addInverseTransformationsToMatrix(matrix);
	}
	var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
	var zratio = 1;
	if (this.z > 0) {
		zratio = 1 / (this.z / zscale);
	} 

	var drawx = Math.round(-this.width / 2 + zratio*this.x);
	var drawy = Math.round(-this.height / 2 + zratio*this.y);

	matrix.addTranslation(-(drawx + this.width/2),-(drawy+this.height/2));
	matrix.addScale(1/(zratio*this.scaleX), 1/(zratio*this.scaleY));
	matrix.addRotation(-this.rotation);
}

// Private function
// Input parameters: a matrix object
// Returns: nothing
// Description: adds the reverse Translation, Scale, and Rotation of an object to the matrix passed into the function,
// accounts for the reverse transformations of the parents before applying transformations
ActorBlock.prototype.addReverseTransformationsToMatrix = function(matrix) {
	PARAMS.initializeValidation();
	matrix = PARAMS.validateParam(PARAMS.MATRIX, matrix);

	if (this.parent != null) {
		this.parent.addReverseTransformationsToMatrix(matrix);
	}
	var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
	var zratio = 1;
	if (this.z > 0) {
		zratio = 1 / (this.z / zscale);
	} 

	var drawx = Math.round(-this.width / 2 + zratio*this.x);
	var drawy = Math.round(-this.height / 2 + zratio*this.y);

	matrix.addRotation(-this.rotation);
	matrix.addScale(1/(zratio*this.scaleX), 1/(zratio*this.scaleY));
	matrix.addTranslation(-(drawx + this.width/2),-(drawy+this.height/2));
}

// Private function
// Input parameters: mouseEvent object
// Returns: Boolean indicating if the mouse event is within the boundaries of an object
// Description: converts coordinates of the mouse event (global coordinates) into the coordinates of an object (local coordinates),
// and then checks if the mouse event coordinates are within the bounds of an object
ActorBlock.prototype.isMouseEventWithinBlock = function(mouseEvent) {
	PARAMS.initializeValidation();
	mouseEvent = PARAMS.validateParam(PARAMS.MOUSEEVENT, mouseEvent);

	MATRIX.clearTransformations();

	this.addInverseTransformationsToMatrix(MATRIX);

	var xyResult = MATRIX.applyTransformation(mouseEvent.x,mouseEvent.y);

	LOG.writeObject(xyResult);

	if (xyResult.x > -this.width/2 && xyResult.x < this.width/2 &&
		xyResult.y > -this.height/2 && xyResult.y < this.height/2) {
		return true;
	}
	else {
		return false;
	}
}

// Private function
// Input parameters: mouseEvent object
// Returns: Boolean indicating if the mouseEvent triggered any mouseOver or mouseOut reactions
// Description: checks if the input mouseEvent should trigger any mouseOver or mouseOut reactions
ActorBlock.prototype.reactToMouseMoveEvent = function(mouseEvent) {
	PARAMS.initializeValidation();
	mouseEvent = PARAMS.validateParam(PARAMS.MOUSEEVENT, mouseEvent);

	if (this.isMouseEventWithinBlock(mouseEvent)) {
		if (!this.isMouseOver) {
			this.isMouseOver = true;
			for (var i = 0; i < this.mouseOverReactions.length; i++) {
				this.mouseOverReactions[i](this, mouseEvent);
			}
			return true;
		}
	}
	else {
		if (this.isMouseOver) {
			this.isMouseOver = false;
			for (var i = 0; i < this.mouseOutReactions.length; i++) {
				this.mouseOutReactions[i](this, mouseEvent);
			}
			return true;
		}
	}
	return false
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to MouseMove events, 
// and adds a mouseOver reaction to an object, with optional variables associated with it
ActorBlock.prototype.addMouseOverReaction = function (reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	CANVASMANAGER.mouseMoveEvent.subscribe(this);

	if (this.mouseOverReactions.indexOf(reaction) == -1) {
		this.mouseOverReactions.push(reaction);
	}
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to MouseMove events, 
// and adds a mouseOut reaction to an object, with optional variables associated with it
ActorBlock.prototype.addMouseOutReaction = function (reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	CANVASMANAGER.mouseMoveEvent.subscribe(this);

	if (this.mouseOutReactions.indexOf(reaction) == -1) {
		this.mouseOutReactions.push(reaction);
	}
}

// Private function
// Input parameters: mouseEvent object
// Returns: Boolean indicating if the mouseEvent triggered any mouseClick reactions
// Description: checks if the input mouseEvent should trigger any mouseClick reactions
ActorBlock.prototype.reactToMouseClickEvent = function(mouseEvent) {
	PARAMS.initializeValidation();
	mouseEvent = PARAMS.validateParam(PARAMS.MOUSEEVENT, mouseEvent);

	if (this.isMouseEventWithinBlock(mouseEvent)) {
		for (var i = 0; i < this.mouseClickReactions.length; i++) {
			this.mouseClickReactions[i](this, mouseEvent);
		}
		return true;
	}
	return false;
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to MouseClick events, 
// and adds a mouseClick reaction to an object, with optional variables associated with it
ActorBlock.prototype.addMouseClickReaction = function (reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	CANVASMANAGER.mouseClickEvent.subscribe(this);

	if (this.mouseClickReactions.indexOf(reaction) == -1) {
		this.mouseClickReactions.push(reaction);
	}
}

// Private function
// Input parameters: mouseEvent object
// Returns: Boolean indicating if the mouseEvent triggered any mouseDown reactions
// Description: checks if the input mouseEvent should trigger any mouseDown reactions
ActorBlock.prototype.reactToMouseDownEvent = function(mouseEvent) {
	PARAMS.initializeValidation();
	mouseEvent = PARAMS.validateParam(PARAMS.MOUSEEVENT, mouseEvent);

	if (this.isMouseEventWithinBlock(mouseEvent)) {
		for (var i = 0; i < this.mouseDownReactions.length; i++) {
			this.mouseDownReactions[i](this, mouseEvent);
		}
		return true;
	}
	return false;
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to MouseDown events, 
// and adds a mouseDown reaction to an object, with optional variables associated with it
ActorBlock.prototype.addMouseDownReaction = function (reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	CANVASMANAGER.mouseDownEvent.subscribe(this);

	if (this.mouseDownReactions.indexOf(reaction) == -1) {
		this.mouseDownReactions.push(reaction);
	}
}

// Private function
// Input parameters: mouseEvent object
// Returns: Boolean indicating if the mouseEvent triggered any mouseup reactions
// Description: checks if the input mouseEvent should trigger any mouseUp reactions
ActorBlock.prototype.reactToMouseUpEvent = function(mouseEvent) {
	PARAMS.initializeValidation();
	mouseEvent = PARAMS.validateParam(PARAMS.MOUSEEVENT, mouseEvent);

	if (this.isMouseEventWithinBlock(mouseEvent)) {
		for (var i = 0; i < this.mouseUpReactions.length; i++) {
			this.mouseUpReactions[i](this, mouseEvent);
		}
		return true;
	}
	return false;
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to MouseUp events, 
// and adds a mouseUp reaction to an object, with optional variables associated with it
ActorBlock.prototype.addMouseUpReaction = function (reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	var that = this;
	if (!this.isSubscribedToMouseUp) {
		this.isSubscribedToMouseUp = true;
		CANVASMANAGER.mouseUpEvent.subscribe(function(e) { 
			if (that.width > 0 && that.height > 0) {
				if (that.isMouseEventWithinBlock(e)) {
					for (var i = 0; i < that.mouseUpReactions.length; i++) {
						that.mouseUpReactions[i](that, e);
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseUpReactions.length; i++) {
					that.mouseUpReactions[i](that, e);
				}
			}
		});
	}

	if (this.mouseUpReactions.indexOf(reaction) == -1) {
		this.mouseUpReactions.push(reaction);
	}
}

// Private function
// Input parameters: keyboardEvent object
// Returns: Boolean indicating if the keyboardEvent triggered any keyPress reactions
// Description: checks if the input keyboardEvent should trigger any keyPress reactions
ActorBlock.prototype.reactToKeyPressEvent = function(keyboardEvent,keyName) {
	PARAMS.initializeValidation();
	keyboardEvent = PARAMS.validateParam(PARAMS.KEYBOARDEVENT, keyboardEvent);
	keyName = PARAMS.validateParam(PARAMS.STRING, keyName);

	if (this.keyPressReactions[keyName] != undefined) {
		for (var i = 0; i < this.keyPressReactions[keyName].length; i++) {
			this.keyPressReactions[keyName][i](this, keyboardEvent);
		}
		return true;
	}
	return false;
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to keyPress events, 
// and adds a keyPress reaction for any key to an object, with optional variables associated with it
ActorBlock.prototype.addAnyKeyPressReaction = function(reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	var name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);

	CANVASMANAGER.keyboardEvent.subscribeToKeyPress(this,KEYCODES.ANYKEY);

	if (this.keyPressReactions[name] == undefined) {
		this.keyPressReactions[name] = new Array();
	}
	if (this.keyPressReactions[name].indexOf(reaction) == -1) {
		this.keyPressReactions[name].push(reaction);
	}
}

// Private function
// Input parameters: keyboardEvent object
// Returns: Boolean indicating if the keyboardEvent triggered any keyDown reactions
// Description: checks if the input keyboardEvent should trigger any keyDown reactions
ActorBlock.prototype.reactToKeyDownEvent = function(keyboardEvent,keyName) {
	PARAMS.initializeValidation();
	keyboardEvent = PARAMS.validateParam(PARAMS.KEYBOARDEVENT, keyboardEvent);
	keyName = PARAMS.validateParam(PARAMS.STRING, keyName);

	if (this.keyDownReactions[keyName] != undefined) {
		for (var i = 0; i < this.keyDownReactions[keyName].length; i++) {
			this.keyDownReactions[keyName][i](this, keyboardEvent);
		}
		return true;
	}
	return false;
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to any keyDown events, 
// and adds a keyDown reaction for any key to an object, with optional variables associated with it
ActorBlock.prototype.addAnyKeyDownReaction = function(reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	var name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);

	CANVASMANAGER.keyboardEvent.subscribeToKeyDown(this,KEYCODES.ANYKEY);

	if (this.keyDownReactions[name] == undefined) {
		this.keyDownReactions[name] = new Array();
	}
	if (this.keyDownReactions[name].indexOf(reaction) == -1) {
		this.keyDownReactions[name].push(reaction);
	}
}

// Private function
// Input parameters: keyboardEvent object
// Returns: Boolean indicating if the keyboardEvent triggered any keyUp reactions
// Description: checks if the input keyboardEvent should trigger any keyUp reactions
ActorBlock.prototype.reactToKeyUpEvent = function(keyboardEvent,keyName) {
	PARAMS.initializeValidation();
	keyboardEvent = PARAMS.validateParam(PARAMS.KEYBOARDEVENT, keyboardEvent);
	keyName = PARAMS.validateParam(PARAMS.STRING, keyName);

	if (this.keyUpReactions[keyName] != undefined) {
		for (var i = 0; i < this.keyUpReactions[keyName].length; i++) {
			this.keyUpReactions[keyName][i](this, keyboardEvent);
		}
		return true;
	}
	return false;
}

// Public function
// Input parameters: a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to any keyUp events, 
// and adds a keyUp reaction for any key to an object, with optional variables associated with it
ActorBlock.prototype.addAnyKeyUpReaction = function(reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	var name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	
	CANVASMANAGER.keyboardEvent.subscribeToKeyUp(this,KEYCODES.ANYKEY);

	if (this.keyUpReactions[name] == undefined) {
		this.keyUpReactions[name] = new Array();
	}
	if (this.keyUpReactions[name].indexOf(reaction) == -1) {
		this.keyUpReactions[name].push(reaction);
	}
}

// Public function
// Input parameters: a keycode, a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to keyPress events, 
// and adds a keyPress reaction associated with the input keycode to an object, with optional variables associated with it
ActorBlock.prototype.addKeyPressReaction = function(keyCode, reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	keyCode = PARAMS.validateParam(PARAMS.INTEGER, keyCode);
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	var name = KEYCODES.getStringFromKeyCode(keyCode);

	CANVASMANAGER.keyboardEvent.subscribeToKeyPress(this,keyCode);
		

	if (this.keyPressReactions[name] == undefined) {
		this.keyPressReactions[name] = new Array();
	}
	if (this.keyPressReactions[name].indexOf(reaction) == -1) {
		this.keyPressReactions[name].push(reaction);
	}
}

// Public function
// Input parameters: a keycode, a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to any keyDown events, 
// and adds a keyDown reaction associated with the input keycode to an object, with optional variables associated with it
ActorBlock.prototype.addKeyDownReaction = function(keyCode, reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	keyCode = PARAMS.validateParam(PARAMS.INTEGER, keyCode);
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	var name = KEYCODES.getStringFromKeyCode(keyCode);
	
	CANVASMANAGER.keyboardEvent.subscribeToKeyDown(this,keyCode);

	if (this.keyDownReactions[name] == undefined) {
		this.keyDownReactions[name] = new Array();
	}
	if (this.keyDownReactions[name].indexOf(reaction) == -1) {
		this.keyDownReactions[name].push(reaction);
	}
}

// Public function
// Input parameters: a keycode, a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to any keyUp events, 
// and adds a keyUp reaction associated with the input keycode to an object, with optional variables associated with it
ActorBlock.prototype.addKeyUpReaction = function(keyCode, reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	keyCode = PARAMS.validateParam(PARAMS.INTEGER, keyCode);
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	var name = KEYCODES.getStringFromKeyCode(keyCode);
	
	CANVASMANAGER.keyboardEvent.subscribeToKeyUp(this,keyCode);

	if (this.keyUpReactions[name] == undefined) {
		this.keyUpReactions[name] = new Array();
	}
	if (this.keyUpReactions[name].indexOf(reaction) == -1) {
		this.keyUpReactions[name].push(reaction);
	}
}

// Public function
// Input parameters: an array of keycodes, a function, a variable object, and a boolean
// Returns: nothing
// Description: subscribes an object to any keyDown events, 
// and adds a keyDown reaction associated with the input combination of keycodes to an object, 
// with optional variables associated with it
ActorBlock.prototype.addKeyCombinationReaction = function(keyCodes, reaction, vars, propagateToChildren) {
	PARAMS.initializeValidation();
	keyCode = PARAMS.validateParam(PARAMS.INTEGER, keyCode);
	reaction = PARAMS.validateParam(PARAMS.FUNCTION, reaction);
	vars = PARAMS.validateParam(PARAMS.OBJECT, vars);
	propagateToChildren = PARAMS.validateParam(PARAMS.BOOLEAN, propagateToChildren, false);

	var name = KEYCODES.getStringFromKeyCodes(keyCodes);
	
	CANVASMANAGER.keyboardEvent.subscribeToKeyCombination(this,keyCodes);

	if (this.keyDownReactions[name] == undefined) {
		this.keyDownReactions[name] = new Array();
	}
	if (this.keyDownReactions[name].indexOf(reaction) == -1) {
		this.keyDownReactions[name].push(reaction);
	}
}