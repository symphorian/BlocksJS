var Log = function() {
	this.logThreshold = 0;
	this.displayObjects = false;
	this.displayBlocks = false;

	this.VERBOSE = 0;
	this.INFO = 1;
	this.WARN = 2;
	this.ERROR = 3;
	this.FATAL = 4;
	this.NONE = 999;
}

Log.prototype.setLogThreshold = function(logType) {
	switch(logType) {
		case this.VERBOSE:
		case this.INFO:
		case this.WARN:
		case this.ERROR:
		case this.FATAL:
		case this.NONE:
			this.logThreshold = logType;
			break;

		default:
			this.logThreshold = this.VERBOSE;
			break;
	}
}

Log.prototype.setDisplayObjects = function(allowObjectLogging) {
	this.displayObjects = allowObjectLogging;
}

Log.prototype.setDisplayBlocks = function(allowBlockLogging) {
	this.displayBlocks = allowBlockLogging;
}

Log.prototype.write = function(message, logType) {
	var verifiedType = this.VERBOSE;
	var descriptor = "";
	switch(logType) {
		case this.VERBOSE:
			verifiedType = logType;
			descriptor += "VERBOSE: ";
			break;

		case this.INFO:
			verifiedType = logType;
			descriptor += "INFO: ";
			break; 

		case this.WARN:
			verifiedType = logType;
			descriptor += "WARN: ";
			break;

		case this.ERROR:
			verifiedType = logType;
			descriptor += "ERROR: ";
			break;

		case this.FATAL:
			verifiedType = logType;
			descriptor += "FATAL: ";
			break;

		default:
			break;
	}

	if (verifiedType >= this.logThreshold) {
		console.log(descriptor + message);
	}
}

Log.prototype.writeObject = function(obj, logType) {
	if (this.displayObjects) {
		var verifiedType = this.VERBOSE;
		var descriptor = "";
		switch(logType) {
			case this.VERBOSE:
				verifiedType = logType;
				descriptor += "VERBOSE: ";
				break;

			case this.INFO:
				verifiedType = logType;
				descriptor += "INFO: ";
				break; 

			case this.WARN:
				verifiedType = logType;
				descriptor += "WARN: ";
				break;

			case this.ERROR:
				verifiedType = logType;
				descriptor += "ERROR: ";
				break;

			case this.FATAL:
				verifiedType = logType;
				descriptor += "FATAL: ";
				break;

			default:
				break;
		}

		if (verifiedType >= this.logThreshold) {
			console.log(obj);
		}

		
	}
}

Log.prototype.writeBlock = function(block, logType, identity) {
	if (this.displayBlocks) {
		var verifiedType = this.VERBOSE;
		var descriptor = "";
		switch(logType) {
			case this.VERBOSE:
				verifiedType = logType;
				descriptor += "VERBOSE: ";
				break;

			case this.INFO:
				verifiedType = logType;
				descriptor += "INFO: ";
				break; 

			case this.WARN:
				verifiedType = logType;
				descriptor += "WARN: ";
				break;

			case this.ERROR:
				verifiedType = logType;
				descriptor += "ERROR: ";
				break;

			case this.FATAL:
				verifiedType = logType;
				descriptor += "FATAL: ";
				break;

			default:
				break;
		}

		if (verifiedType >= this.logThreshold) {
			if (identity == undefined) {
				console.log(block);
			}
			else {
				if (block.identity == identity) {
					console.log(block);
				}
			}
		}
	}
}

var LOG = new Log();

var KeyCodes = function() {
	this.A = 65;
	this.B = 66;
	this.C = 67;
	this.D = 68;
	this.E = 69;
	this.F = 70;
	this.G = 71;
	this.H = 72;
	this.I = 73;
	this.J = 74;
	this.K = 75;
	this.L = 76;
	this.M = 77;
	this.N = 78;
	this.O = 79;
	this.P = 80;
	this.Q = 81;
	this.R = 82;
	this.S = 83;
	this.T = 84;
	this.U = 85;
	this.V = 86;
	this.W = 87;
	this.X = 88;
	this.Y = 89;
	this.Z = 90;

	this.uppercaseKeyCodes = [this.A,this.B,this.C,this.D,this.E,this.F,this.G,this.H,this.I,this.J,this.K,this.L,this.M,this.N,this.O,this.P,this.Q,this.R,this.S,this.T,this.U,this.V,this.W,this.X,this.Y,this.Z];

	this.a = 97;
	this.b = 98;
	this.c = 99;
	this.d = 100;
	this.e = 101;
	this.f = 102;
	this.g = 103;
	this.h = 104;
	this.i = 105;
	this.j = 106;
	this.k = 107;
	this.l = 108;
	this.m = 109;
	this.n = 110;
	this.o = 111;
	this.p = 112;
	this.q = 113;
	this.r = 114;
	this.s = 115;
	this.t = 116;
	this.u = 117;
	this.v = 118;
	this.w = 119;
	this.x = 120;
	this.y = 121;
	this.z = 122;

	this.lowercaseKeyCodes = [this.a,this.b,this.c,this.d,this.e,this.f,this.g,this.h,this.i,this.j,this.k,this.l,this.m,this.n,this.o,this.p,this.q,this.r,this.s,this.t,this.u,this.v,this.w,this.x,this.y,this.z];

	this.ZERO = 48;
	this.ONE = 49;
	this.TWO = 50;
	this.THREE = 51;
	this.FOUR = 52;
	this.FIVE = 53;
	this.SIX = 54;
	this.SEVEN = 55;
	this.EIGHT = 56;
	this.NINE = 57;

	this.numericKeyCodes = [this.ZERO,this.ONE,this.TWO,this.THREE,this.FOUR,this.FIVE,this.SIX,this.SEVEN,this.EIGHT,this.NINE];

	this.SPACE = 32;
	this.ENTER = 13;
	//this.TAB = 9;
	//this.ESCAPE = 27;
	this.BACKSPACE = 8;
	this.SHIFT = 16;

	this.specialKeyCodes = [this.SPACE,this.ENTER,this.BACKSPACE,this.SHIFT];

	this.LEFT = 37;
	this.UP = 38;
	this.RIGHT = 39;
	this.DOWN = 40;

	this.arrowKeyCodes = [this.LEFT,this.UP,this.RIGHT,this.DOWN];

	this.ANYKEY = 999;
}

KeyCodes.prototype.getStringFromKeyCode = function(keyCode) {
	for (var name in this) {
		if (this[name] == keyCode) {
			return name;
		}
	}

	return "";
}

KeyCodes.prototype.getStringFromKeyCodes = function(keyCodes) {
	var name = "";
	keyCodes.sort();
	var filteredKeyCodes = new Array();

	for (var i = 0; i < keyCodes.length; i++) {
		if (filteredKeyCodes.indexOf(keyCodes[i]) == -1) {
			filteredKeyCodes.push(keyCodes[i]);
			name += this.getStringFromKeyCode(keyCodes[i]);
		}
	}

	return name;
}

KeyCodes.prototype.isKeyCodeUppercase = function(keycode) {
	for (var i = 0; i < this.uppercaseKeyCodes.length; i++) {
		if (this.uppercaseKeyCodes[i] == keycode) {
			return true;
		}
	}
	return false;
}

KeyCodes.prototype.isKeyCodeLowercase = function(keycode) {
	for (var i = 0; i < this.lowercaseKeyCodes.length; i++) {
		if (this.lowercaseKeyCodes[i] == keycode) {
			return true;
		}
	}
	return false;
}

KeyCodes.prototype.isKeyCodeAlphabetic = function(keycode) {
	return (this.isKeyCodeUppercase(keycode) || this.isKeyCodeLowercase(keycode));
}

KeyCodes.prototype.isKeyCodeNumeric = function(keycode) {
	for (var i = 0; i < this.numericKeyCodes.length; i++) {
		if (this.numericKeyCodes[i] == keycode) {
			return true;
		}
	}
	return false;
}

KeyCodes.prototype.isKeyCodeSpecial = function(keycode) {
	for (var i = 0; i < this.specialKeyCodes.length; i++) {
		if (this.specialKeyCodes[i] == keycode) {
			return true;
		}
	}
	return false;
}

KeyCodes.prototype.isKeyCodeArrow = function(keycode) {
	for (var i = 0; i < this.arrowKeyCodes.length; i++) {
		if (this.arrowKeyCodes[i] == keycode) {
			return true;
		}
	}
	return false;
}

var KEYCODES = new KeyCodes();

var getFunctionName = function(functionObject) {
	var functionString = String(functionObject);
	var firstIndex = functionString.indexOf(' ') + 1;
	var lastIndex = functionString.indexOf('(');

	return functionString.substring(firstIndex, lastIndex);
}

//var trace = function(string) {
//	console.log(string);
//}

var copyArray = function(src, dest) {
	for (var i = 0; i < src.length; i++) {
		dest[i] = src[i];
	}
}

var extend = function(srcObj, destObj, recurseDown) {
	for (var prop in srcObj) {
		destObj[prop] = srcObj[prop];
	}
}

var TextHelper = function() {
	this.span = document.createElement("span");
	this.block = document.createElement("div");
	this.block.style.display = "inline-block";
	this.block.width = "1px";
	this.block.height = "0px";
	//this.block.textContent = "test";
	this.div = document.createElement("div");
	this.div.appendChild(this.span);
	this.div.appendChild(this.block);

}

TextHelper.prototype.measureTextHeight = function(text, font, size) {

	this.span.style.font = size + "px " + font;
	this.span.textContent = text;

  	document.body.appendChild(this.div);

  	var result = {};

  	try {

	    this.block.style.verticalAlign = "baseline";
	    result.ascent = this.block.offsetTop - this.span.offsetTop;

	    this.block.style.verticalAlign = "bottom";
	    result.height = this.block.offsetTop - this.span.offsetTop;

	    result.descent = result.height - result.ascent;

  	} finally {
    	document.body.removeChild(this.div);
  	}

  	return result;

}

var TEXTHELPER = new TextHelper();