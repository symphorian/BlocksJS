var ActorBlock = function () {
	LOG.write("ActorBlock constructor called", LOG.VERBOSE);
	var that = this;
	Block.call(this);

	this.xvel = 0;
	this.yvel = 0;
	this.zvel = 0;

	this.xacc = 0;
	this.yacc = 0;
	this.zacc = 0;

	this.rotationVel = 0;
	this.rotationAcc = 0;

	this.behaviors = new Array();
	this.behaviorVars = new Array();
	//this.behaviorLock

	this.constraints = new Array();
	this.constraintVars = new Array();

	this.isMouseOver = false;
	this.mouseOverReactions = new Array();
	this.mouseOutReactions = new Array();
	this.mouseClickReactions = new Array();
	this.mouseDownReactions = new Array();
	this.mouseUpReactions = new Array();

	this.keyPressReactions = new Object();
	this.keyDownReactions = new Object();
	this.keyUpReactions = new Object();

	this.isSubscribedToMouseMove = false;
	this.isSubscribedToMouseClick = false;
	this.isSubscribedToMouseDown = false;
	this.isSubscribedToMouseUp = false;

	this.keysPressedSubscribedTo = new Array();
	this.keysDownSubscribedTo = new Array();
	this.keysUpSubscribedTo = new Array();

	this.awake = true;
	this.memoryCapacity = 1;
	this.oldestMemoryIndex = 0;
	this.currentMemoryIndex = 0;

	this.memories = new Array({});
}

ActorBlock.prototype = new Block();

ActorBlock.prototype.putAsleep = function() {
	this.awake = false;
	this.currentMemoryIndex = this.oldestMemoryIndex - 1;

	if (this.currentMemoryIndex < 0) {
		this.currentMemoryIndex += this.memoryCapacity;
	}
}

ActorBlock.prototype.wakeUp = function() {
	this.awake = true;

	var currentMemoryIndex = this.currentMemoryIndex + 1;
	if (this.currentMemoryIndex >= this.memoryCapacity) {
		this.currentMemoryIndex -= this.memoryCapacity;
	}
	while (currentMemoryIndex != this.oldestMemoryIndex) {
		this.forgetMemory(this.memories[currentMemoryIndex]);

		currentMemoryIndex++;
		if (currentMemoryIndex >= this.memoryCapacity) {
			currentMemoryIndex -= this.memoryCapacity;
		}
	}

	this.oldestMemoryIndex = this.currentMemoryIndex + 1;
}

ActorBlock.prototype.forgetMemory = function(memory) {
	memory.x = null;
	memory.y = null;
	memory.z = null;
	memory.xvel = null;
	memory.yvel = null;
	memory.zvel = null;
	memory.xacc = null;
	memory.yacc = null;
	memory.zacc = null;
	memory.rotation = null;
	memory.rotationVel = null;
	memory.rotationAcc = null;
}

ActorBlock.prototype.isMemoryForgotten = function(memory) {
	return memory.x == null;
}

// currentMemoryIndex is not what you think, fix how you use it
ActorBlock.prototype.setMemoryCapacity = function(memCap) {
	if (memCap > 0) {
		//this.memories.splice(0,this.memories.length);
		this.memoryCapacity = memCap;
		this.oldestMemoryIndex = 0;

		for (var i = 0; i < this.memoryCapacity; i++) {
			if (this.memories[i] == null) {
				this.memories[i] = {};
			}
			else {
				this.forgetMemory(this.memories[i]);
			}
		}
	}
}

ActorBlock.prototype.recordMemory = function() {
	var memory = this.memories[this.oldestMemoryIndex];

	memory.x = this.x;
	memory.y = this.y;
	memory.z = this.z;
	memory.xvel = this.xvel;
	memory.yvel = this.yvel;
	memory.zvel = this.zvel;
	memory.xacc = this.xacc;
	memory.yacc = this.yacc;
	memory.zacc = this.zacc;
	memory.rotation = this.rotation;
	memory.rotationVel = this.rotationVel;
	memory.rotationAcc = this.rotationAcc;

	return memory;
}

ActorBlock.prototype.updateMemory = function() {
	this.recordMemory();
	this.oldestMemoryIndex++;
	if (this.oldestMemoryIndex >= this.memoryCapacity) {
		this.oldestMemoryIndex = 0;
	}
}

ActorBlock.prototype.changeMemoryIntoReality = function(memory) {
	this.x = memory.x;
	this.y = memory.y;
	this.z = memory.z;
	this.xvel = memory.xvel;
	this.yvel = memory.yvel;
	this.zvel = memory.zvel;
	this.xacc = memory.xacc;
	this.yacc = memory.yacc;
	this.zacc = memory.zacc;
	this.rotation = memory.rotation;
	this.rotationVel = memory.rotationVel;
	this.rotationAcc = memory.rotationAcc;
}

ActorBlock.prototype.setCurrentMemoryIndex = function(index) {
	this.currentMemoryIndex = index;
}

ActorBlock.prototype.getNthLatestMemory = function(n) {
	if (n > 0 && n < this.memoryCapacity) {
		var nthNewestMemoryIndex = this.oldestMemoryIndex - 1 - n;
		if (nthNewestMemoryIndex < 0) {
			nthNewestMemoryIndex += this.memoryCapacity;
		}

		var memory = this.memories[nthNewestMemoryIndex];

		if (this.isMemoryForgotten(memory)) {
			nthNewestMemoryIndex--;
			if (nthNewestMemoryIndex < 0) {
				nthNewestMemoryIndex += this.memoryCapacity;
			}
			while(this.isMemoryForgotten(memory) && nthNewestMemoryIndex != this.oldestMemoryIndex - 1 - n) {
				memory = this.memories[nthNewestMemoryIndex];
				nthNewestMemoryIndex--;
				if (nthNewestMemoryIndex < 0) {
					nthNewestMemoryIndex += this.memoryCapacity;
				}
			}
		}

		if (this.isMemoryForgotten(memory)) {
			return null;
		}
		else {
			return memory;
		}
	}
	else {
		return null;
	}
}

ActorBlock.prototype.getLatestMemory = function() {
	return this.getNthLatestMemory(0);
}

ActorBlock.prototype.getNthEarliestMemory = function(n) {
	if (n > 0 && n < this.memoryCapacity) {
		var nthOldestMemoryIndex = this.oldestMemoryIndex + n;
		if (nthOldestMemoryIndex >= this.memoryCapacity) {
			nthOldestMemoryIndex -= this.memoryCapacity;
		}

		var memory = this.memories[nthOldestMemoryIndex];

		if (this.isMemoryForgotten(memory)) {
			nthOldestMemoryIndex++;
			if (nthOldestMemoryIndex >= this.memoryCapacity) {
				nthOldestMemoryIndex -= this.memoryCapacity;
			}
			while(this.isMemoryForgotten(memory) && nthOldestMemoryIndex != this.oldestMemoryIndex) {
				memory = this.memories[nthOldestMemoryIndex];
				nthOldestMemoryIndex++;
				if (nthOldestMemoryIndex >= this.memoryCapacity) {
					nthOldestMemoryIndex -= this.memoryCapacity;
				}
			}
		}

		if (this.isMemoryForgotten(memory)) {
			return null;
		}
		else {
			return memory;
		}
	}
	else {
		return null;
	}
}

ActorBlock.prototype.getEarliestMemory = function() {
	return this.getNthEarliestMemory(0);
}

ActorBlock.prototype.recallLaterMemory = function() {
	if (this.currentMemoryIndex != this.oldestMemoryIndex - 1) {

		var laterMemoryIndex = this.currentMemoryIndex;
		laterMemoryIndex++;
		
		if (laterMemoryIndex >= this.memoryCapacity) {
			laterMemoryIndex -= this.memoryCapacity;
		}

		
		var memory = this.memories[laterMemoryIndex];

		while(this.isMemoryForgotten(memory) && laterMemoryIndex != this.oldestMemoryIndex - 1) {
			laterMemoryIndex++;
			if (laterMemoryIndex >= this.memoryCapacity) {
				laterMemoryIndex -= this.memoryCapacity;
			}
			memory = this.memories[laterMemoryIndex];
		}

		if (this.isMemoryForgotten(memory)) {
			return null;
		}
		else {
			this.currentMemoryIndex = laterMemoryIndex;
			return memory;
		}
	}
	else {
		return null;
	}
}

ActorBlock.prototype.recallEarlierMemory = function() {
	if (this.currentMemoryIndex != this.oldestMemoryIndex) {

		var earlierMemoryIndex = this.currentMemoryIndex;
		earlierMemoryIndex--;

		if (earlierMemoryIndex < 0) {
			earlierMemoryIndex += this.memoryCapacity;
		}

		
		var memory = this.memories[earlierMemoryIndex];

		while(this.isMemoryForgotten(memory) && earlierMemoryIndex != this.oldestMemoryIndex) {
			earlierMemoryIndex--;
			if (earlierMemoryIndex < 0) {
				earlierMemoryIndex += this.memoryCapacity;
			}
			
			memory = this.memories[earlierMemoryIndex];
		}

		if (this.isMemoryForgotten(memory)) {
			return null;
		}
		else {
			this.currentMemoryIndex = earlierMemoryIndex;
			return memory;
		}
	}
	else {
		return null;
	}
}

ActorBlock.prototype.hasChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return !(memory.x == this.x && memory.y == this.y && memory.z == this.z && memory.xvel == this.xvel && memory.yvel == this.yvel && memory.zvel == this.zvel && memory.xacc == this.xacc && memory.yacc == this.yacc && memory.zacc == this.zacc && memory.rotation == this.rotation && memory.rotationVel == this.rotationVel && memory.rotationAcc == this.rotationAcc);
	}
}

ActorBlock.prototype.hasPositionChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return !(memory.x == this.x && memory.y == this.y && memory.z == this.z && memory.rotation == this.rotation);
	}
}

ActorBlock.prototype.update = function(dest) {
	if (this.awake) {
		this.updateMemory();

		for (var i = 0; i < this.behaviors.length; i++) {
			this.behaviors[i](this,dest);
		}

		for (var i = 0; i < this.constraints.length; i++) {
			this.constraints[i](this, dest);
		}

		for (var i = 0; i < this.children.length; i++) {
			this.children[i].update(dest);
		}
	}
	else {
		if (this.currentMemoryIndex >= 0 && this.currentMemoryIndex < this.memoryCapacity) {
			var currentMemory = this.memories[this.currentMemoryIndex];
			if (currentMemory != null) {
				this.changeMemoryIntoReality(currentMemory);
			}
		}
	}

	this.x = Math.round(this.x);
	this.y = Math.round(this.y);
}

ActorBlock.prototype.addBehavior = function (behavior, vars, propagateToChildren) {
	if (propagateToChildren == true) {
		for (var i = 0; i < this.children.length; i++) {
			if (this.children[i].children.length == 0) {
				this.children[i].addBehavior(behavior, extend(vars, {}));
			}
			else {
				this.children[i].addBehavior(behavior, extend(vars, {}), true);
			}
		}
	}
	else {
		if (this.behaviorLock == undefined && this.behaviors.indexOf(behavior) == -1) {
			this.behaviors.push(behavior);
			if (vars != undefined) {
				this.behaviorVars[getFunctionName(behavior)] = vars;
			}
		}
	}
}

ActorBlock.prototype.removeBehavior = function (behavior) {
	var index = this.behaviors.indexOf(behavior);
	if (index > -1) {
		this.behaviors.splice(index,1);
		//this.behaviorVars[getFunctionName(behavior)] = undefined;
	}
	//if (this.behaviorLock == behavior) {
	//	this.behaviorLock = undefined;
	//}

	for (var i = 0; i < this.children.length; i++) {
		this.children[i].removeBehavior(behavior);
	}
}

ActorBlock.prototype.addConstraint = function (constraint, vars, propagateToChildren) {
	if (propagateToChildren == true) {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].addConstraint(constraint, extend(vars,{}));
		}
	}
	else {
		if (this.constraints.indexOf(constraint) == -1) {
			this.constraints.push(constraint);
			if (vars != undefined) {
				this.constraintVars[getFunctionName(constraint)] = vars;
			}
		}
	}
}

ActorBlock.prototype.isMouseEventWithinBlock = function(e) {
	var drawx;
	var drawy;

	var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
	var zratio = 1
	if (this.z > 0) {
		zratio = 1 / (this.z / zscale);
	} 

	if (CANVASMANAGER.width > this.width && CANVASMANAGER.height > this.height) {
		drawx = Math.round(zratio*this.x);
		drawy = Math.round(zratio*this.y);
	}
	else {
		drawx = 0;
		drawy = 0;
	}

	if (e.x > drawx - zratio*this.scaleX*this.width/2 && e.x < drawx + zratio*this.scaleX*this.width/2 &&
		e.y > drawy - zratio*this.scaleX*this.height/2 && e.y < drawy + zratio*this.scaleX*this.height/2) {
		return true;
	}
	else {
		return false;
	}
}

ActorBlock.prototype.addMouseOverReaction = function (reaction, vars, propagateToChildren) {
	var that = this;
	if (!this.isSubscribedToMouseMove) {
		this.isSubscribedToMouseMove = true;
		CANVASMANAGER.mouseMoveEvent.subscribe(function(e) { 
			if (that.width > 0 && that.height > 0) {
				if (that.isMouseEventWithinBlock(e)) {
					if (!that.isMouseOver) {
						that.isMouseOver = true;
						for (var i = 0; i < that.mouseOverReactions.length; i++) {
							that.mouseOverReactions[i](that);
						}
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseOverReactions.length; i++) {
					that.mouseOverReactions[i](that);
				}
			}
		});
		CANVASMANAGER.mouseMoveEvent.subscribe(function(e) { 
			if (that.width > 0 && that.height > 0) {
				if (!that.isMouseEventWithinBlock(e)) {
					if (that.isMouseOver) {
						that.isMouseOver = false;
						for (var i = 0; i < that.mouseOutReactions.length; i++) {
							that.mouseOutReactions[i](that);
						}
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseOutReactions.length; i++) {
					that.mouseOutReactions[i](that);
				}
			}
		});
	}

	if (this.mouseOverReactions.indexOf(reaction) == -1) {
		this.mouseOverReactions.push(reaction);
	}
}

ActorBlock.prototype.addMouseOutReaction = function (reaction, vars, propagateToChildren) {
	var that = this;
	if (!this.isSubscribedToMouseMove) {
		this.isSubscribedToMouseMove = true;
		CANVASMANAGER.mouseMoveEvent.subscribe(function(e) { 
			if (that.width > 0 && that.height > 0) {
				if (that.isMouseEventWithinBlock(e)) {
					if (!that.isMouseOver) {
						that.isMouseOver = true;
						for (var i = 0; i < that.mouseOverReactions.length; i++) {
							that.mouseOverReactions[i](that);
						}
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseOverReactions.length; i++) {
					that.mouseOverReactions[i](that);
				}
			}
		});
		CANVASMANAGER.mouseMoveEvent.subscribe(function(e) { 
			if (that.width > 0 && that.height > 0) {
				if (!that.isMouseEventWithinBlock(e)) {
					if (that.isMouseOver) {
						that.isMouseOver = false;
						for (var i = 0; i < that.mouseOutReactions.length; i++) {
							that.mouseOutReactions[i](that);
						}
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseOutReactions.length; i++) {
					that.mouseOutReactions[i](that);
				}
			}
		});
	}

	if (this.mouseOutReactions.indexOf(reaction) == -1) {
		this.mouseOutReactions.push(reaction);
	}
}


ActorBlock.prototype.addMouseClickReaction = function (reaction, vars, propagateToChildren) {
	var that = this;
	if (!this.isSubscribedToMouseClick) {
		this.isSubscribedToMouseClick = true;
		CANVASMANAGER.mouseClickEvent.subscribe(function(e) { 
			if (that.width > 0 && that.height > 0) {
				if (that.isMouseEventWithinBlock(e)) {
					for (var i = 0; i < that.mouseClickReactions.length; i++) {
						that.mouseClickReactions[i](that);
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseClickReactions.length; i++) {
					that.mouseClickReactions[i](that);
				}
			}
		});
	}

	if (this.mouseClickReactions.indexOf(reaction) == -1) {
		this.mouseClickReactions.push(reaction);
	}
}

ActorBlock.prototype.addMouseDownReaction = function (reaction, vars, propagateToChildren) {
	var that = this;
	if (!this.isSubscribedToMouseDown) {
		this.isSubscribedToMouseDown = true;
		CANVASMANAGER.mouseDownEvent.subscribe(function(e) { 
			if (that.width > 0 && that.height > 0) {
				if (that.isMouseEventWithinBlock(e)) {
					for (var i = 0; i < that.mouseDownReactions.length; i++) {
						that.mouseDownReactions[i](that);
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseDownReactions.length; i++) {
					that.mouseDownReactions[i](that);
				}
			}
		});
	}

	if (this.mouseDownReactions.indexOf(reaction) == -1) {
		this.mouseDownReactions.push(reaction);
	}
}

ActorBlock.prototype.addMouseUpReaction = function (reaction, vars, propagateToChildren) {
	var that = this;
	if (!this.isSubscribedToMouseUp) {
		this.isSubscribedToMouseUp = true;
		CANVASMANAGER.mouseUpEvent.subscribe(function(e) { 
			if (that.width > 0 && that.height > 0) {
				if (that.isMouseEventWithinBlock(e)) {
					for (var i = 0; i < that.mouseUpReactions.length; i++) {
						that.mouseUpReactions[i](that);
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseUpReactions.length; i++) {
					that.mouseUpReactions[i](that);
				}
			}
		});
	}

	if (this.mouseUpReactions.indexOf(reaction) == -1) {
		this.mouseUpReactions.push(reaction);
	}
}

ActorBlock.prototype.addAnyKeyPressReaction = function(reaction, vars, propagateToChildren) {
	var that = this;
	var name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	if (this.keysPressedSubscribedTo.indexOf(name) == -1) {
		this.keysPressedSubscribedTo.push(name);
		CANVASMANAGER.keyEvent.subscribeToKeyPress(function(e) {
			if (that.keyPressReactions[name] != undefined) {
				for (var i = 0; i < that.keyPressReactions[name].length; i++) {
					that.keyPressReactions[name][i](that, e);
				}
			}
		});
	}

	if (this.keyPressReactions[name] == undefined) {
		this.keyPressReactions[name] = new Array();
	}
	if (this.keyPressReactions[name].indexOf(reaction) == -1) {
		this.keyPressReactions[name].push(reaction);
	}
}

ActorBlock.prototype.addAnyKeyDownReaction = function(reaction, vars, propagateToChildren) {
	var that = this;
	var name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	if (this.keysDownSubscribedTo.indexOf(name) == -1) {
		this.keysDownSubscribedTo.push(name);
		CANVASMANAGER.keyEvent.subscribeToKeyDown(function(e) {
			if (that.keyDownReactions[name] != undefined) {
				for (var i = 0; i < that.keyDownReactions[name].length; i++) {
					that.keyDownReactions[name][i](that, e);
				}
			}
		});
	}

	if (this.keyDownReactions[name] == undefined) {
		this.keyDownReactions[name] = new Array();
	}
	if (this.keyDownReactions[name].indexOf(reaction) == -1) {
		this.keyDownReactions[name].push(reaction);
	}
}

ActorBlock.prototype.addAnyKeyUpReaction = function(reaction, vars, propagateToChildren) {
	var that = this;
	var name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	if (this.keysUpSubscribedTo.indexOf(name) == -1) {
		this.keysUpSubscribedTo.push(name);
		CANVASMANAGER.keyEvent.subscribeToKeyUp(function(e) {
			if (that.keyUpReactions[name] != undefined) {
				for (var i = 0; i < that.keyUpReactions[name].length; i++) {
					that.keyUpReactions[name][i](that, e);
				}
			}
		});
	}

	if (this.keyUpReactions[name] == undefined) {
		this.keyUpReactions[name] = new Array();
	}
	if (this.keyUpReactions[name].indexOf(reaction) == -1) {
		this.keyUpReactions[name].push(reaction);
	}
}

ActorBlock.prototype.addKeyPressReaction = function(keyCode, reaction, vars, propagateToChildren) {
	var that = this;
	var name = KEYCODES.getStringFromKeyCode(keyCode);
	if (this.keysPressedSubscribedTo.indexOf(name) == -1) {
		this.keysPressedSubscribedTo.push(name);
		CANVASMANAGER.keyEvent.subscribeToKeyPress(function(e) {
			if (that.keyPressReactions[name] != undefined) {
				for (var i = 0; i < that.keyPressReactions[name].length; i++) {
					that.keyPressReactions[name][i](that, e);
				}
			}
		},
		keyCode);
	}

	if (this.keyPressReactions[name] == undefined) {
		this.keyPressReactions[name] = new Array();
	}
	if (this.keyPressReactions[name].indexOf(reaction) == -1) {
		this.keyPressReactions[name].push(reaction);
	}
}

ActorBlock.prototype.addKeyDownReaction = function(keyCode, reaction, vars, propagateToChildren) {
	var that = this;
	var name = KEYCODES.getStringFromKeyCode(keyCode);
	if (this.keysDownSubscribedTo.indexOf(name) == -1) {
		this.keysDownSubscribedTo.push(name);
		CANVASMANAGER.keyEvent.subscribeToKeyDown(function(e) {
			if (that.keyDownReactions[name] != undefined) {
				for (var i = 0; i < that.keyDownReactions[name].length; i++) {
					that.keyDownReactions[name][i](that, e);
				}
			}
		},
		keyCode);
	}

	if (this.keyDownReactions[name] == undefined) {
		this.keyDownReactions[name] = new Array();
	}
	if (this.keyDownReactions[name].indexOf(reaction) == -1) {
		this.keyDownReactions[name].push(reaction);
	}
}

ActorBlock.prototype.addKeyUpReaction = function(keyCode, reaction, vars, propagateToChildren) {
	var that = this;
	var name = KEYCODES.getStringFromKeyCode(keyCode);
	if (this.keysUpSubscribedTo.indexOf(name) == -1) {
		this.keysUpSubscribedTo.push(name);
		CANVASMANAGER.keyEvent.subscribeToKeyUp(function(e) {
			if (that.keyUpReactions[name] != undefined) {
				for (var i = 0; i < that.keyUpReactions[name].length; i++) {
					that.keyUpReactions[name][i](that, e);
				}
			}
		},
		keyCode);
	}

	if (this.keyUpReactions[name] == undefined) {
		this.keyUpReactions[name] = new Array();
	}
	if (this.keyUpReactions[name].indexOf(reaction) == -1) {
		this.keyUpReactions[name].push(reaction);
	}
}

ActorBlock.prototype.addKeyCombinationReaction = function(keyCodes, reaction, vars, propagateToChildren) {
	var that = this;
	var name = KEYCODES.getStringFromKeyCodes(keyCodes);
	if (this.keysDownSubscribedTo.indexOf(name) == -1) {
		this.keysDownSubscribedTo.push(name);
		CANVASMANAGER.keyEvent.subscribeToKeyCombination(function(e) {
			if (that.keyDownReactions[name] != undefined) {
				for (var i = 0; i < that.keyDownReactions[name].length; i++) {
					that.keyDownReactions[name][i](that, e);
				}
			}
		},
		keyCodes);
	}

	if (this.keyDownReactions[name] == undefined) {
		this.keyDownReactions[name] = new Array();
	}
	if (this.keyDownReactions[name].indexOf(reaction) == -1) {
		this.keyDownReactions[name].push(reaction);
	}
}