var KeyboardEvent = function() {
	this.keyPressSubscribedFunctions = new Object();
	this.keyDownSubscribedFunctions = new Object();
	this.keyUpSubscribedFunctions = new Object();
	this.keysDown = new Array();

	this.lastKeyCodePress = 0;
	this.lastKeyCodeDown = 0;
	this.lastKeyCodeUp = 0;

	this.lastKeyNamePress = "";
	this.lastKeyNameDown = "";
	this.lastKeyNameUp = "";

	this.KEYPRESSEVENT = 1;
	this.KEYDOWNEVENT = 2;
	this.KEYUPEVENT = 3;
 }

KeyboardEvent.prototype = new Event();

KeyboardEvent.prototype.keysDown = new Array();

KeyboardEvent.prototype.fireEvent = function(keyCode, eventType) {
	var index = this.keysDown.indexOf(keyCode);
	var name = KEYCODES.getStringFromKeyCode(keyCode);

	if (eventType == this.KEYDOWNEVENT) {
		this.lastKeyCodeDown = keyCode;
		this.lastKeyNameDown = name;
		if (index == -1) {
			this.keysDown.push(keyCode);

			if (this.keysDown.length > 1) {
				var combinationName = KEYCODES.getStringFromKeyCodes(this.keysDown);

				if (this.keyDownSubscribedFunctions[combinationName] != undefined) {
					for (var i = 0; i < this.keyDownSubscribedFunctions[combinationName].length; i++) {
						this.keyDownSubscribedFunctions[combinationName][i](this);
					}
				}
				
			}

			if (this.keyDownSubscribedFunctions[name] != undefined) {
				for (var i = 0; i < this.keyDownSubscribedFunctions[name].length; i++) {
					this.keyDownSubscribedFunctions[name][i](this);
				}
			}

			if (this.keyDownSubscribedFunctions[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)] != undefined) {
				for (var i = 0; i < this.keyDownSubscribedFunctions[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)].length; i++) {
					this.keyDownSubscribedFunctions[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)][i](this);
				}
			}
		}
	}
	else if (eventType == this.KEYUPEVENT) {
		this.lastKeyCodeUp = keyCode;
		this.lastKeyNameUp = name;
		if (index != -1) {
			this.keysDown.splice(index, 1);
		}

		if (this.keyUpSubscribedFunctions[name] != undefined) {
			for (var i = 0; i < this.keyUpSubscribedFunctions[name].length; i++) {
				this.keyUpSubscribedFunctions[name][i](this);
			}
		}

		if (this.keyUpSubscribedFunctions[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)] != undefined) {
			for (var i = 0; i < this.keyUpSubscribedFunctions[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)].length; i++) {
				this.keyUpSubscribedFunctions[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)][i](this);
			}
		}
	}
	else if (eventType == this.KEYPRESSEVENT) {
		this.lastKeyCodePress = keyCode;
		this.lastKeyNamePress = name;
		if (this.keyPressSubscribedFunctions[name] != undefined) {
			for (var i = 0; i < this.keyPressSubscribedFunctions[name].length; i++) {
				this.keyPressSubscribedFunctions[name][i](this);
			}
		}

		if (this.keyPressSubscribedFunctions[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)] != undefined) {
			for (var i = 0; i < this.keyPressSubscribedFunctions[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)].length; i++) {
				this.keyPressSubscribedFunctions[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)][i](this);
			}
		}
	}
}

KeyboardEvent.prototype.subscribeToKeyPress = function(func, keyCode) {
	var name;

	if (keyCode == undefined) {
		name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	}
	else {
		name = KEYCODES.getStringFromKeyCode(keyCode);
	}
	

	if (this.keyPressSubscribedFunctions[name] == undefined) {
		this.keyPressSubscribedFunctions[name] = new Array();
	}

	if (this.keyPressSubscribedFunctions[name].indexOf(func) == -1) {
		this.keyPressSubscribedFunctions[name].push(func);
	}
}

KeyboardEvent.prototype.subscribeToKeyDown = function(func, keyCode) {
	var name;

	if (keyCode == undefined) {
		name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	}
	else {
		name = KEYCODES.getStringFromKeyCode(keyCode);
	}
	

	if (this.keyDownSubscribedFunctions[name] == undefined) {
		this.keyDownSubscribedFunctions[name] = new Array();
	}

	if (this.keyDownSubscribedFunctions[name].indexOf(func) == -1) {
		this.keyDownSubscribedFunctions[name].push(func);
	}
}

KeyboardEvent.prototype.subscribeToKeyUp = function(func, keyCode) {
	var name;

	if (keyCode == undefined) {
		name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	}
	else {
		name = KEYCODES.getStringFromKeyCode(keyCode);
	}

	if (this.keyUpSubscribedFunctions[name] == undefined) {
		this.keyUpSubscribedFunctions[name] = new Array();
	}

	if (this.keyUpSubscribedFunctions[name].indexOf(func) == -1) {
		this.keyUpSubscribedFunctions[name].push(func);
	}
}

KeyboardEvent.prototype.subscribeToKeyCombination = function(func, keyCodes) {
	var combinationName = KEYCODES.getStringFromKeyCodes(keyCodes);

	if (this.keyDownSubscribedFunctions[combinationName] == undefined) {
		this.keyDownSubscribedFunctions[combinationName] = new Array();
	}

	if (this.keyDownSubscribedFunctions[combinationName].indexOf(func) == -1) {
		this.keyDownSubscribedFunctions[combinationName].push(func);
	}
}