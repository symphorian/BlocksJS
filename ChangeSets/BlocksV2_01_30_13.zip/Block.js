var Block = function () {
	this.identity = null;
	this.x = 0;
	this.y = 0;
	this.z = 0;

	this.homeX = 0;
	this.homeY = 0;
	this.homeZ = 0;

	this.width = 0;
	this.height = 0;

	this.scaleX = 1;
	this.scaleY = 1;

	this.rotation = 0;

	this.visible = true;

	this.parent = null;
	this.children = new Array();
};

Block.prototype.globalX = function() {
	if (this.parent == null) {
		return this.x;
	}
	else {
		return this.parent.globalX()+this.x;
	}
}

Block.prototype.globalY = function() {
	if (this.parent == null) {
		return this.y;
	}
	else {
		return this.parent.globalY()+this.y;
	}
}

Block.prototype.globalZ = function() {
	if (this.parent == null) {
		return this.z;
	}
	else {
		return this.parent.globalZ()+this.z;
	}
}

Block.prototype.globalScaleX = function() {
	if (this.parent == null) {
		return this.scaleX;
	}
	else {
		return this.parent.globalScaleX()+this.scaleX;
	}
}

Block.prototype.globalScaleY = function() {
	if (this.parent == null) {
		return this.scaleY;
	}
	else {
		return this.parent.globalScaleY()+this.scaleY;
	}
}

Block.prototype.adoptChild = function(childBlock) {
	this.children.push(childBlock);
	childBlock.parent = this;

	if (childBlock.identity == null) {
		childBlock.identity = "Block" + CANVASMANAGER.getIdentityNumber();
		LOG.write("Child " + childBlock.identity + " adopted by " + this.identity, LOG.VERBOSE);
	}
}

Block.prototype.draw = function(dest) {
	this.children.sort(function(a,b) { return b.z - a.z });
	for (var i = 0; i < this.children.length; i++) {
		this.children[i].draw(dest);
	}
};

Block.prototype.undraw = function(dest) {
	for (var i = 0; i < this.children.length; i++) {
		this.children[i].undraw(dest);
	}
};