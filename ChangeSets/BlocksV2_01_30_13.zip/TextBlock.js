var TextBlock = function(text, font, size) {
	LOG.write("TextBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);

	this.oldText = null;
	this.oldFont = null;
	this.oldSize = null;

	this.text = text;
	this.font = font;
	this.size = size;

	this.alignment = "center";

	this.textImageData = null;
	this.textImage = new Image();
}

TextBlock.prototype = new ActorBlock();

TextBlock.prototype.recordMemory = function() {
	var memory = ActorBlock.prototype.recordMemory.call(this);

	memory.text = this.text;
	memory.font = this.font;
	memory.size = this.size;
	memory.alignment = this.alignment;

	return memory;
}

TextBlock.prototype.changeMemoryIntoReality = function(memory) {
	ActorBlock.prototype.changeMemoryIntoReality.call(this,memory);
	this.text = memory.text;
	this.font = memory.font;
	this.size = memory.size;
	this.alignment = memory.alignment;
}

TextBlock.prototype.hasChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return ActorBlock.prototype.hasChangedFromLatestMemory.call(this) || !(memory.text == this.text && memory.font == this.font && memory.size == this.size && memory.alignment == this.alignment);
	}
}

TextBlock.prototype.createTextData = function() {
	LOG.write("creating text data");
	//LOG.write(this.identity + " child of " + this.parent.identity);

	CANVASMANAGER.workingCanvasFrame.context.font = this.size + "px " + this.font;
	CANVASMANAGER.workingCanvasFrame.context.fillStyle = "black";
	CANVASMANAGER.workingCanvasFrame.context.textBaseline = 'top';
    CANVASMANAGER.workingCanvasFrame.context.textAlign = 'left';

	this.width = CANVASMANAGER.workingCanvasFrame.context.measureText(this.text).width;
	if (this.width == 0) { this.width = 1; }
	var textMetric = TEXTHELPER.measureTextHeight(this.text,this.font,this.size);
	this.height = textMetric.height + 1;

	CANVASMANAGER.workingCanvasFrame.resize(this.width,this.height,-1);

	CANVASMANAGER.workingCanvasFrame.context.font = this.size + "px " + this.font;
	CANVASMANAGER.workingCanvasFrame.context.fillStyle = "black";
	CANVASMANAGER.workingCanvasFrame.context.textBaseline = 'top';
    CANVASMANAGER.workingCanvasFrame.context.textAlign = 'left';


	CANVASMANAGER.workingCanvasFrame.context.clearRect(0,0,this.width,this.height);

	if (this.text.length > 0) {
		CANVASMANAGER.workingCanvasFrame.context.fillText(this.text, 0, 0);
	}
	else {
		CANVASMANAGER.workingCanvasFrame.context.fillText(" ", 0, 0);
	}

	//CANVASMANAGER.workingCanvasFrame.context.fillRect(0,0,1000,1);
	//CANVASMANAGER.workingCanvasFrame.context.fillRect(0,textMetric.ascent,1000,1);
	//CANVASMANAGER.workingCanvasFrame.context.fillRect(0,textMetric.height,1000,1);

	this.textImageData = CANVASMANAGER.workingCanvasFrame.context.getImageData(0,0,this.width,this.height);
	this.textImage.src = CANVASMANAGER.workingCanvasFrame.canvas.toDataURL();
}

TextBlock.prototype.setText = function(newText) {
	this.text = newText;
}

TextBlock.prototype.setFont = function(newFont) {
	this.font = newFont;
}

TextBlock.prototype.setSize = function(newSize) {
	this.size = newSize;
}

TextBlock.prototype.setAlignment = function(newAlignment) {
	var alignment = "center";

	switch (newAlignment) {
		case "left":
		case "right":
		case "center":
			alignment = newAlignment;
			break;
	}

	this.alignment = alignment;
}

TextBlock.prototype.undraw = function(dest) {
	if (this.children.length == 0) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var originX;
				var originY;

				switch (this.alignment) {
					case "center":
						originX = this.width/2;
						originY = this.height/2;
						break;

					case "left":
						originX = 0;
						originY = 0;
						break;

					case "right":
						originX = this.width;
						originY = this.height;
						break;
				}


				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
				var zratio = 1
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 

				drawx = Math.round(CANVASMANAGER.width / 2 - originX + zratio*this.globalX());
				drawy = Math.round(CANVASMANAGER.height / 2 - originY + zratio*this.globalY());				

				dest.save();
				dest.translate(drawx+originX - 1,drawy+originY - 1);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);

				dest.clearRect(-originX, -originY, this.width + 2/(zratio*this.scaleX), this.height + 2/(zratio*this.scaleY));

				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in TextBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
	else {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].undraw(dest);
		}
	}
}

TextBlock.prototype.update = function(dest) {
	ActorBlock.prototype.update.call(this);

	if (this.oldText != this.text || this.oldFont != this.font || this.oldSize != this.size) {
		this.createTextData();
		this.oldText = this.text;
		this.oldFont = this.font;
		this.oldSize = this.size;
	}
}

TextBlock.prototype.draw = function(dest) {
	if (this.children.length == 0) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var originX;
				var originY;

				switch (this.alignment) {
					case "center":
						originX = this.width/2;
						originY = this.height/2;
						break;

					case "left":
						originX = 0;
						originY = 0;
						break;

					case "right":
						originX = this.width;
						originY = this.height;
						break;
				}


				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
				var zratio = 1;
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 
	
				drawx = Math.round(CANVASMANAGER.width / 2 - originX + zratio*this.globalX());
				drawy = Math.round(CANVASMANAGER.height / 2 - originY + zratio*this.globalY());

				

				dest.save();
				dest.translate(drawx+originX,drawy+originY);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);
				
				dest.drawImage(this.textImage,-originX,-originY);
				//dest.fillText(this.text, -this.width/2, -this.height/2);

				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in TextBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
	else {
		this.children.sort(function(a,b) { return b.z - a.z });
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].draw(dest);
		}
	}
}