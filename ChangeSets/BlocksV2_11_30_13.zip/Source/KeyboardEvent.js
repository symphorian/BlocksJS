var KeyboardEvent = function() {
	this.keyPressSubscribedBlocks = new Object();
	this.keyDownSubscribedBlocks = new Object();
	this.keyUpSubscribedBlocks = new Object();
	this.keysDown = new Array();

	this.lastKeyCodePress = 0;
	this.lastKeyCodeDown = 0;
	this.lastKeyCodeUp = 0;

	this.lastKeyNamePress = "";
	this.lastKeyNameDown = "";
	this.lastKeyNameUp = "";

	this.KEYPRESSEVENT = "KeyPressEvent";
	this.KEYDOWNEVENT = "KeyDownEvent";
	this.KEYUPEVENT = "KeyUpEvent";
 }

KeyboardEvent.prototype = new BlockEvent();

KeyboardEvent.prototype.keysDown = new Array();

KeyboardEvent.prototype.fireEvent = function(keyCode, eventType) {
	var index = this.keysDown.indexOf(keyCode);
	var name = KEYCODES.getStringFromKeyCode(keyCode);
	var anyKeyName = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);

	if (eventType == this.KEYDOWNEVENT) {
		this.lastKeyCodeDown = keyCode;
		this.lastKeyNameDown = name;
		if (index == -1) {
			this.keysDown.push(keyCode);

			if (this.keysDown.length > 1) {
				var combinationName = KEYCODES.getStringFromKeyCodes(this.keysDown);

				if (this.keyDownSubscribedBlocks[combinationName] != undefined) {
					for (var i = 0; i < this.keyDownSubscribedBlocks[combinationName].length; i++) {
						this.keyDownSubscribedBlocks[combinationName][i]["reactTo" + this.KEYDOWNEVENT](this,name);
					}
				}
				
			}

			if (this.keyDownSubscribedBlocks[name] != undefined) {
				for (var i = 0; i < this.keyDownSubscribedBlocks[name].length; i++) {
					this.keyDownSubscribedBlocks[name][i]["reactTo" + this.KEYDOWNEVENT](this, name);
				}
			}

			if (this.keyDownSubscribedBlocks[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)] != undefined) {
				for (var i = 0; i < this.keyDownSubscribedBlocks[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)].length; i++) {
					this.keyDownSubscribedBlocks[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)][i]["reactTo" + this.KEYDOWNEVENT](this,anyKeyName);
				}
			}
		}
	}
	else if (eventType == this.KEYUPEVENT) {
		this.lastKeyCodeUp = keyCode;
		this.lastKeyNameUp = name;
		if (index != -1) {
			this.keysDown.splice(index, 1);
		}

		if (this.keyUpSubscribedBlocks[name] != undefined) {
			for (var i = 0; i < this.keyUpSubscribedBlocks[name].length; i++) {
				this.keyUpSubscribedBlocks[name][i]["reactTo" + this.KEYUPEVENT](this,name);
			}
		}

		if (this.keyUpSubscribedBlocks[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)] != undefined) {
			for (var i = 0; i < this.keyUpSubscribedBlocks[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)].length; i++) {
				this.keyUpSubscribedBlocks[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)][i]["reactTo" + this.KEYUPEVENT](this,anyKeyName);
			}
		}
	}
	else if (eventType == this.KEYPRESSEVENT) {
		this.lastKeyCodePress = keyCode;
		this.lastKeyNamePress = name;
		if (this.keyPressSubscribedBlocks[name] != undefined) {
			for (var i = 0; i < this.keyPressSubscribedBlocks[name].length; i++) {
				this.keyPressSubscribedBlocks[name][i]["reactTo" + this.KEYPRESSEVENT](this,name);
			}
		}

		if (this.keyPressSubscribedBlocks[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)] != undefined) {
			for (var i = 0; i < this.keyPressSubscribedBlocks[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)].length; i++) {
				this.keyPressSubscribedBlocks[KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY)][i]["reactTo" + this.KEYPRESSEVENT](this,anyKeyName);
			}
		}
	}
}

KeyboardEvent.prototype.subscribeToKeyPress = function(block, keyCode) {
	var name;

	if (keyCode == undefined) {
		name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	}
	else {
		name = KEYCODES.getStringFromKeyCode(keyCode);
	}
	

	if (this.keyPressSubscribedBlocks[name] == undefined) {
		this.keyPressSubscribedBlocks[name] = new Array();
	}

	if (this.keyPressSubscribedBlocks[name].indexOf(block) == -1) {
		this.keyPressSubscribedBlocks[name].push(block);
	}
}

KeyboardEvent.prototype.subscribeToKeyDown = function(block, keyCode) {
	var name;

	if (keyCode == undefined) {
		name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	}
	else {
		name = KEYCODES.getStringFromKeyCode(keyCode);
	}
	

	if (this.keyDownSubscribedBlocks[name] == undefined) {
		this.keyDownSubscribedBlocks[name] = new Array();
	}

	if (this.keyDownSubscribedBlocks[name].indexOf(block) == -1) {
		this.keyDownSubscribedBlocks[name].push(block);
	}
}

KeyboardEvent.prototype.subscribeToKeyUp = function(block, keyCode) {
	var name;

	if (keyCode == undefined) {
		name = KEYCODES.getStringFromKeyCode(KEYCODES.ANYKEY);
	}
	else {
		name = KEYCODES.getStringFromKeyCode(keyCode);
	}

	if (this.keyUpSubscribedBlocks[name] == undefined) {
		this.keyUpSubscribedBlocks[name] = new Array();
	}

	if (this.keyUpSubscribedBlocks[name].indexOf(block) == -1) {
		this.keyUpSubscribedBlocks[name].push(block);
	}
}

KeyboardEvent.prototype.subscribeToKeyCombination = function(block, keyCodes) {
	var combinationName = KEYCODES.getStringFromKeyCodes(keyCodes);

	if (this.keyDownSubscribedBlocks[combinationName] == undefined) {
		this.keyDownSubscribedBlocks[combinationName] = new Array();
	}

	if (this.keyDownSubscribedBlocks[combinationName].indexOf(block) == -1) {
		this.keyDownSubscribedBlocks[combinationName].push(block);
	}
}