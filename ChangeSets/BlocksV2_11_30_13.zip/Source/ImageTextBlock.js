// Public Constructor function
// Input parameter(s):  text (string), font name (string)(default:Verdana), 
//                      font size (integer)(default:12), font color (string/hex)(default:#000/Black), 
//                      text alignment (string:left, center, or right)
// Returns: ImageTextBlock object instantiated with the supplied text and font properties
// Description: utilizes the native canvas textFill function to draw text, and then saves the rasterized text as an image
// Example: var myITB = new ImageTextBlock("Hello world!", "Verdana", 12, "Blue", "left");
var ImageTextBlock = function(text, font, size, color, alignment) {
	LOG.write("ImageTextBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);

	this.text = text;
	
	if (font == undefined) {
		this.font = "Verdana";
	}
	else {
		this.font = font;
	}

	if (size == undefined) {
		this.size = 12;
	}
	else {
		this.size = size;
	}

	if (color == undefined) {
		this.color = "#000";
	}
	else {
		this.color = color;
	}

	this.alignment = "center";
	this.lastAlignment = "center";
	switch (alignment) {
		case "left":
		case "right":
		case "center":
			this.alignment = alignment;
			this.lastAlignment = alignment;
			break;
	}

	this.textImageData = null;
	this.textImage = new Image();

	this.maskMode = "none";
}

ImageTextBlock.prototype = new ActorBlock();

// Private function
// Input parameters: none
// Returns: the modified memory object
// Description: overrides ActorBlock.recordMemory
ImageTextBlock.prototype.recordMemory = function() {
	var memory = ActorBlock.prototype.recordMemory.call(this);

	memory.text = this.text;
	memory.font = this.font;
	memory.size = this.size;
	memory.color = this.color;
	memory.alignment = this.alignment;

	return memory;
}

// Private function
// Input parameters: a memory object
// Returns: nothing
// Description: overrides ActorBlock.changeMemoryIntoReality
ImageTextBlock.prototype.changeMemoryIntoReality = function(memory) {
	ActorBlock.prototype.changeMemoryIntoReality.call(this,memory);
	this.text = memory.text;
	this.font = memory.font;
	this.size = memory.size;
	this.color = memory.color;
	this.alignment = memory.alignment;
}

// Private function
// Input parameters: boolean, whether or not changes in the parent class' properties are checked
// Returns: boolean, whether or not the current object state has changed from the last memory
// Description: overrides ActorBlock.hasChangedFromLatestMemory
ImageTextBlock.prototype.hasChangedFromLatestMemory = function(excludeParentProperties) {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return true;
	}
	else if (excludeParentProperties) {
		return !(memory.text == this.text && memory.font == this.font && memory.size == this.size && memory.alignment == this.alignment && memory.color == this.color);
	}
	else {
		return ActorBlock.prototype.hasChangedFromLatestMemory.call(this) || !(memory.text == this.text && memory.font == this.font && memory.size == this.size && memory.alignment == this.alignment && memory.color == this.color);
	}
}

// Private function
// Input parameters: none
// Returns: nothing
// Description: creates imageData and image objects from the text and font properties
ImageTextBlock.prototype.createTextData = function() {
	LOG.write("creating text data");
	//LOG.write(this.identity + " child of " + this.parent.identity);

	CANVASMANAGER.workingCanvasFrame.context.save();

	CANVASMANAGER.workingCanvasFrame.context.font = this.size + "px " + this.font;
	CANVASMANAGER.workingCanvasFrame.context.fillStyle = this.color;
	CANVASMANAGER.workingCanvasFrame.context.textBaseline = 'top';
    CANVASMANAGER.workingCanvasFrame.context.textAlign = 'left';

    // m is an additional buffer in case the font isn't set up properly
    // causing parts of the font to be cut off
    var m = CANVASMANAGER.workingCanvasFrame.context.measureText("M").width;

	this.width = CANVASMANAGER.workingCanvasFrame.context.measureText(this.text).width + m;
	if (this.width == 0) { this.width = 1; }
	var textMetric = TEXTHELPER.measureTextHeight(this.text,this.font,this.size);
	this.height = textMetric.height + 1 + m;

	CANVASMANAGER.workingCanvasFrame.resize(this.width,this.height,-1);

	// since resizing reinitializes the canvas context, we need to reset our text properties
	CANVASMANAGER.workingCanvasFrame.context.font = this.size + "px " + this.font;
	CANVASMANAGER.workingCanvasFrame.context.fillStyle = this.color;
	CANVASMANAGER.workingCanvasFrame.context.textBaseline = 'top';
    CANVASMANAGER.workingCanvasFrame.context.textAlign = 'left';

	CANVASMANAGER.workingCanvasFrame.context.clearRect(0,0,this.width,this.height);

	CANVASMANAGER.workingCanvasFrame.context.save();
	// for some reason, hidden ascenders and descenders are revealed 
	// when rotation != 0 degrees (depending on zoom)
	CANVASMANAGER.workingCanvasFrame.context.translate(m/2,m/2);
	CANVASMANAGER.workingCanvasFrame.context.rotate(0.1*Math.PI/180);
	

	if (this.text.length > 0) {
		CANVASMANAGER.workingCanvasFrame.context.fillText(this.text, 0, 0);
	}
	else {
		CANVASMANAGER.workingCanvasFrame.context.fillText(" ", 0, 0);
	}

	CANVASMANAGER.workingCanvasFrame.context.restore();
	CANVASMANAGER.workingCanvasFrame.context.restore();

	this.textImageData = CANVASMANAGER.workingCanvasFrame.context.getImageData(0,0,this.width,this.height);
	this.textImage.src = CANVASMANAGER.workingCanvasFrame.canvas.toDataURL();

}

// Public function
// Input parameters: string
// Returns: nothing
// Description: sets the text property of the TextBlock object
ImageTextBlock.prototype.setText = function(newText) {
	this.text = newText;
}

// Public function
// Input parameters: string
// Returns: nothing
// Description: sets the font type property of the TextBlock object
ImageTextBlock.prototype.setFont = function(newFont) {
	this.font = newFont;
}

// Public function
// Input parameters: string
// Returns: nothing
// Description: sets the font size property of the TextBlock object
ImageTextBlock.prototype.setSize = function(newSize) {
	this.size = newSize;
}

// Public function
// Input parameters: string
// Returns: nothing
// Description: sets the text color property of the TextBlock object
ImageTextBlock.prototype.setColor = function(newColor) {
	this.color = newColor;
}

// Public function
// Input parameters: string
// Returns: nothing
// Description: sets the alignment property of the TextBlock object
ImageTextBlock.prototype.setAlignment = function(newAlignment) {
	var alignment = "center";

	switch (newAlignment) {
		case "left":
		case "right":
		case "center":
			alignment = newAlignment;
			break;
	}

	this.alignment = alignment;
}

// Private function
// Input parameters: mouseEvent object
// Returns: Boolean indicating if the mouse event is within the boundaries of an object
// Description: converts coordinates of the mouse event (global coordinates) into the coordinates of an object (local coordinates),
// and then checks if the mouse event coordinates are within the bounds of an object
ImageTextBlock.prototype.isMouseEventWithinBlock = function(e) {
	MATRIX.clearTransformations();

	this.addInverseTransformationsToMatrix(MATRIX);

	var xyResult = MATRIX.applyTransformation(e.x,e.y);

	LOG.writeObject(xyResult);

	switch (this.alignment) {
		case "center":
			if (xyResult.x > -this.width/2 && xyResult.x < this.width/2 &&
				xyResult.y > -this.height/2 && xyResult.y < this.height/2) {
				return true;
			}
			else {
				return false;
			}
			break;

		case "left":
			if (xyResult.x > 0 && xyResult.x < this.width &&
				xyResult.y > -this.height/2 && xyResult.y < this.height/2) {
				return true;
			}
			else {
				return false;
			}
			break;

		case "right":
			if (xyResult.x > -this.width && xyResult.x < 0 &&
				xyResult.y > -this.height/2 && xyResult.y < this.height/2) {
				return true;
			}
			else {
				return false;
			}
			break;
	}
}

// Private function
// Input parameters: canvas context where the undrawing should occur
// Returns: nothing
// Description: overrides Block.undraw,
// used to clear the rectangle occupied by the object's text after applying necessary transformations
ImageTextBlock.prototype.undraw = function(dest) {
	var drawx = 0;
	var drawy = 0;
	try {
		if (this.visible && this.z >= 0) {
			var originX;
			var originY;

			switch (this.lastAlignment) {
				case "center":
					originX = this.width/2;
					originY = this.height/2;
					break;

				case "left":
					originX = 0;
					originY = this.height/2;
					break;

				case "right":
					originX = this.width;
					originY = this.height/2;
					break;
			}


			var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
			var zratio = 1
			if (this.z > 0) {
				zratio = 1 / (this.z / zscale);
			} 

			drawx = Math.round(-originX + zratio*this.x);
			drawy = Math.round(-originY + zratio*this.y);				

			dest.save();
			dest.translate(drawx+originX,drawy+originY);
			dest.scale(zratio*this.scaleX,zratio*this.scaleY);
			dest.rotate(this.rotation*Math.PI/180);

			dest.clearRect(-originX - 1, -originY - 1, this.width + 2, this.height + 2);

			if (this.showDebugDisplay) {
				dest.clearRect(-5,-5,10,10);
			}

			for (var i = 0; i < this.children.length; i++) {
				this.children[i].undraw(dest);
			}

			dest.restore();
		}
	}
	catch (err) {
		LOG.write("error in ImageTextBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
		LOG.writeBlock(this, LOG.ERROR);
		LOG.writeObject(err, LOG.ERROR);
		debugger;
	}
}

// Private function
// Input parameters: canvas context where updates may occur
// Returns: nothing
// Description: overrides ActorBlock.update,
// handles text and font updates
ImageTextBlock.prototype.update = function(dest) {
	this.lastAlignment = this.alignment;

	if (this.hasChangedFromLatestMemory(true)) {
		this.createTextData();
	}

	ActorBlock.prototype.update.call(this);
}

// Private function
// Input parameters: canvas context where the drawing should occur
// Returns: nothing
// Description: overrides Block.draw,
// used to draw the object's current text after applying necessary transformations
ImageTextBlock.prototype.draw = function(dest) {
	var drawx = 0;
	var drawy = 0;
	try {
		if (this.visible && this.z >= 0) {
			var originX;
			var originY;

			switch (this.alignment) {
				case "center":
					originX = this.width/2;
					originY = this.height/2;
					break;

				case "left":
					originX = 0;
					originY = this.height/2;
					break;

				case "right":
					originX = this.width;
					originY = this.height/2;
					break;
			}


			var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
			var zratio = 1;
			if (this.z > 0) {
				zratio = 1 / (this.z / zscale);
			} 

			drawx = Math.round(-originX + zratio*this.x);
			drawy = Math.round(-originY + zratio*this.y);

			dest.save();
			dest.translate(drawx+originX,drawy+originY);
			dest.scale(zratio*this.scaleX,zratio*this.scaleY);
			dest.rotate(this.rotation*Math.PI/180);

			switch(this.maskMode) {
				case "window":
					dest.globalCompositeOperation = "destination-in";
				break;

				case "wall":
					dest.globalCompositeOperation = "destination-out";
				break;
			}
			
			dest.drawImage(this.textImage,-originX,-originY);
			//dest.fillText(this.text, -originX, -originY);

			if (this.showDebugDisplay) {
				dest.save();
				dest.strokeStyle = "Green";
				dest.lineWidth = 1;
				dest.beginPath();
				dest.moveTo(0,0);
				dest.lineTo(0,-this.height/2);
				dest.stroke();
				dest.fillStyle = "Red";
				dest.fillRect(-4,-4,8,8);
				dest.beginPath();
				dest.strokeStyle = "Blue";
				dest.lineWidth = 1;
				dest.rect(-originX,-originY,this.width,this.height);
				dest.stroke();
				dest.restore();
			}

			this.children.sort(function(a,b) { return b.z - a.z });
			for (var i = 0; i < this.children.length; i++) {
				this.children[i].draw(dest);
			}

			dest.restore();
		}
	}
	catch (err) {
		LOG.write("error in ImageTextBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
		LOG.writeBlock(this, LOG.ERROR);
		LOG.writeObject(err, LOG.ERROR);
		debugger;
	}
}