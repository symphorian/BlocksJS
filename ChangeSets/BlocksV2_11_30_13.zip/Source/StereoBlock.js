var StereoBlock = function() {
	LOG.write("SoundBlock constructor called", LOG.VERBOSE);
	PlayerBlock.call(this);

	this.tracks = new Array();

	for (var i = 0; i < arguments.length; i++) {
		var track = CANVASMANAGER.getAudioAsset(arguments[i]);
		if (track != null) {
			this.tracks.push(track);
		}
	}

	this.currentTrackIndex = 0;
	this.volume = 100;
	this.looping = false;
}

StereoBlock.prototype = new PlayerBlock();

StereoBlock.prototype.recordMemory = function() {
	var memory = ActorBlock.prototype.recordMemory.call(this);

	memory.currentTrackIndex = this.currentTrackIndex;

	return memory;
}

StereoBlock.prototype.changeMemoryIntoReality = function(memory) {
	ActorBlock.prototype.changeMemoryIntoReality.call(this,memory);
	this.currentTrackIndex = memory.currentTrackIndex;
}

StereoBlock.prototype.hasChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return ActorBlock.prototype.hasChangedFromLatestMemory.call(this) || !(memory.currentTrackIndex == this.currentTrackIndex);
	}
}

StereoBlock.prototype.getTrack = function(trackName) {
	for (var i = 0; i < this.tracks.length; i++) {
		if (this.tracks[i].getName() == trackName) {
			return this.tracks[i];
		}
	}
	return null;
}

StereoBlock.prototype.getTrackIndex = function(trackName) {
	for (var i = 0; i < this.tracks.length; i++) {
		if (this.tracks[i].getName() == trackName) {
			return i;
		}
	}
	return -1;
}

StereoBlock.prototype.play = function(trackName) {
	if (trackName != null) {
		var newTrackIndex = this.getTrackIndex(trackName);
		if (newTrackIndex >= 0 && newTrackIndex != this.currentTrackIndex) {
			this.stop();
			this.currentTrackIndex = newTrackIndex;
		}
	}

	this.tracks[this.currentTrackIndex].play();
}

StereoBlock.prototype.pause = function() {
	this.tracks[this.currentTrackIndex].pause();
}

StereoBlock.prototype.stop = function() {
	this.tracks[this.currentTrackIndex].play();
	this.tracks[this.currentTrackIndex].pause();
}

StereoBlock.prototype.getVolume = function() {
	return this.volume;
}

StereoBlock.prototype.setVolume = function(percent) {
	this.volume = percent;
	for (var i = 0; i < this.tracks.length; i++) {
		this.tracks[i].setVolume(this.volume);
	}
}

StereoBlock.prototype.setLooping = function(shouldLoop) {
	this.looping = shouldLoop;
	for (var i = 0; i < this.tracks.length; i++) {
		this.tracks[i].setLooping(this.looping);
	}
}