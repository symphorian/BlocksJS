var SoundBlock = function(trackAlias) {
	LOG.write("SoundBlock constructor called", LOG.VERBOSE);
	PlayerBlock.call(this);

	this.track = CANVASMANAGER.getAudioAsset(trackAlias);
}

SoundBlock.prototype = new PlayerBlock();

SoundBlock.prototype.play = function() {
	this.track.play();
}

SoundBlock.prototype.pause = function() {
	this.track.pause();
}

SoundBlock.prototype.stop = function() {
	this.track.play();
	this.track.pause();
}

SoundBlock.prototype.getVolume = function() {
	return this.track.getVolume();
}

SoundBlock.prototype.setVolume = function(percent) {
	this.track.setVolume(percent);
}

SoundBlock.prototype.setLooping = function(shouldLoop) {
	this.track.setLooping(shouldLoop);
}