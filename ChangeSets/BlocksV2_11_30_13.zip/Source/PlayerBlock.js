var PlayerBlock = function() {
	LOG.write("PlayerBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);
}

PlayerBlock.prototype = new ActorBlock();

PlayerBlock.prototype.play = function() {

}

PlayerBlock.prototype.pause = function() {

}

PlayerBlock.prototype.stop = function() {

}

PlayerBlock.prototype.getVolume = function() {

}

PlayerBlock.prototype.setVolume = function() {

}