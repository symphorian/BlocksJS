var CanvasManager = function() {
	LOG.write("CanvasManager constructor function called", LOG.VERBOSE);
	var that = this;
	this.width = 0;
	this.height = 0;

	this.identityNumber = 0;

	this.startUpFunction = null;

	this.fov = 75; // field of view in degrees

	this.frameRate = 30;

	this.canvasFrameStack = new Array();
	//this.workingCanvasFrame = new CanvasFrame(this.width, this.height);

	this.mouseMoveEvent = new MouseEvent("MouseMoveEvent");
	this.mouseClickEvent = new MouseEvent("MouseClickEvent");
	this.mouseDownEvent = new MouseEvent("MouseDownEvent");
	this.mouseUpEvent = new MouseEvent("MouseUpEvent");

	this.keyEvent = new KeyboardEvent("KeyEvent");

	/*
	this.isFixedWidth = false;
	this.isFixedHeight = false;

	if (isFixedWidth != null) {
		this.isFixedWidth = isFixedWidth;
	}
	if (isFixedHeight != null) {
		this.isFixedHeight = isFixedHeight;
	}

	if (width != null) {
		this.width = width;
	}
	if (height != null) {
		this.height = height;
	}
	*/

	window.onload = function() {
		LOG.write("Window loaded and ready for action. Window width: " + window.innerWidth + " Window height: " + window.innerHeight, LOG.VERBOSE);
		
		//that.gallery = document.createElement("div");
		//that.gallery.setAttribute("style", "position: relative");


		that.width = window.innerWidth;
		that.height = window.innerHeight;
		that.workingCanvasFrame = new CanvasFrame(that.width, that.height, -1);
		var canvasFrame = new CanvasFrame(that.width, that.height, 0);
		that.canvasFrameStack.push(canvasFrame);

		//document.body.appendChild(that.gallery);
		//that.gallery.appendChild(canvasFrame.canvas);
		document.body.appendChild(canvasFrame.canvas);

		if (that.startUpFunction != null) {
			that.startUpFunction();
		}
	}

	window.onresize = function() {
		LOG.write("Window resize detected. width: " + window.innerWidth + " height: " + window.innerHeight, LOG.VERBOSE);
		var shouldResizeCanvases = false;
		if (!that.isFixedWidth) {
			that.width = window.innerWidth;
			shouldResizeCanvases = true;
		}
		if (!that.isFixedHeight) {
			that.height = window.innerHeight;
			shouldResizeCanvases = true;
		}

		if (shouldResizeCanvases) {
			for (var i = 0; i < that.canvasFrameStack.length; i++) {
				document.body.removeChild(that.canvasFrameStack[i].canvas);
				that.canvasFrameStack[i].resize(that.width, that.height, i);
				document.body.appendChild(that.canvasFrameStack[i].canvas);
				that.canvasFrameStack[i].masterBlock.x = that.width/2;
				that.canvasFrameStack[i].masterBlock.y = that.height/2;
			}
		}
	}

	window.onmousemove = function(e) {
		//LOG.write("Mouse move detected. moveX:" + e.pageX + " moveY:" + e.pageY, LOG.VERBOSE);
		that.mouseMoveEvent.fireEvent(e.pageX - that.width/2, e.pageY - that.height/2);
	}

	window.onclick = function(e) {
		LOG.write("Mouse click detected. clickX:" + e.pageX + " clickY:" + e.pageY, LOG.VERBOSE);
		that.mouseClickEvent.fireEvent(e.pageX, e.pageY);
	}

	window.onmousedown = function(e) {
		LOG.write("Mouse down detected. downX:" + e.pageX + " downY:" + e.pageY, LOG.VERBOSE);
		that.mouseDownEvent.fireEvent(e.pageX - that.width/2, e.pageY - that.height/2);
	}

	window.onmouseup = function(e) {
		LOG.write("Mouse up detected. upX:" + e.pageX + " upY:" + e.pageY, LOG.VERBOSE);
		that.mouseUpEvent.fireEvent(e.pageX - that.width/2, e.pageY - that.height/2);
	}

	window.onkeypress = function(e) {
		LOG.write("Key press detected. keycode:" + e.keyCode + " key:" + KEYCODES.getStringFromKeyCode(e.keyCode), LOG.VERBOSE);
		that.keyEvent.fireEvent(e.keyCode, that.keyEvent.KEYPRESSEVENT);
	}

	window.onkeydown = function(e) {
		LOG.write("Key down detected. keycode:" + e.keyCode + " key:" + KEYCODES.getStringFromKeyCode(e.keyCode), LOG.VERBOSE);
		that.keyEvent.fireEvent(e.keyCode, that.keyEvent.KEYDOWNEVENT);

		if (e.keyCode == KEYCODES.BACKSPACE) {
			that.keyEvent.fireEvent(e.keyCode, that.keyEvent.KEYPRESSEVENT);
			return false;
		}
	}

	window.onkeyup = function(e) {
		LOG.write("Key up detected. keycode:" + e.keyCode + " key:" + KEYCODES.getStringFromKeyCode(e.keyCode), LOG.VERBOSE);
		that.keyEvent.fireEvent(e.keyCode, that.keyEvent.KEYUPEVENT);

		if (e.keyCode == KEYCODES.BACKSPACE) {
			return false;
		}
	}

	this.assetManager = new AssetManager();
};

CanvasManager.prototype.getIdentityNumber = function() {
	return this.identityNumber++;
}

CanvasManager.prototype.setStartUpFunction = function(func) {
	this.startUpFunction = func;
}

CanvasManager.prototype.addCanvasFrame = function(canvasFrame) {
	var index = this.canvasFrameStack.indexOf(canvasFrame);
	
	if (index > -1) {
		this.canvasFrameStack.splice(index, 1);
		this.gallery.removeChild(canvasFrame.canvas);
	}

	this.canvasFrameStack.push(canvasFrame);

	//this.gallery.appendChild(canvasFrame.canvas);
	document.body.appendChild(canvasFrame.canvas);
}

CanvasManager.prototype.addNewCanvasFrame = function() {
	var canvasFrame = new CanvasFrame(this.width, this.height, this.canvasFrameStack.length);
	this.canvasFrameStack.push(canvasFrame);
	//this.gallery.appendChild(canvasFrame.canvas);
	document.body.appendChild(canvasFrame.canvas);
}

CanvasManager.prototype.adoptBlockChild = function(block, canvasFrameIndex) {
	if (this.canvasFrameStack.length > 0) {
		if (canvasFrameIndex != null) {
			this.canvasFrameStack[canvasFrameIndex].adoptBlockChild(block);
		}
		else {
			this.canvasFrameStack[0].adoptBlockChild(block);
		}
	}
	else {
		LOG.write("No CanvasFrames have been added to this instance of CanvasManager, so no Block children can be adopted.  Please create and add a new CanvasFrame in order to give this Block child a home.", LOG.WARN);
	}
	
}

CanvasManager.prototype.refreshAll = function() {
	for (var i = 0; i < this.canvasFrameStack.length; i++) {
		this.canvasFrameStack[i].refresh();
	}
}

CanvasManager.prototype.start = function(frameRate) {
	var that = this;

	if (frameRate != null) {
		this.frameRate = frameRate;
	}

	setInterval(function() {window.requestAnimationFrame(function() { that.refreshAll(); })},1000/this.frameRate);
}

CanvasManager.prototype.showVerboseMessages = function() {
	LOG.setLogThreshold(LOG.VERBOSE);
}

CanvasManager.prototype.showInfoMessages = function() {
	LOG.setLogThreshold(LOG.INFO);
}

CanvasManager.prototype.showWarningMessages = function() {
	LOG.setLogThreshold(LOG.WARN);
}

CanvasManager.prototype.showErrorMessages = function() {
	LOG.setLogThreshold(LOG.ERROR);
}

CanvasManager.prototype.showFatalMessages = function() {
	LOG.setLogThreshold(LOG.FATAL);
}

CanvasManager.prototype.showNoMessages = function() {
	LOG.setLogThreshold(LOG.NONE);
}

/*
CanvasManager.prototype.loadImageAssetsXML = function(filename) {
	this.assetManager.loadImageAssetXML(filename);
}

CanvasManager.prototype.loadAudioAssetsXML = function(filename) {
	this.assetManager.loadAudioAssetXML(filename);
}
*/

CanvasManager.prototype.loadAssets = function(imageXMLfilename, audioXMLfilename, videoXMLfilename) {
	this.assetManager.loadAssets(imageXMLfilename, audioXMLfilename, videoXMLfilename);
}

CanvasManager.prototype.getSingleImageAsset = function(alias) {
	return this.assetManager.imageAssets[alias].img;
}

// pass in image aliases to be gotten
//CanvasManager.prototype.getImageAssets = function() {
//	var imageAssets = new Array();
//	for (var i = 0; i < arguments.length; i++) {
//		imageAssets.push(this.assetManager.imageAssets[arguments[i]].img);
//	}
//	return imageAssets;
//}

CanvasManager.prototype.getImageAssets = function(aliases) {
	var imageAssets = new Array();
	for (var i = 0; i < aliases.length; i++) {
		imageAssets.push(this.assetManager.imageAssets[aliases[i]].img);
	}
	return imageAssets;
}

CanvasManager.prototype.getSingleImageAssetData = function(alias) {
	return this.assetManager.imageAssets[alias].imgdata;
}

// pass in image aliases to be gotten
//CanvasManager.prototype.getImageAssetData = function() {
//	var imageAssets = new Array();
//	for (var i = 0; i < arguments.length; i++) {
//		imageAssets.push(this.assetManager.imageAssets[arguments[i]].imgdata);
//	}
//	return imageAssets;
//}

CanvasManager.prototype.getImageAssetData = function(aliases) {
	var imageAssets = new Array();
	for (var i = 0; i < aliases.length; i++) {
		imageAssets.push(this.assetManager.imageAssets[aliases[i]].imgdata);
	}
	return imageAssets;
}

CanvasManager.prototype.getAudioAsset = function(alias) {
	return this.assetManager.audioAssets[alias].track;
}

CanvasManager.prototype.getVideoAsset = function(alias) {
	return this.assetManager.videoAssets[alias].video;
}

var CANVASMANAGER = new CanvasManager();