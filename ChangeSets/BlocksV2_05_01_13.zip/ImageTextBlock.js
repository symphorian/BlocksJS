var ImageTextBlock = function(text, font, size, color, alignment) {
	LOG.write("ImageTextBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);

	this.oldText = null;
	this.oldFont = null;
	this.oldSize = null;
	this.oldColor = null;

	this.text = text;
	
	if (font == undefined) {
		this.font = "Verdana";
	}
	else {
		this.font = font;
	}

	if (size == undefined) {
		this.size = 12;
	}
	else {
		this.size = size;
	}

	if (color == undefined) {
		this.color = "#000";
	}
	else {
		this.color = color;
	}

	this.alignment = "center";
	switch (alignment) {
		case "left":
		case "right":
		case "center":
			this.alignment = alignment;
			break;
	}

	this.textImageData = null;
	this.textImage = new Image();
}

ImageTextBlock.prototype = new ActorBlock();

ImageTextBlock.prototype.recordMemory = function() {
	var memory = ActorBlock.prototype.recordMemory.call(this);

	memory.text = this.text;
	memory.font = this.font;
	memory.size = this.size;
	memory.color = this.color;
	memory.alignment = this.alignment;

	return memory;
}

ImageTextBlock.prototype.changeMemoryIntoReality = function(memory) {
	ActorBlock.prototype.changeMemoryIntoReality.call(this,memory);
	this.text = memory.text;
	this.font = memory.font;
	this.size = memory.size;
	this.color = memory.color;
	this.alignment = memory.alignment;
}

ImageTextBlock.prototype.hasChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return ActorBlock.prototype.hasChangedFromLatestMemory.call(this) || !(memory.text == this.text && memory.font == this.font && memory.size == this.size && memory.alignment == this.alignment && memory.color == this.color);
	}
}

ImageTextBlock.prototype.createTextData = function() {
	LOG.write("creating text data");
	//LOG.write(this.identity + " child of " + this.parent.identity);

	CANVASMANAGER.workingCanvasFrame.context.font = this.size + "px " + this.font;
	CANVASMANAGER.workingCanvasFrame.context.fillStyle = this.color;
	CANVASMANAGER.workingCanvasFrame.context.textBaseline = 'top';
    CANVASMANAGER.workingCanvasFrame.context.textAlign = 'left';

	this.width = CANVASMANAGER.workingCanvasFrame.context.measureText(this.text).width;
	if (this.width == 0) { this.width = 1; }
	var textMetric = TEXTHELPER.measureTextHeight(this.text,this.font,this.size);
	this.height = textMetric.height + 1;

	CANVASMANAGER.workingCanvasFrame.resize(this.width,this.height,-1);

	CANVASMANAGER.workingCanvasFrame.context.font = this.size + "px " + this.font;
	CANVASMANAGER.workingCanvasFrame.context.fillStyle = this.color;
	CANVASMANAGER.workingCanvasFrame.context.textBaseline = 'top';
    CANVASMANAGER.workingCanvasFrame.context.textAlign = 'left';


	CANVASMANAGER.workingCanvasFrame.context.clearRect(0,0,this.width,this.height);

	if (this.text.length > 0) {
		CANVASMANAGER.workingCanvasFrame.context.fillText(this.text, 0, 0);
	}
	else {
		CANVASMANAGER.workingCanvasFrame.context.fillText(" ", 0, 0);
	}

	//CANVASMANAGER.workingCanvasFrame.context.fillRect(0,0,1000,1);
	//CANVASMANAGER.workingCanvasFrame.context.fillRect(0,textMetric.ascent,1000,1);
	//CANVASMANAGER.workingCanvasFrame.context.fillRect(0,textMetric.height,1000,1);

	this.textImageData = CANVASMANAGER.workingCanvasFrame.context.getImageData(0,0,this.width,this.height);
	this.textImage.src = CANVASMANAGER.workingCanvasFrame.canvas.toDataURL();

}

ImageTextBlock.prototype.setText = function(newText) {
	this.text = newText;
}

ImageTextBlock.prototype.setFont = function(newFont) {
	this.font = newFont;
}

ImageTextBlock.prototype.setSize = function(newSize) {
	this.size = newSize;
}

ImageTextBlock.prototype.setColor = function(newColor) {
	this.color = newColor;
}

ImageTextBlock.prototype.setAlignment = function(newAlignment) {
	var alignment = "center";

	switch (newAlignment) {
		case "left":
		case "right":
		case "center":
			alignment = newAlignment;
			break;
	}

	this.alignment = alignment;
}

ImageTextBlock.prototype.isMouseEventWithinBlock = function(e) {
	MATRIX.clearTransformations();

	this.addInverseTransformationsToMatrix(MATRIX);

	var xyResult = MATRIX.applyTransformation(e.x,e.y);

	LOG.writeObject(xyResult);

	switch (this.alignment) {
		case "center":
			if (xyResult.x > -this.width/2 && xyResult.x < this.width/2 &&
				xyResult.y > -this.height/2 && xyResult.y < this.height/2) {
				return true;
			}
			else {
				return false;
			}
			break;

		case "left":
			if (xyResult.x > 0 && xyResult.x < this.width &&
				xyResult.y > -this.height/2 && xyResult.y < this.height/2) {
				return true;
			}
			else {
				return false;
			}
			break;

		case "right":
			if (xyResult.x > -this.width && xyResult.x < 0 &&
				xyResult.y > -this.height/2 && xyResult.y < this.height/2) {
				return true;
			}
			else {
				return false;
			}
			break;
	}
}

ImageTextBlock.prototype.undraw = function(dest) {
	if (this.children.length == 0) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var originX;
				var originY;

				switch (this.alignment) {
					case "center":
						originX = this.width/2;
						originY = this.height/2;
						break;

					case "left":
						originX = 0;
						originY = this.height/2;
						break;

					case "right":
						originX = this.width;
						originY = this.height/2;
						break;
				}


				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
				var zratio = 1
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 

				drawx = Math.round(-originX + zratio*this.x);
				drawy = Math.round(-originY + zratio*this.y);				

				dest.save();
				dest.translate(drawx+originX - 1,drawy+originY - 1);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);

				dest.clearRect(-originX, -originY, this.width + 2/(zratio*this.scaleX), this.height + 2/(zratio*this.scaleY));

				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in TextBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
	else {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].undraw(dest);
		}
	}
}

ImageTextBlock.prototype.update = function(dest) {
	ActorBlock.prototype.update.call(this);

	if (this.oldText != this.text || this.oldFont != this.font || this.oldSize != this.size || this.oldColor != this.color) {
		this.createTextData();
		this.oldText = this.text;
		this.oldFont = this.font;
		this.oldSize = this.size;
		this.oldColor = this.color;
	}
}

ImageTextBlock.prototype.draw = function(dest) {
	if (this.children.length == 0) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var originX;
				var originY;

				switch (this.alignment) {
					case "center":
						originX = this.width/2;
						originY = this.height/2;
						break;

					case "left":
						originX = 0;
						originY = this.height/2;
						break;

					case "right":
						originX = this.width;
						originY = this.height/2;
						break;
				}


				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
				var zratio = 1;
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 
	
				drawx = Math.round(-originX + zratio*this.x);
				drawy = Math.round(-originY + zratio*this.y);

				dest.save();
				dest.translate(drawx+originX,drawy+originY);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);
				
				dest.drawImage(this.textImage,-originX,-originY);
				//dest.fillText(this.text, -originX, -originY);

				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in TextBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
	else {
		this.children.sort(function(a,b) { return b.z - a.z });
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].draw(dest);
		}
	}
}