var AudioTrack = function() {
	LOG.write("AudioTrack constructor called", LOG.VERBOSE);
	this.audio = document.createElement("audio");
	this.name = "";
	this.onload = null;
}

AudioTrack.prototype.setName = function(alias) {
	this.name = alias;
	this.audio.name = alias;
}

AudioTrack.prototype.load = function(filename) {
	this.audio.addEventListener("canplaythrough", this.onload);
	this.audio.src = filename;
	this.audio.load();
}

AudioTrack.prototype.play = function(startFromBeginning) {
	if (startFromBeginning == true) {
		this.audio.currentTime = 0;
	}
	this.audio.play();
}

AudioTrack.prototype.pause = function() {
	if (this.audio.paused) {
		this.audio.play();
	}
	else {
		this.audio.pause();
	}
}

AudioTrack.prototype.getVolume = function() {
	return this.audio.volume*100;
}

AudioTrack.prototype.setVolume = function(percent) {
	var decimal = 0;
	if (percent >= 100) {
		decimal = 1;
	}
	else if (percent <= 0) {
		decimal = 0;
	}
	else {
		decimal = percent / 100.0;
	}

	this.audio.volume = decimal;
}