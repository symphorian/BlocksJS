var TextBlock = function(text, font, size, color, alignment) {
	LOG.write("TextBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);

	this.text = text;

	if (font == undefined) {
		this.font = "Verdana";
	}
	else {
		this.font = font;
	}

	if (size == undefined) {
		this.size = 12;
	}
	else {
		this.size = size;
	}
	
	if (color == undefined) {
		this.color = "#000";
	}
	else {
		this.color = color;
	}
	
	this.alignment = "center";
	switch (alignment) {
		case "left":
		case "right":
		case "center":
			this.alignment = alignment;
			break;
	}

	this.ascent = 0;
	this.descent = 0;
	
}

TextBlock.prototype = new ActorBlock();

TextBlock.prototype.recordMemory = function() {
	var memory = ActorBlock.prototype.recordMemory.call(this);

	memory.text = this.text;
	memory.font = this.font;
	memory.size = this.size;
	memory.color = this.color;
	memory.alignment = this.alignment;

	return memory;
}

TextBlock.prototype.changeMemoryIntoReality = function(memory) {
	ActorBlock.prototype.changeMemoryIntoReality.call(this,memory);
	this.text = memory.text;
	this.font = memory.font;
	this.size = memory.size;
	this.color = memory.color;
	this.alignment = memory.alignment;
}

TextBlock.prototype.hasChangedFromLatestMemory = function(excludeParentProperties) {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return true;
	}
	else if (excludeParentProperties) {
		return !(memory.text == this.text && memory.font == this.font && memory.size == this.size && memory.alignment == this.alignment && memory.color == this.color);
	}
	else {
		return ActorBlock.prototype.hasChangedFromLatestMemory.call(this) || !(memory.text == this.text && memory.font == this.font && memory.size == this.size && memory.alignment == this.alignment && memory.color == this.color);
	}
}

TextBlock.prototype.isMouseEventWithinBlock = function(e) {
	MATRIX.clearTransformations();

	this.addInverseTransformationsToMatrix(MATRIX);

	var xyResult = MATRIX.applyTransformation(e.x,e.y);

	LOG.writeObject(xyResult);

	switch (this.alignment) {
		case "center":
			if (xyResult.x > -this.width/2 && xyResult.x < this.width/2 &&
				xyResult.y > -this.height/2 - this.ascent && xyResult.y < this.height/2 - this.ascent) {
				return true;
			}
			else {
				return false;
			}
			break;

		case "left":
			if (xyResult.x > 0 && xyResult.x < this.width &&
				xyResult.y > -this.height/2 - this.ascent && xyResult.y < this.height/2 - this.ascent) {
				return true;
			}
			else {
				return false;
			}
			break;

		case "right":
			if (xyResult.x > -this.width && xyResult.x < 0 &&
				xyResult.y > -this.height/2 - this.ascent && xyResult.y < this.height/2 - this.ascent) {
				return true;
			}
			else {
				return false;
			}
			break;
	}
}

TextBlock.prototype.setText = function(newText) {
	this.text = newText;
}

TextBlock.prototype.setAlignment = function(newAlignment) {
	var alignment = "center";

	switch (newAlignment) {
		case "left":
		case "right":
		case "center":
			alignment = newAlignment;
			break;
	}

	this.alignment = alignment;
}

TextBlock.prototype.undraw = function(dest) {
	if (this.children.length == 0) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var originX;
				var originY;

				switch (this.alignment) {
					case "center":
						originX = this.width/2;
						originY = this.height/2;
						break;

					case "left":
						originX = 0;
						originY = this.height/2;
						break;

					case "right":
						originX = this.width;
						originY = this.height/2;
						break;
				}


				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
				var zratio = 1
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 

				drawx = Math.round(-originX + zratio*this.x);
				drawy = Math.round(-originY + zratio*this.y);				

				dest.save();
				dest.translate(drawx+originX - 1,drawy+originY - 1);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);
				
				dest.clearRect(-originX - 10, -originY - this.ascent, this.width + 2/(zratio*this.scaleX) + 20, this.height + 2/(zratio*this.scaleY) + 1);

				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in TextBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
	else {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].undraw(dest);
		}
	}
}

TextBlock.prototype.update = function(dest) {
	if (this.hasChangedFromLatestMemory(true)) {
		CANVASMANAGER.workingCanvasFrame.context.save();
		CANVASMANAGER.workingCanvasFrame.context.font = this.size + "px " + this.font;
		CANVASMANAGER.workingCanvasFrame.context.fillStyle = this.color;
		CANVASMANAGER.workingCanvasFrame.context.fillText(this.text, 0, 0);
		this.width = CANVASMANAGER.workingCanvasFrame.context.measureText(this.text).width;
		CANVASMANAGER.workingCanvasFrame.context.restore();

		var metric = TEXTHELPER.measureTextHeight(this.text,this.font,this.size);
		this.height = metric.height;
		this.ascent = metric.ascent;
		this.descent = metric.descent;
	}

	ActorBlock.prototype.update.call(this);

	if (this.width == 0) { this.width = 1; }
	if (this.height ==0) { this.height = 1; }
}

TextBlock.prototype.draw = function(dest) {
	if (this.children.length == 0) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var originX;
				var originY;

				switch (this.alignment) {
					case "center":
						originX = this.width/2;
						originY = this.height/2;
						break;

					case "left":
						originX = 0;
						originY = this.height/2;
						break;

					case "right":
						originX = this.width;
						originY = this.height/2;
						break;
				}


				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
				var zratio = 1;
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 
	
				drawx = Math.round(-originX + zratio*this.x);
				drawy = Math.round(-originY + zratio*this.y);

				dest.save();
				dest.translate(drawx+originX,drawy+originY);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);
				
				//dest.drawImage(this.textImage,-originX,-originY);

				dest.font = this.size + "px " + this.font;
				dest.fillStyle = this.color;
				dest.fillText(this.text, -originX, -originY);

				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in TextBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
	else {
		this.children.sort(function(a,b) { return b.z - a.z });
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].draw(dest);
		}
	}
}