var CanvasManager = function() {
	trace("CanvasManager constructor function called");
	var that = this;
	this.width = 0;
	this.height = 0;

	/*
	this.isFixedWidth = false;
	this.isFixedHeight = false;

	if (isFixedWidth != null) {
		this.isFixedWidth = isFixedWidth;
	}
	if (isFixedHeight != null) {
		this.isFixedHeight = isFixedHeight;
	}

	if (width != null) {
		this.width = width;
	}
	if (height != null) {
		this.height = height;
	}
	*/

	this.startUpFunction = null;

	this.fov = 75; // field of view in degrees

	this.frameRate = 30;

	this.canvasFrameStack = new Array();
	//this.workingCanvasFrame = new CanvasFrame(this.width, this.height);

	this.mouseMoveEvent = new MouseEvent();
	this.mouseClickEvent = new MouseEvent();
	this.mouseDownEvent = new MouseEvent();
	this.mouseUpEvent = new MouseEvent();

	this.keyDownEvent = new KeyboardEvent();
	this.keyUpEvent = new KeyboardEvent();

	window.onload = function() {
		trace("Window loaded and ready for action. Window width: " + window.innerWidth + " Window height: " + window.innerHeight);
		
		//that.gallery = document.createElement("div");
		//that.gallery.setAttribute("style", "position: relative");


		that.width = window.innerWidth;
		that.height = window.innerHeight;
		that.workingCanvasFrame = new CanvasFrame(that.width, that.height, -1);
		var canvasFrame = new CanvasFrame(that.width, that.height, 0);
		that.canvasFrameStack.push(canvasFrame);

		//document.body.appendChild(that.gallery);
		//that.gallery.appendChild(canvasFrame.canvas);
		document.body.appendChild(canvasFrame.canvas);

		if (that.startUpFunction != null) {
			that.startUpFunction();
		}
	}

	window.onresize = function() {
		trace("Window resize detected. width: " + window.innerWidth + " height: " + window.innerHeight);
		var shouldResizeCanvases = false;
		if (!that.isFixedWidth) {
			that.width = window.innerWidth;
			shouldResizeCanvases = true;
		}
		if (!that.isFixedHeight) {
			that.height = window.innerHeight;
			shouldResizeCanvases = true;
		}

		if (shouldResizeCanvases) {
			for (var i = 0; i < that.canvasFrameStack.length; i++) {
				document.body.removeChild(that.canvasFrameStack[i].canvas);
				that.canvasFrameStack[i].resize(that.width, that.height, i);
				document.body.appendChild(that.canvasFrameStack[i].canvas);
			}
		}
	}

	window.onmousemove = function(e) {
		//trace("moveX:" + e.pageX + " moveY:" + e.pageY);
		that.mouseMoveEvent.fireEvent(e.pageX - that.width/2, e.pageY - that.height/2);
	}

	window.onclick = function(e) {
		//trace("clickX:" + e.pageX + " clickY:" + e.pageY);
		that.mouseClickEvent.fireEvent(e.pageX - that.width/2, e.pageY - that.height/2);
	}

	window.onmousedown = function(e) {
		//trace("downX:" + e.pageX + " downY:" + e.pageY);
		that.mouseDownEvent.fireEvent(e.pageX - that.width/2, e.pageY - that.height/2);
	}

	window.onmouseup = function(e) {
		//trace("upX:" + e.pageX + " upY:" + e.pageY);
		that.mouseUpEvent.fireEvent(e.pageX - that.width/2, e.pageY - that.height/2);
	}

	this.assetManager = new AssetManager();
};

CanvasManager.prototype.setStartUpFunction = function(func) {
	this.startUpFunction = func;
}

CanvasManager.prototype.addCanvasFrame = function(canvasFrame) {
	var index = this.canvasFrameStack.indexOf(canvasFrame);
	
	if (index > -1) {
		this.canvasFrameStack.splice(index, 1);
		this.gallery.removeChild(canvasFrame.canvas);
	}

	this.canvasFrameStack.push(canvasFrame);

	//this.gallery.appendChild(canvasFrame.canvas);
	document.body.appendChild(canvasFrame.canvas);
}

CanvasManager.prototype.addNewCanvasFrame = function() {
	var canvasFrame = new CanvasFrame(this.width, this.height, this.canvasFrameStack.length);
	this.canvasFrameStack.push(canvasFrame);
	//this.gallery.appendChild(canvasFrame.canvas);
	document.body.appendChild(canvasFrame.canvas);
}

CanvasManager.prototype.adoptBlockChild = function(block, canvasFrameIndex) {
	if (this.canvasFrameStack.length > 0) {
		if (canvasFrameIndex != null) {
			this.canvasFrameStack[canvasFrameIndex].adoptBlockChild(block);
		}
		else {
			this.canvasFrameStack[0].adoptBlockChild(block);
		}
	}
	else {
		trace("No CanvasFrames have been added to this instance of CanvasManager, so no Block children can be adopted.  Please create and add a new CanvasFrame in order to give this Block child a home.")
	}
	
}

CanvasManager.prototype.refreshAll = function() {
	for (var i = 0; i < this.canvasFrameStack.length; i++) {
		this.canvasFrameStack[i].refresh();
	}
}

CanvasManager.prototype.start = function(frameRate) {
	var that = this;

	if (frameRate != null) {
		this.frameRate = frameRate;
	}

	setInterval(function() { that.refreshAll(); },1000/this.frameRate);
}

CanvasManager.prototype.loadAssetsXML = function(filename) {
	this.assetManager.loadImageAssetXML(filename);
}

// pass in image aliases to be gotten
CanvasManager.prototype.getImageAssets = function() {
	var imageAssets = new Array();
	for (var i = 0; i < arguments.length; i++) {
		imageAssets.push(this.assetManager.imageAssets[arguments[i]].img);
	}
	return imageAssets;
}

// pass in image aliases to be gotten
CanvasManager.prototype.getImageAssetData = function() {
	var imageAssets = new Array();
	for (var i = 0; i < arguments.length; i++) {
		imageAssets.push(this.assetManager.imageAssets[arguments[i]].imgdata);
	}
	return imageAssets;
}

var CANVASMANAGER = new CanvasManager();