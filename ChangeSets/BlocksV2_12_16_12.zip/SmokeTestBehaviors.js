function simpleVelocityUpdate(obj,dest) {
	obj.x += obj.xvel;
	obj.y += obj.yvel;
	obj.x = Math.round(obj.x);
	obj.y = Math.round(obj.y);

	//trace("x: " + obj.x + " y:" + obj.y + " xvel:" + obj.xvel + " yvel:" + obj.yvel);
}

function pace(obj,dest) {
	var left = obj.behaviorVars["pace"].left;
	var right = obj.behaviorVars["pace"].right;

	if (obj.xvel == 0) {
		obj.xvel = 1;
		obj.yvel = 1;
	}

	if (obj.x > right) {
		obj.xvel = -1;
	}
	if (obj.x < left) {
		obj.xvel = 1;
	}
}

function zpace(obj,dest) {
	if (obj.behaviorVars["zpace"] == null) {
		obj.behaviorVars["zpace"] = new Object();
		var goesAway;
		if (Math.random() > .5) {
			goesAway = true;
		}
		else {
			goesAway = false;
		}
		obj.behaviorVars["zpace"].away = goesAway;
	}

	if (obj.behaviorVars["zpace"].away) {
		obj.z += 0.01;
		if (obj.z > 2) {
			obj.behaviorVars["zpace"].away = false;
			trace("here i come!")
		}
	}
	else {
		obj.z -= 0.01;
		if (obj.z < 0) {
			obj.behaviorVars["zpace"].away = true;
			trace("run away!")
		}
	}
}

function spin(obj,dest) {
	obj.rotation++;
}

function growAndShrink(obj,dest) {
	if (obj.behaviorVars["growAndshrink"] == null) {
		obj.behaviorVars["growAndshrink"] = new Object();
		obj.behaviorVars["growAndshrink"].growing = true;
	}

	if (obj.behaviorVars["growAndshrink"].growing) {
		obj.scaleX += 0.02;
		if (obj.scaleX > 2) {
			obj.behaviorVars["growAndshrink"].growing = false;
		}
		obj.scaleY = obj.scaleX;
	}
	else {
		obj.scaleX -= 0.02;
		if (obj.scaleX < 0.05) {
			obj.behaviorVars["growAndshrink"].growing = true;
		}
		obj.scaleY = obj.scaleX;
	}
}

function poke(obj,dest) {
	if (CANVASMANAGER.mouseMoveEvent.x > obj.x - obj.width/2 && CANVASMANAGER.mouseMoveEvent.x < obj.x + obj.width/2 &&
		CANVASMANAGER.mouseMoveEvent.y > obj.y - obj.height/2 && CANVASMANAGER.mouseMoveEvent.y < obj.y + obj.height/2) {
		trace("poked you!")
	}
}

function angularVelUpdate(obj, dest) {

	if (obj.behaviorVars["angularVelUpdate"] == null) {
		obj.behaviorVars["angularVelUpdate"] = new Object();
	}

	var degrees = obj.behaviorVars["angularVelUpdate"].angle;
	var speed = obj.behaviorVars["angularVelUpdate"].speed;

	if (degrees == undefined) {
		degrees = Math.random() * 360;
		obj.behaviorVars["angularVelUpdate"].angle = degrees;
	}
	if (speed == undefined) {
		speed = 5;
		obj.behaviorVars["angularVelUpdate"].speed = speed;
	}

	var xsign = 0;
	var ysign = 0;

	while (degrees > 360) {
		degrees -= 360;
	}

	while (degrees < 0) {
		degrees += 360;
	}

	if (degrees >= 0 && degrees < 180) {
		ysign = 1;
	}
	else {
		ysign = -1;
	}

	if (degrees >= 90 && degrees < 270) {
		xsign = -1;
	}
	else {
		xsign = 1;
	}

	if (degrees > 270) {
		degrees -= 180;
		degrees = 180 - degrees;
	}
	else if (degrees > 180) {
		degrees -= 180;
	}
	else if (degrees > 90) {
		degrees = 180 - degrees;
	}

	var radians = degrees*Math.PI/180;

	obj.xvel = xsign * speed * Math.cos(radians);
	obj.yvel = ysign * speed * Math.sin(radians);

	obj.x += obj.xvel;
	obj.y += obj.yvel;
	obj.x = Math.round(obj.x);
	obj.y = Math.round(obj.y);

	obj.rotation = obj.behaviorVars["angularVelUpdate"].angle;
}

function wanderWithinBoundaries(obj, dest) {
	var leftBoundaryCrossed = false;
	var rightBoundaryCrossed = false;
	var topBoundaryCrossed = false;
	var bottomBoundaryCrossed = false;

	if (obj.constraintVars["checkForCrossedBoundaries"] != undefined) {
		leftBoundaryCrossed = obj.constraintVars["checkForCrossedBoundaries"].leftBoundaryCrossed;
		rightBoundaryCrossed = obj.constraintVars["checkForCrossedBoundaries"].rightBoundaryCrossed;
		topBoundaryCrossed = obj.constraintVars["checkForCrossedBoundaries"].topBoundaryCrossed;
		bottomBoundaryCrossed = obj.constraintVars["checkForCrossedBoundaries"].bottomBoundaryCrossed;
	}

	var chanceToTurn = obj.behaviorVars["wanderWithinBoundaries"].chanceToTurn;
	var chanceToAccelerate = obj.behaviorVars["wanderWithinBoundaries"].chanceToAccelerate;
	var maxTurnAngle = obj.behaviorVars["wanderWithinBoundaries"].maxTurnAngle;
	var maxTurnFrames = obj.behaviorVars["wanderWithinBoundaries"].maxTurnFrames;
	var maxAcceleration = obj.behaviorVars["wanderWithinBoundaries"].maxAcceleration;
	var maxAccelerationFrames = obj.behaviorVars["wanderWithinBoundaries"].maxAccelerationFrames;
	var returnAngle = obj.behaviorVars["wanderWithinBoundaries"].returnAngle;

	var framesToTurn = obj.behaviorVars["wanderWithinBoundaries"].framesToTurn;
	var turnAngle = obj.behaviorVars["wanderWithinBoundaries"].turnAngle;
	var framesToAccelerate = obj.behaviorVars["wanderWithinBoundaries"].framesToAccelerate;
	var acceleration = obj.behaviorVars["wanderWithinBoundaries"].acceleration;


	if (leftBoundaryCrossed || rightBoundaryCrossed || topBoundaryCrossed || bottomBoundaryCrossed) {

		if (framesToTurn != 0) {
			framesToTurn = 0;
			turnAngle = 0;
		}
		framesToAccelerate = 0;

		var currentAngle = obj.behaviorVars["angularVelUpdate"].angle;
		while (currentAngle < 0) {
			currentAngle += 360;
		}
		while (currentAngle > 360) {
			currentAngle -= 360;
		}
		if (leftBoundaryCrossed) {
			if (!((currentAngle > 0 && currentAngle < 10) || (currentAngle > 350 && currentAngle < 360))) {
				if (turnAngle == 0) {
					if (currentAngle > 180) {
						turnAngle = returnAngle;
					}
					else {
						turnAngle = -returnAngle;
					}
				}
				obj.behaviorVars["angularVelUpdate"].angle += turnAngle;
			}
		}
		else if (rightBoundaryCrossed) {
			if (!(currentAngle > 170 && currentAngle < 190)) {
				if (turnAngle == 0) {
					if (currentAngle < 180) {
						turnAngle = returnAngle;
					}
					else {
						turnAngle = -returnAngle;
					}
				}
				obj.behaviorVars["angularVelUpdate"].angle += turnAngle;
			}
		}
		else if (bottomBoundaryCrossed) {
			if (!(currentAngle > 260 && currentAngle < 280)) {
				if (turnAngle == 0) {
					if (currentAngle > 90 && currentAngle < 270) {
						turnAngle = returnAngle;
					}
					else {
						turnAngle = -returnAngle;
					}
				}
				obj.behaviorVars["angularVelUpdate"].angle += turnAngle;
			}
		}
		else if (topBoundaryCrossed) {
			if (!(currentAngle > 80 && currentAngle < 100)) {
				if (turnAngle == 0) {
					if (currentAngle < 270 && currentAngle > 90) {
						turnAngle = -returnAngle;
					}
					else {
						turnAngle = returnAngle;
					}
				}
				obj.behaviorVars["angularVelUpdate"].angle += turnAngle;
			}
		}
	}
	else {
		if (framesToTurn == undefined || framesToTurn == 0) {
			if (Math.random() < chanceToTurn) {
				framesToTurn = Math.ceil(Math.random() * maxTurnFrames);
				turnAngle = Math.round(Math.random()*maxTurnAngle*2 - maxTurnAngle);
			}
		}
		else {
			framesToTurn--;
			obj.behaviorVars["angularVelUpdate"].angle += turnAngle;
		}

		if (framesToAccelerate == undefined || framesToAccelerate == 0) {
			if (Math.random() < chanceToAccelerate) {
				framesToAccelerate = Math.ceil(Math.random() * maxAccelerationFrames);
				acceleration = Math.round(Math.random()*maxAcceleration*2 - maxAcceleration);
			}
		}
		else {
			framesToAccelerate--;
			obj.behaviorVars["angularVelUpdate"].speed += acceleration;

			if (obj.behaviorVars["angularVelUpdate"].speed < 0) {
				obj.behaviorVars["angularVelUpdate"].speed = 0;
			}
		}
	}

	obj.behaviorVars["wanderWithinBoundaries"].framesToTurn = framesToTurn;
	obj.behaviorVars["wanderWithinBoundaries"].turnAngle = turnAngle;
	obj.behaviorVars["wanderWithinBoundaries"].framesToAccelerate = framesToAccelerate;
	obj.behaviorVars["wanderWithinBoundaries"].acceleration = acceleration;
}

function applyRandomSingleColorFilter(obj, dest) {
	var color = obj.behaviorVars["applyRandomSingleColorFilter"].color;
	var lowerRange = obj.behaviorVars["applyRandomSingleColorFilter"].lowerRange;
	var upperRange = obj.behaviorVars["applyRandomSingleColorFilter"].upperRange;

	var red;
	var green;
	var blue;

	var rand = Math.random() * (upperRange-lowerRange) + lowerRange;

	switch(color) {
		case "red":
			if (rand < .5) {
				red = 255 * rand*2;
				green = 0;
				blue = 0;
			}
			else {
				red = 255;
				green = 255 * (1-rand)*2;
				blue = 255 * (1-rand)*2;
			}
			break;

		case "green":
			if (rand < .5) {
				red = 0;
				green = 255 * rand*2;
				blue = 0;
			}
			else {
				red = 255 * (1-rand)*2;
				green = 255;
				blue = 255 * (1-rand)*2;
			}
			break;

		case "blue":
			if (rand < .5) {
				red = 0;
				green = 0;
				blue = 255 * rand*2;
			}
			else {
				red = 255 * (1-rand)*2;
				green = 255 * (1-rand)*2;
				blue = 255;
			}
			break;

		default:
			red = 255 * rand;
			green = 255 * rand;
			blue = 255 * rand;
			break;
	}
	

	obj.setColorFilter(red, green, blue);

	obj.removeBehavior(applyRandomSingleColorFilter);
}

// event behaviors
function addRedFilter(obj) {
	if (obj.behaviorVars["addRedFilter"] == null) {
		obj.behaviorVars["addRedFilter"] = new Object();
		obj.behaviorVars["addRedFilter"].isRed = false;
	}

	if (obj.behaviorVars["addRedFilter"].isRed) {
		obj.behaviorVars["addRedFilter"].isRed = false;
		obj.resetFilters();
	}
	else {
		obj.behaviorVars["addRedFilter"].isRed = true;
		obj.setColorFilter(255);
	}
	
}

function createButterfly(obj) {
	var b = new MovieBlock(CANVASMANAGER.getImageAssetData("Butterfly1","Butterfly1","Butterfly2","Butterfly2","Butterfly3","Butterfly3","Butterfly2","Butterfly2"));

	b.addConstraint(checkForCrossedBoundaries, {leftMostX:-CANVASMANAGER.width/2 + 300, rightMostX:CANVASMANAGER.width/2 - 200, topMostY:0, bottomMostY:CANVASMANAGER.height/2 - 200});
	b.addBehavior(angularVelUpdate);
	b.addBehavior(wanderWithinBoundaries,{chanceToTurn:0.1, chanceToAccelerate:0.05, maxTurnAngle:8, maxTurnFrames:25, maxAcceleration:0.1, maxAccelerationFrames:10, returnAngle:4});
	
	var rand = Math.random();
	var clr;
	if (rand < .25) {
		clr = "red";
	}
	else if (rand < .5) {
		clr = "blue";
	}
	else if (rand < .75) {
		clr = "green"
	}
	else {
		clr = "";
	}

	b.addBehavior(applyRandomSingleColorFilter,{color:clr, lowerRange:0.4, upperRange:0.85});
	b.addBehavior(zpace);

	b.x = CANVASMANAGER.mouseClickEvent.x;
	b.y = CANVASMANAGER.mouseClickEvent.y;
	b.z = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
	

	obj.adoptChild(b);
}