var ActorBlock = function () {
	trace("ActorBlock constructor called");
	var that = this;
	Block.call(this);

	this.xvel = 0;
	this.yvel = 0;
	this.zvel = 0;

	this.xacc = 0;
	this.yacc = 0;
	this.zacc = 0;

	this.rotationVel = 0;
	this.rotationAcc = 0;

	this.behaviors = new Array();
	this.behaviorVars = new Array();
	//this.behaviorLock

	this.constraints = new Array();
	this.constraintVars = new Array();

	this.mouseOverBehaviors = new Array();
	this.mouseClickBehaviors = new Array();
	this.mouseDownBehaviors = new Array();
	this.mouseUpBehaviors = new Array();

	this.isSubscribedToMouseMove = false;
	this.isSubscribedToMouseClick = false;
	this.isSubscribedToMouseDown = false;
	this.isSubscribedToMouseUp = false;

	this.awake = true;
}

ActorBlock.prototype = new Block();

ActorBlock.prototype.update = function(dest) {
	for (var i = 0; i < this.behaviors.length; i++) {
		this.behaviors[i](this,dest);
	}

	for (var i = 0; i < this.constraints.length; i++) {
		this.constraints[i](this, dest);
	}

	for (var i = 0; i < this.children.length; i++) {
		this.children[i].update(dest);
	}
}

ActorBlock.prototype.addBehavior = function (behavior, vars, propagateToChildren) {
	if (propagateToChildren == true) {
		for (var i = 0; i < this.children.length; i++) {
			if (this.children[i].children.length == 0) {
				this.children[i].addBehavior(behavior, extend(vars, {}), true);
			}
			else {
				this.children[i].addBehavior(behavior, extend(vars, {}));
			}
		}
	}
	else {
		if (this.behaviorLock == undefined && this.behaviors.indexOf(behavior) == -1) {
			this.behaviors.push(behavior);
			if (vars != undefined) {
				this.behaviorVars[getFunctionName(behavior)] = vars;
			}
		}
	}
}

ActorBlock.prototype.removeBehavior = function (behavior) {
	var index = this.behaviors.indexOf(behavior);
	if (index > -1) {
		this.behaviors.splice(index,1);
		//this.behaviorVars[getFunctionName(behavior)] = undefined;
	}
	//if (this.behaviorLock == behavior) {
	//	this.behaviorLock = undefined;
	//}

	for (var i = 0; i < this.children.length; i++) {
		this.children[i].removeBehavior(behavior);
	}
}

ActorBlock.prototype.addConstraint = function (constraint, vars, propagateToChildren) {
	if (propagateToChildren == true) {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].addConstraint(constraint, extend(vars,{}));
		}
	}
	else {
		if (this.constraints.indexOf(constraint) == -1) {
			this.constraints.push(constraint);
			if (vars != undefined) {
				this.constraintVars[getFunctionName(constraint)] = vars;
			}
		}
	}
}

ActorBlock.prototype.addMouseOverBehavior = function (behavior, vars, propagateToChildren) {
	var that = this;
	if (!this.isSubscribedToMouseMove) {
		this.isSubscribedToMouseMove = true;
		CANVASMANAGER.mouseMoveEvent.subscribe(function(e) { 
			if (that.x > 0 && that.y > 0) {
				if (e.x > that.x - that.width/2 && e.x < that.x + that.width/2 &&
					e.y > that.y - that.height/2 && e.y < that.y + that.height/2) {
					for (var i = 0; i < that.mouseOverBehaviors.length; i++) {
						that.mouseOverBehaviors[i](that);
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseOverBehaviors.length; i++) {
					that.mouseOverBehaviors[i](that);
				}
			}
		});
	}

	if (this.mouseOverBehaviors.indexOf(behavior) == -1) {
		this.mouseOverBehaviors.push(behavior);
	}
}

ActorBlock.prototype.addMouseClickBehavior = function (behavior, vars, propagateToChildren) {
	if (this.mouseClickBehaviors.indexOf(behavior) == -1) {
		this.mouseClickBehaviors.push(behavior);
	}
}

ActorBlock.prototype.addMouseClickBehavior = function (behavior, vars, propagateToChildren) {
	var that = this;
	if (!this.isSubscribedToMouseClick) {
		this.isSubscribedToMouseClick = true;
		CANVASMANAGER.mouseClickEvent.subscribe(function(e) { 
			if (that.x > 0 && that.y > 0) {
				if (e.x > that.x - that.width/2 && e.x < that.x + that.width/2 &&
					e.y > that.y - that.height/2 && e.y < that.y + that.height/2) {
					for (var i = 0; i < that.mouseClickBehaviors.length; i++) {
						that.mouseClickBehaviors[i](that);
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseClickBehaviors.length; i++) {
					that.mouseClickBehaviors[i](that);
				}
			}
		});
	}

	if (this.mouseClickBehaviors.indexOf(behavior) == -1) {
		this.mouseClickBehaviors.push(behavior);
	}
}

ActorBlock.prototype.addMouseDownBehavior = function (behavior, vars, propagateToChildren) {
	if (this.mouseDownBehaviors.indexOf(behavior) == -1) {
		this.mouseDownBehaviors.push(behavior);
	}
}

ActorBlock.prototype.addMouseDownBehavior = function (behavior, vars, propagateToChildren) {
	var that = this;
	if (!this.isSubscribedToMouseDown) {
		this.isSubscribedToMouseDown = true;
		CANVASMANAGER.mouseDownEvent.subscribe(function(e) { 
			if (that.x > 0 && that.y > 0) {
				if (e.x > that.x - that.width/2 && e.x < that.x + that.width/2 &&
					e.y > that.y - that.height/2 && e.y < that.y + that.height/2) {
					for (var i = 0; i < that.mouseDownBehaviors.length; i++) {
						that.mouseDownBehaviors[i](that);
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseDownBehaviors.length; i++) {
					that.mouseDownBehaviors[i](that);
				}
			}
		});
	}

	if (this.mouseDownBehaviors.indexOf(behavior) == -1) {
		this.mouseDownBehaviors.push(behavior);
	}
}

ActorBlock.prototype.addMouseUpBehavior = function (behavior, vars, propagateToChildren) {
	if (this.mouseUpBehaviors.indexOf(behavior) == -1) {
		this.mouseUpBehaviors.push(behavior);
	}
}

ActorBlock.prototype.addMouseUpBehavior = function (behavior, vars, propagateToChildren) {
	var that = this;
	if (!this.isSubscribedToMouseUp) {
		this.isSubscribedToMouseUp = true;
		CANVASMANAGER.mouseUpEvent.subscribe(function(e) { 
			if (that.x > 0 && that.y > 0) {
				if (e.x > that.x - that.width/2 && e.x < that.x + that.width/2 &&
					e.y > that.y - that.height/2 && e.y < that.y + that.height/2) {
					for (var i = 0; i < that.mouseUpBehaviors.length; i++) {
						that.mouseUpBehaviors[i](that);
					}
				}
			}
			else {
				for (var i = 0; i < that.mouseUpBehaviors.length; i++) {
					that.mouseUpBehaviors[i](that);
				}
			}
		});
	}

	if (this.mouseUpBehaviors.indexOf(behavior) == -1) {
		this.mouseUpBehaviors.push(behavior);
	}
}