

var getFunctionName = function(functionObject) {
	var functionString = String(functionObject);
	var firstIndex = functionString.indexOf(' ') + 1;
	var lastIndex = functionString.indexOf('(');

	return functionString.substring(firstIndex, lastIndex);
}

var trace = function(string) {
	console.log(string);
}

var copyArray = function(src, dest) {
	for (var i = 0; i < src.length; i++) {
		dest[i] = src[i];
	}
}

var extend = function(srcObj, destObj, recurseDown) {
	for (var prop in srcObj) {
		destObj[prop] = srcObj[prop];
	}
}