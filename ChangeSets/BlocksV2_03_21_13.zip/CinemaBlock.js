var CinemaBlock = function() {
	LOG.write("CinemaBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);

	this.movieFrameAliases = new Object();

	for (var i = 0; i < arguments.length; i += 2) {
		this.movieFrameAliases[arguments[i]] = arguments[i+1];
	}

	this.movieFrameData = new Object();
	this.movieFrames = new Object();

	this.isPlaying = true;
	if (arguments[0] == undefined) {
		this.currentMovie = "";
	}
	else {
		this.currentMovie = arguments[0];
	}
	
	this.currentFrameIndex = -1;
}

CinemaBlock.prototype = new ActorBlock();

CinemaBlock.prototype.recordMemory = function() {
	var memory = ActorBlock.prototype.recordMemory.call(this);

	memory.currentMovie = this.currentMovie;
	memory.currentFrameIndex = this.currentFrameIndex;

	return memory;
}

CinemaBlock.prototype.changeMemoryIntoReality = function(memory) {
	ActorBlock.prototype.changeMemoryIntoReality.call(this,memory);
	this.currentMovie = memory.currentMovie;
	this.currentFrameIndex = memory.currentFrameIndex;
}

CinemaBlock.prototype.hasChangedFromLatestMemory = function() {
	var memory = this.getLatestMemory();
	if (memory == null) {
		return false;
	}
	else {
		return ActorBlock.prototype.hasChangedFromLatestMemory.call(this) || !(memory.currentMovie == this.currentMovie && memory.currentFrameIndex == this.currentFrameIndex);
	}
}

CinemaBlock.prototype.setNowPlaying = function(movieName) {
	var validMovieName = false;
	for (var existingMovieName in this.movieFrameAliases) {
		if (existingMovieName == movieName) {
			validMovieName = true;
		}
	}
	for (var existingMovieName in this.movieFrameData) {
		if (existingMovieName == movieName) {
			validMovieName = true;
		}
	}

	if (validMovieName) {
		this.currentMovie = movieName;
		this.currentFrameIndex = -1;
	}
	else {
		LOG.write("CinemaBlock with identity " + this.identity + " has no Movie named: " + movieName, LOG.WARN);
	}
	
}

CinemaBlock.prototype.createFrameData = function() {
	for (var movieName in this.movieFrameAliases) {
		var imgDataArray = CANVASMANAGER.getImageAssetData(this.movieFrameAliases[movieName]);
		var imgDataArrayCopy = new Array();

		for (var i = 0; i < imgDataArray.length; i++) {
			var copy = CANVASMANAGER.workingCanvasFrame.context.createImageData(imgDataArray[i].width, imgDataArray[i].height);
			copy.data.set(imgDataArray[i].data);
			imgDataArrayCopy[i] = copy;
		}

		this.movieFrameData[movieName] = imgDataArrayCopy;
	}
}

CinemaBlock.prototype.setFrameData = function(movieName, imgDataArray) {
	this.movieFrameData[movieName] = imgDataArray;
	if (this.currentMovie == "") {
		this.currentMovie = movieName;
	}
}

CinemaBlock.prototype.updateFrames = function() {
	//this.frames.splice(0,this.frames.length);
	for (var movieName in this.movieFrameData) {
		for (var i = 0; i < this.movieFrameData[movieName].length; i++) {
			CANVASMANAGER.workingCanvasFrame.resize(this.movieFrameData[movieName][i].width,this.movieFrameData[movieName][i].height,-1);
			CANVASMANAGER.workingCanvasFrame.context.clearRect(0,0,this.movieFrameData[movieName][i].width,this.movieFrameData[movieName][i].height);
			CANVASMANAGER.workingCanvasFrame.context.putImageData(this.movieFrameData[movieName][i],0,0);
			//var workingImage = new Image();
			//workingImage.src = CANVASMANAGER.workingCanvasFrame.canvas.toDataURL();
			//this.frames[i] = workingImage;
			if (this.movieFrames[movieName][i] == null) {
				this.movieFrames[movieName][i] = new Image();
			}
			this.movieFrames[movieName][i].src = CANVASMANAGER.workingCanvasFrame.canvas.toDataURL();
		}
	}
}

CinemaBlock.prototype.shatter = function(newBlockSize) {
	var orphanage = new Array();

	for (var movieName in this.movieFrameData) {
		if (this.movieFrameData[movieName].length == 0) {
			this.createFrameData();
			LOG.write("MovieFrameData not present; creating MovieFrameData:", LOG.INFO);
			LOG.writeObject(this.movieFrameData, LOG.INFO);
		}
		
		var splitImgDataArrays = new Array();
		var blockClusterPositions = new Array();

		for (var k = 0; k < this.movieFrameData[movieName].length; k++) {
			var blockIndex = 0;
			CANVASMANAGER.workingCanvasFrame.resize(this.movieFrameData[movieName][k].width,this.movieFrameData[movieName][k].height,-1);
			CANVASMANAGER.workingCanvasFrame.context.clearRect(0,0,this.movieFrameData[movieName][k].width,this.movieFrameData[movieName][k].height);
			CANVASMANAGER.workingCanvasFrame.context.putImageData(this.movieFrameData[movieName][k],0,0);

			for (var i = 0; i < this.movieFrameData[movieName][k].width; i += newBlockSize) {
				for (var j = 0; j < this.movieFrameData[movieName][k].height; j += newBlockSize) {
					if (blockClusterPositions[blockIndex] == undefined) {
						blockClusterPositions[blockIndex] = {"x":i - this.movieFrameData[movieName][k].width/2, "y":j - this.movieFrameData[movieName][k].height/2}
						//blockClusterPositions[blockIndex] = createPoint(i,j);
					}

					var newImgData = CANVASMANAGER.workingCanvasFrame.context.getImageData(i,j,newBlockSize,newBlockSize);
					if (splitImgDataArrays[blockIndex] == undefined) {
						splitImgDataArrays[blockIndex] = new Array(this.movieFrameData[movieName].length)
					}

					splitImgDataArrays[blockIndex][k] = newImgData;
					
					blockIndex++;
				}
			}
		}

		for (var i = 0; i < splitImgDataArrays.length; i++) {
			if (orphanage[i] == undefined) {
				var newBlock = new CinemaBlock();
				newBlock.setFrameData(movieName, splitImgDataArrays[i]);
				//newBlock.updateFrames();

				newBlock.x = blockClusterPositions[i].x;
				newBlock.y = blockClusterPositions[i].y;
				newBlock.z = this.z;

				newBlock.homeX = blockClusterPositions[i].x;
				newBlock.homeY = blockClusterPositions[i].y;
				newBlock.homeZ = this.z;
				
				//this.adoptChild(newBlock);
			}
			else {
				orphanage[i].setFrameData(movieName, splitImgDataArrays[i]);
			}
		}
	}
	
	for (var i = 0; i < orphanage.length; i++) {
		orphanage[i].updateFrames();
		this.adoptChild(orphanage[i]);
	}
}

CinemaBlock.prototype.getCurrentFrame = function() {
	if (this.currentFrameIndex >= 0) {
		if (this.movieFrames[this.currentMovie] != null && this.movieFrames[this.currentMovie][this.currentFrameIndex] != null) {
			return this.movieFrames[this.currentMovie][this.currentFrameIndex];
		}
		else {
			return CANVASMANAGER.getSingleImageAsset(this.movieFrameAliases[this.currentMovie][this.currentFrameIndex]);
		}
	}
	else {
		return null;
	}
}

CinemaBlock.prototype.undraw = function(dest) {
	if (this.children.length == 0) {
		if (this.currentMovie != null && (this.movieFrameAliases[this.currentMovie].length > 0 || this.movieFrames[this.currentMovie].length > 0)) {
			var drawx = 0;
			var drawy = 0;
			try {
				if (this.visible && this.z >= 0) {
					var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
					var zratio = 1
					if (this.z > 0) {
						zratio = 1 / (this.z / zscale);
					} 

					drawx = Math.round(-this.width / 2 + zratio*this.x);
					drawy = Math.round(-this.height / 2 + zratio*this.y);

					dest.save();
					dest.translate(drawx + this.width/2 - 1,drawy+this.height/2 - 1);
					dest.scale(zratio*this.scaleX,zratio*this.scaleY);
					dest.rotate(this.rotation*Math.PI/180);

					dest.clearRect(-this.width/2, -this.height/2, this.width + 2/(zratio*this.scaleX), this.height + 2/(zratio*this.scaleY));

					dest.restore();
				}
			}
			catch (err) {
				LOG.write("error in CinemaBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
				LOG.writeBlock(this, LOG.ERROR);
				LOG.writeObject(err, LOG.ERROR);
				debugger;
			}
		}
	}
	else {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].undraw(dest);
		}
	}
}

CinemaBlock.prototype.update = function(dest) {
	if (this.isPlaying) {
		this.currentFrameIndex++;

		if ((this.movieFrameAliases[this.currentMovie] != null && this.movieFrameAliases[this.currentMovie].length > 0 && this.currentFrameIndex >= this.movieFrameAliases[this.currentMovie].length) ||
			 (this.movieFrameData[this.currentMovie] != null && this.movieFrameData[this.currentMovie].length > 0 && this.currentFrameIndex >= this.movieFrameData[this.currentMovie].length)) {
			 this.currentFrameIndex = 0;
		}
	}

	ActorBlock.prototype.update.call(this);

	var currentFrame = this.getCurrentFrame();

	if (currentFrame != null) {
		this.width = currentFrame.width;
		this.height = currentFrame.height;
	}
}

CinemaBlock.prototype.draw = function(dest) {
	if (this.currentMovie != null && (this.movieFrameAliases[this.currentMovie].length > 0 || this.movieFrames[this.currentMovie].length > 0)) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
				var zratio = 1;
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 

				drawx = Math.round(-this.width / 2 + zratio*this.x);
				drawy = Math.round(-this.height / 2 + zratio*this.y);

				dest.save();
				dest.translate(drawx + this.width/2,drawy+this.height/2);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);
				
				var currentFrame = this.getCurrentFrame();
				if (currentFrame != null) {	
					dest.drawImage(currentFrame,-this.width/2,-this.height/2);
				}

				this.children.sort(function(a,b) { return b.z - a.z });
				for (var i = 0; i < this.children.length; i++) {
					this.children[i].draw(dest);
				}

				dest.restore();
			}
		}
		catch (err) {
			LOG.write("error in CinemaBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
}

CinemaBlock.prototype.setColorFilter = function(red,green,blue,alpha) {
	this.createFrameData();
	for (var movieName in this.movieFrameData) {
		for (var i = 0; i < this.movieFrameData[movieName].length; i++) {
			for (var j = 0; j < this.movieFrameData[movieName][i].data.length; j++) {
				var color = j % 4;
				var colorValue = this.movieFrameData[movieName][i].data[j];
				switch(color) {
					case 0:
					if (red != undefined) {
						this.movieFrameData[movieName][i].data[j] = red;
					}
					break;

					case 1:
					if (green != undefined) {
						this.movieFrameData[movieName][i].data[j] = green;
					}
					break;

					case 2:
					if (blue != undefined) {
						this.movieFrameData[movieName][i].data[j] = blue;
					}
					break;

					case 3:
					if (alpha != undefined) {
						this.movieFrameData[movieName][i].data[j] = alpha;
					}
					break;
				}

			}
		}
	}
	
	this.updateFrames();
}