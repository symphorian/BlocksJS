var CanvasFrame = function(width, height, zindex) {
	LOG.write("CanvasFrame constructor called", LOG.VERBOSE);
	this.canvas = document.createElement("canvas");
	this.canvas.setAttribute("style", "position: absolute; left: 0px; top: 0px; z-index:" + zindex)
	/*this.canvas.setAttribute("position", "absolute");
	this.canvas.setAttribute("left", "0px");
	this.canvas.setAttribute("top", "0px");*/
	this.canvas.setAttribute("width", width);
	this.canvas.setAttribute("height", height);
	this.canvas.setAttribute("z-index", zindex);
	this.context = this.canvas.getContext("2d");

	this.masterBlock = new ActorBlock();
	this.masterBlock.x = width/2;
	this.masterBlock.y = height/2;
	this.masterBlock.identity = "MasterBlock" + zindex;
}

CanvasFrame.prototype.adoptBlockChild = function(block) {
	this.masterBlock.adoptChild(block);
}

CanvasFrame.prototype.addBehavior = function(behavior, vars, propagateToChildren) {
	this.masterBlock.addBehavior(behavior, vars, propagateToChildren);
}

CanvasFrame.prototype.addMouseOverReaction = function(reaction, vars, propagateToChildren) {
	this.masterBlock.addMouseOverReaction(reaction, vars, propagateToChildren);
}

CanvasFrame.prototype.addMouseClickReaction = function(reaction, vars, propagateToChildren) {
	this.masterBlock.addMouseClickReaction(reaction, vars, propagateToChildren);
}

CanvasFrame.prototype.addMouseDownReaction = function(reaction, vars, propagateToChildren) {
	this.masterBlock.addMouseDownReaction(reaction, vars, propagateToChildren);
}

CanvasFrame.prototype.addMouseUpReaction = function(reaction, vars, propagateToChildren) {
	this.masterBlock.addMouseUpReaction(reaction, vars, propagateToChildren);
}

CanvasFrame.prototype.addAnyKeyDownReaction = function(reaction, vars, propagateToChildren) {
	this.masterBlock.addAnyKeyDownReaction(reaction, vars, propagateToChildren);
}

CanvasFrame.prototype.addAnyKeyUpReaction = function(reaction, vars, propagateToChildren) {
	this.masterBlock.addAnyKeyUpReaction(reaction, vars, propagateToChildren);
}

CanvasFrame.prototype.addKeyDownReaction = function(keyCode, reaction, vars, propagateToChildren) {
	this.masterBlock.addKeyDownReaction(keyCode, reaction, vars, propagateToChildren);
}

CanvasFrame.prototype.addKeyUpReaction = function(keyCode, reaction, vars, propagateToChildren) {
	this.masterBlock.addKeyUpReaction(keyCode, reaction, vars, propagateToChildren);
}

CanvasFrame.prototype.addKeyCombinationReaction = function(keyCodes, reaction, vars, propagateToChildren) {
	this.masterBlock.addKeyCombinationReaction(keyCodes, reaction, vars, propagateToChildren);
}

CanvasFrame.prototype.resize = function(width, height, zindex) {
	if (width != this.width || height != this.height) {
		this.canvas.setAttribute("width", width);
		this.canvas.setAttribute("height", height);
		this.canvas.setAttribute("style", "position: absolute; left: 0px; top: 0px; z-index:" + zindex)
		
		this.context = this.canvas.getContext("2d");
		this.masterBlock.draw(this.context);
	}
}

CanvasFrame.prototype.refresh = function() {
	this.masterBlock.undraw(this.context);
	this.masterBlock.update(this.context);
	this.masterBlock.draw(this.context);
}