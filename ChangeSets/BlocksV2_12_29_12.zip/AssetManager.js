var AssetManager = function() {
	LOG.write("AssetManager constructor called", LOG.VERBOSE);

	this.xmlRequest = new XMLHttpRequest();
	this.imageAssets = new Object();

	this.assetsFound = 0;
	this.assetsLoaded = 0;

	this.assetsLoadedEvent = new Event();

}

AssetManager.prototype.onAssetLoaded = function () {
	this.assetsLoaded = this.assetsLoaded + 1;
	LOG.write("assetsFound: " + this.assetsFound + " assetsLoaded: " + this.assetsLoaded, LOG.VERBOSE);
	if (this.assetsFound == this.assetsLoaded) {
		LOG.writeObject(this.imageAssets, LOG.VERBOSE);
		this.assetsLoadedEvent.fireEvent();
	}
}

AssetManager.prototype.loadImageAsset = function(imgFilename, imgAlias) {
	var image = new Image();
	image.onload = this.assetsLoadedEvent.fireEvent;
	//image.src =
}

AssetManager.prototype.loadImageAssetXML = function(xmlFilename) {
	var that = this;
	this.xmlRequest.open("GET", xmlFilename, false);
	this.xmlRequest.send();
	var parser = new DOMParser();
	var xmlDoc = parser.parseFromString(this.xmlRequest.response, "text/xml");
	var images = xmlDoc.getElementsByTagName("Image");
	this.assetsFound = images.length;
	for (var i = 0; i < images.length; i++) {
		var image = new Image();
		var filename = images[i].getElementsByTagName("Filename")[0].childNodes[0].nodeValue;
		var alias = images[i].getElementsByTagName("Alias")[0].childNodes[0].nodeValue;
		
		if (alias == null) {
			alias = filename;
		}

		this.imageAssets[alias] = new Object();
		this.imageAssets[alias].img = new Image();
		this.imageAssets[alias].img.name = alias;
		this.imageAssets[alias].img.onload = function() {
			LOG.write("Image onload reached with alias: " + this.name + " Width:" + that.imageAssets[this.name].img.width + " Height:" + that.imageAssets[this.name].img.height, LOG.INFO);

			CANVASMANAGER.workingCanvasFrame.resize(CANVASMANAGER.width,CANVASMANAGER.height,-1);
			
			var clipx = 0;
			var clipy = 0;
			var clipw = that.imageAssets[this.name].img.width;
			var cliph = that.imageAssets[this.name].img.height;

			if (CANVASMANAGER.width < that.imageAssets[this.name].img.width || CANVASMANAGER.height < that.imageAssets[this.name].img.height) {
				clipx = that.imageAssets[this.name].img.width / 2 - CANVASMANAGER.width / 2;
				clipy = that.imageAssets[this.name].img.height / 2 - CANVASMANAGER.height / 2;
				clipw = CANVASMANAGER.width;
				cliph = CANVASMANAGER.height;
				//that.imageAssets[this.name].imgdata = CANVASMANAGER.workingCanvasFrame.context.getImageData(centerx,centery,CANVASMANAGER.width,CANVASMANAGER.height);
			}

			CANVASMANAGER.workingCanvasFrame.context.clearRect(0,0,clipw,cliph);
			CANVASMANAGER.workingCanvasFrame.context.drawImage(that.imageAssets[this.name].img,clipx,clipy,clipw,cliph,0,0,clipw,cliph);

			that.imageAssets[this.name].imgdata = CANVASMANAGER.workingCanvasFrame.context.getImageData(0,0,that.imageAssets[this.name].img.width,that.imageAssets[this.name].img.height);			
			that.onAssetLoaded();
		}
		this.imageAssets[alias].img.src = filename;

		LOG.write("filename: " + filename + " alias: " + alias, LOG.VERBOSE);
	}
}