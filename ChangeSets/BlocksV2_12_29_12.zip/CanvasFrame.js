var CanvasFrame = function(width, height, zindex) {
	LOG.write("CanvasFrame constructor called", LOG.VERBOSE);
	this.canvas = document.createElement("canvas");
	this.canvas.setAttribute("style", "position: absolute; left: 0px; top: 0px; z-index:" + zindex)
	/*this.canvas.setAttribute("position", "absolute");
	this.canvas.setAttribute("left", "0px");
	this.canvas.setAttribute("top", "0px");*/
	this.canvas.setAttribute("width", width);
	this.canvas.setAttribute("height", height);
	this.canvas.setAttribute("z-index", zindex);
	this.context = this.canvas.getContext("2d");

	this.masterBlock = new ActorBlock();
}

CanvasFrame.prototype.adoptBlockChild = function(block) {
	this.masterBlock.adoptChild(block);
}

CanvasFrame.prototype.addBehavior = function(behavior, vars, propagateToChildren) {
	this.masterBlock.addBehavior(behavior, vars, propagateToChildren);
}

CanvasFrame.prototype.addMouseOverBehavior = function(behavior, vars, propagateToChildren) {
	this.masterBlock.addMouseOverBehavior(behavior, vars, propagateToChildren);
}

CanvasFrame.prototype.addMouseClickBehavior = function(behavior, vars, propagateToChildren) {
	this.masterBlock.addMouseClickBehavior(behavior, vars, propagateToChildren);
}

CanvasFrame.prototype.addMouseDownBehavior = function(behavior, vars, propagateToChildren) {
	this.masterBlock.addMouseDownBehavior(behavior, vars, propagateToChildren);
}

CanvasFrame.prototype.addMouseUpBehavior = function(behavior, vars, propagateToChildren) {
	this.masterBlock.addMouseUpBehavior(behavior, vars, propagateToChildren);
}

CanvasFrame.prototype.resize = function(width, height, zindex) {
	if (width != this.width || height != this.height) {
		this.canvas.setAttribute("width", width);
		this.canvas.setAttribute("height", height);
		this.canvas.setAttribute("style", "position: absolute; left: 0px; top: 0px; z-index:" + zindex)
		
		this.context = this.canvas.getContext("2d");
		this.masterBlock.draw(this.context);
	}
}

CanvasFrame.prototype.refresh = function() {
	this.masterBlock.undraw(this.context);
	this.masterBlock.update(this.context);
	this.masterBlock.draw(this.context);
}