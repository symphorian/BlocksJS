var KeyboardEvent = function() {
	Event.call(this);

	this.lastKeyPressed = 0;
	this.lastKeyReleased = 0;
 }

KeyboardEvent.prototype = new Event();

KeyboardEvent.prototype.keysDown = new Array();

KeyboardEvent.prototype.fireEvent = function(key, isDown) {
	var index = this.keysDown.indexOf(key);
	if (isPressed) {
		this.lastKeyPressed = key;
		if (index == -1) {
			this.keysDown.push(key);
		}
	}
	else {
		this.lastKeyReleased = key;
		if (index > 0) {
			this.keysDown.splice(index, 1);
		}
	}

	for (var i = 0; i < this.subscribedFunctions.length; i++) {
		this.subscribedFunctions[i]();
	}

}