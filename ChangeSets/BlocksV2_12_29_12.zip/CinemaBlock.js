var CinemaBlock = function(imgDataArray) {
	LOG.write("CinemaBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);

	var imgDataArrayCopy = new Array();

	for (var i = 0; i < imgDataArray.length; i++) {
		var copy = canvasManager.workingCanvasFrame.context.createImageData(imgDataArray[i].width, imgDataArray[i].height);
		copy.data.set(imgDataArray[i].data);
		imgDataArrayCopy[i] = copy;
	}

	this.originalImageDataArray = imgDataArrayCopy;
	this.workingImageDataArray = imgDataArrayCopy;

	this.width = this.originalImageDataArray[0].width;
	this.height = this.originalImageDataArray[0].height;

	this.isPlaying = true;
	this.currentFrame = -1;

	this.children = new Array();
}

MovieBlock.prototype = new ActorBlock();

MovieBlock.prototype.undraw = function(dest) {
	if (this.workingImageDataArray != undefined) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible) {
				drawx = Math.round(canvasManager.width / 2 - this.width / 2 + this.x);
				drawy = Math.round(canvasManager.height / 2 - this.height / 2 + this.y);
				dest.clearRect(drawx, drawy, this.width, this.height);
			}
		}
		catch (err) {
			LOG.write("error in CinemaBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
	else {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].draw(dest);
		}
	}
}

MovieBlock.prototype.update = function(dest) {
	ActorBlock.prototype.update.call(this);

	if (this.isPlaying && ++this.currentFrame >= this.workingImageDataArray.length) {
		this.currentFrame = 0;
	}
}

MovieBlock.prototype.draw = function(dest) {
	if (this.workingImageDataArray != undefined) {

		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible) {
				drawx = Math.round(canvasManager.width / 2 - this.width / 2 + this.x);
				drawy = Math.round(canvasManager.height / 2 - this.height / 2 + this.y);
				dest.putImageData(this.workingImageDataArray[this.currentFrame], drawx, drawy);
			}
		}
		catch (err) {
			LOG.write("error in CinemaBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
			LOG.writeBlock(this, LOG.ERROR);
			LOG.writeObject(err, LOG.ERROR);
			debugger;
		}
	}
	else {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].draw(dest);
		}
	}
}

