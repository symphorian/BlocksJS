var MovieBlock = function() {
	LOG.write("MovieBlock constructor called", LOG.VERBOSE);
	ActorBlock.call(this);

	this.frameAliases = new Array();

	for (var i = 0; i < arguments.length; i++) {
		this.frameAliases[i] = arguments[i];
	}

	//var imgDataArrayCopy = new Array();

	//for (var i = 0; i < imgDataArray.length; i++) {
	//	var copy = CANVASMANAGER.workingCanvasFrame.context.createImageData(imgDataArray[i].width, imgDataArray[i].height);
	//	copy.data.set(imgDataArray[i].data);
	//	imgDataArrayCopy[i] = copy;
	//}

	//this.originalImageDataArray = imgDataArray;
	this.frameData = new Array();
	this.frames = new Array();

	this.isPlaying = true;
	this.currentFrameIndex = -1;
}

MovieBlock.prototype = new ActorBlock();

MovieBlock.prototype.createFrameData = function() {
	var imgDataArray = CANVASMANAGER.getImageAssetData(this.frameAliases);
	var imgDataArrayCopy = new Array();

	for (var i = 0; i < imgDataArray.length; i++) {
		var copy = CANVASMANAGER.workingCanvasFrame.context.createImageData(imgDataArray[i].width, imgDataArray[i].height);
		copy.data.set(imgDataArray[i].data);
		imgDataArrayCopy[i] = copy;
	}

	this.frameData = imgDataArrayCopy;
}

MovieBlock.prototype.setFrameData = function(imgDataArray) {
	this.frameData = imgDataArray;
}

MovieBlock.prototype.updateFrames = function() {
	//this.frames.splice(0,this.frames.length);
	for (var i = 0; i < this.frameData.length; i++) {
		CANVASMANAGER.workingCanvasFrame.resize(this.frameData[i].width,this.frameData[i].height,-1);
		CANVASMANAGER.workingCanvasFrame.context.clearRect(0,0,this.frameData[i].width,this.frameData[i].height);
		CANVASMANAGER.workingCanvasFrame.context.putImageData(this.frameData[i],0,0);
		//var workingImage = new Image();
		//workingImage.src = CANVASMANAGER.workingCanvasFrame.canvas.toDataURL();
		//this.frames[i] = workingImage;
		if (this.frames[i] == null) {
			this.frames[i] = new Image();
		}
		this.frames[i].src = CANVASMANAGER.workingCanvasFrame.canvas.toDataURL();
	}
}

MovieBlock.prototype.shatter = function(newBlockSize) {
	if (this.frameData.length == 0) {
		this.createFrameData();
		LOG.write("FrameData not present; creating FrameData:", LOG.INFO);
		LOG.writeObject(this.frameData, LOG.INFO);
	}
	
	var splitImgDataArrays = new Array();
	var blockClusterPositions = new Array();
	//var emptyBlockDataArrays = new Array();

	for (var k = 0; k < this.frameData.length; k++) {
		var blockIndex = 0;
		CANVASMANAGER.workingCanvasFrame.resize(this.frameData[k].width,this.frameData[k].height,-1);
		CANVASMANAGER.workingCanvasFrame.context.clearRect(0,0,this.frameData[k].width,this.frameData[k].height);
		CANVASMANAGER.workingCanvasFrame.context.putImageData(this.frameData[k],0,0);
		//GLOBALS.workctx.putImageData(imgDataArrayCopy[k],0,0);

		for (var i = 0; i < this.frameData[k].width; i += newBlockSize) {
			for (var j = 0; j < this.frameData[k].height; j += newBlockSize) {
				if (blockClusterPositions[blockIndex] == undefined) {
					blockClusterPositions[blockIndex] = {"x":i - this.frameData[k].width/2, "y":j - this.frameData[k].height/2}
					//blockClusterPositions[blockIndex] = createPoint(i,j);
				}

				var newImgData = CANVASMANAGER.workingCanvasFrame.context.getImageData(i,j,newBlockSize,newBlockSize);
				if (splitImgDataArrays[blockIndex] == undefined) {
					splitImgDataArrays[blockIndex] = new Array(this.frameData.length)
				}

				splitImgDataArrays[blockIndex][k] = newImgData;

				/*if (emptyBlockDataArrays[blockIndex] == undefined) {
					emptyBlockDataArrays[blockIndex] = new Array(frameData.length);
				}

				var emptyData = true;
				for (var l = 0; l < newImgData.data.length; l++) {
					if (newImgData.data[l] != 255) {
						emptyData = false;
						break;
					}
				}

				emptyBlockDataArrays[blockIndex][k] = emptyData;*/
				
				blockIndex++;
			}
		}
	}

	for (var i = 0; i < splitImgDataArrays.length; i++) {
		/*var allEmptyData = true;
		for (var j = 0; j < emptyBlockDataArrays[i].length; j++) {
			if (!emptyBlockDataArrays[i][j]) {
				allEmptyData = false;
			}
		}
		if (!allEmptyData) {*/
			//var newblock = createBlock(block, splitImgDataArrays[i],block.blocksize/2,block.blocksize/2);
			//newblock.setPos(blockClusterPositions[i].x,blockClusterPositions[i].y);
			//newblock.setClusterPos(blockClusterPositions[i].x,blockClusterPositions[i].y);
			var newBlock = new MovieBlock();
			newBlock.setFrameData(splitImgDataArrays[i]);
			newBlock.updateFrames();

			newBlock.x = blockClusterPositions[i].x;
			newBlock.y = blockClusterPositions[i].y;
			newBlock.z = this.z;

			newBlock.homeX = blockClusterPositions[i].x;
			newBlock.homeY = blockClusterPositions[i].y;
			newBlock.homeZ = this.z;
			
			this.adoptChild(newBlock);
		//}
	}
}

MovieBlock.prototype.getCurrentFrame = function() {
	if (this.frames[this.currentFrameIndex] != null) {
		return this.frames[this.currentFrameIndex];
	}
	else {
		return CANVASMANAGER.getSingleImageAsset(this.frameAliases[this.currentFrameIndex]);
	}
}

MovieBlock.prototype.undraw = function(dest) {
	if (this.children.length == 0) {
		if (this.frameAliases.length > 0 || this.frames.length > 0) {
			var drawx = 0;
			var drawy = 0;
			try {
				if (this.visible && this.z >= 0) {
					var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
					var zratio = 1
					if (this.z > 0) {
						zratio = 1 / (this.z / zscale);
					} 

					drawx = Math.round(CANVASMANAGER.width / 2 - this.width / 2 + zratio*this.globalX());
					drawy = Math.round(CANVASMANAGER.height / 2 - this.height / 2 + zratio*this.globalY());

					dest.save();
					dest.translate(drawx + this.width/2,drawy+this.height/2);
					dest.scale(zratio*this.scaleX,zratio*this.scaleY);
					dest.rotate(this.rotation*Math.PI/180);

					dest.clearRect(-this.width/2, -this.height/2, this.width+2, this.height+2);

					dest.restore();
				}
			}
			catch (err) {
				LOG.write("error in MovieBlock.undraw at: " + drawx + " " + drawy, LOG.ERROR);
				LOG.writeBlock(this, LOG.ERROR);
				LOG.writeObject(err, LOG.ERROR);
				debugger;
			}
		}
	}
	else {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].undraw(dest);
		}
	}
}

MovieBlock.prototype.update = function(dest) {
	ActorBlock.prototype.update.call(this);

	this.currentFrameIndex++;

	if (this.isPlaying && 
		((this.frameAliases.length > 0 && this.currentFrameIndex >= this.frameAliases.length) ||
		 (this.frameData.length > 0 && this.currentFrameIndex >= this.frameData.length))) {
		 this.currentFrameIndex = 0;
	}

	var currentFrame = this.getCurrentFrame();

	if (currentFrame != null) {
		this.width = currentFrame.width;
		this.height = currentFrame.height;
	}
}

MovieBlock.prototype.draw = function(dest) {
	if (this.children.length == 0) {
		if (this.frameAliases.length > 0 || this.frames.length > 0) {
			//if (this.frames == null) {
			//	trace("updating Frames");
			//	this.updateFrames();
			//}

			var drawx = 0;
			var drawy = 0;
			try {
				if (this.visible && this.z >= 0) {
					var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2);
					var zratio = 1;
					if (this.z > 0) {
						zratio = 1 / (this.z / zscale);
					} 

					

					//if (CANVASMANAGER.width > this.width && CANVASMANAGER.height > this.height) {
						drawx = Math.round(CANVASMANAGER.width / 2 - this.width / 2 + zratio*this.globalX());
						drawy = Math.round(CANVASMANAGER.height / 2 - this.height / 2 + zratio*this.globalY());
					//}
					//else {
					//	drawx = 0;
					//	drawy = 0;
					//}

					//if (this.identity == "Block20") {
					//	trace("drawX=" + drawx + " drawY=" + drawy);
					//}

					dest.save();
					dest.translate(drawx + this.width/2,drawy+this.height/2);
					dest.scale(zratio*this.scaleX,zratio*this.scaleY);
					dest.rotate(this.rotation*Math.PI/180);
					
					dest.drawImage(this.getCurrentFrame(),-this.width/2,-this.height/2);

					dest.restore();
				}
			}
			catch (err) {
				LOG.write("error in MovieBlock.draw at: " + drawx + " " + drawy, LOG.ERROR);
				LOG.writeBlock(this, LOG.ERROR);
				LOG.writeObject(err, LOG.ERROR);
				debugger;
			}
		}
	}
	else {
		this.children.sort(function(a,b) { return b.z - a.z });
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].draw(dest);
		}
	}
}

MovieBlock.prototype.setColorFilter = function(red,green,blue,alpha) {
	this.createFrameData();
	for (var i = 0; i < this.frameData.length; i++) {
		for (var j = 0; j < this.frameData[i].data.length; j++) {
			var color = j % 4;
			var colorValue = this.frameData[i].data[j];
			switch(color) {
				case 0:
				if (red != undefined) {
					this.frameData[i].data[j] = red;
				}
				break;

				case 1:
				if (green != undefined) {
					this.frameData[i].data[j] = green;
				}
				break;

				case 2:
				if (blue != undefined) {
					this.frameData[i].data[j] = blue;
				}
				break;

				case 3:
				if (alpha != undefined) {
					this.frameData[i].data[j] = alpha;
				}
				break;
			}

		}
	}
	this.updateFrames();
}

MovieBlock.prototype.resetFilters = function() {
	var imgDataArrayCopy = new Array();
	for (var i = 0; i < this.originalImageDataArray.length; i++) {
		var copy = CANVASMANAGER.workingCanvasFrame.context.createImageData(this.originalImageDataArray[i].width, this.originalImageDataArray[i].height);
		copy.data.set(this.originalImageDataArray[i].data);
		imgDataArrayCopy[i] = copy;
	}
	this.frameData = imgDataArrayCopy;
	this.updateFrames();
}