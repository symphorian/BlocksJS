var MouseEvent = function() {
	Event.call(this);

	this.x = 0;
	this.y = 0;
};

MouseEvent.prototype = new Event();

MouseEvent.prototype.fireEvent = function(x,y) {
	this.x = x;
	this.y = y;

	for (var i = 0; i < this.subscribedFunctions.length; i++) {
		this.subscribedFunctions[i](this);
	}
}