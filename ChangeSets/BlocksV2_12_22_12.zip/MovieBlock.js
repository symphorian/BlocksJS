var MovieBlock = function(imgDataArray) {
	trace("MovieBlock constructor called");
	ActorBlock.call(this);

	var imgDataArrayCopy = new Array();

	for (var i = 0; i < imgDataArray.length; i++) {
		var copy = CANVASMANAGER.workingCanvasFrame.context.createImageData(imgDataArray[i].width, imgDataArray[i].height);
		copy.data.set(imgDataArray[i].data);
		imgDataArrayCopy[i] = copy;
	}

	this.originalImageDataArray = imgDataArray;
	this.workingImageDataArray = imgDataArrayCopy;

	this.width = this.workingImageDataArray[0].width;
	this.height = this.workingImageDataArray[0].height;

	this.isPlaying = true;
	this.currentFrame = -1;
}

MovieBlock.prototype = new ActorBlock();

MovieBlock.prototype.updateWorkingImageArray = function() {
	if (this.workingImageArray == null) {
		this.workingImageArray = new Array();
	}
	this.workingImageArray.splice(0,this.workingImageArray.length);
	for (var i = 0; i < this.workingImageDataArray.length; i++) {
		CANVASMANAGER.workingCanvasFrame.resize(this.workingImageDataArray[i].width,this.workingImageDataArray[i].height,-1);
		CANVASMANAGER.workingCanvasFrame.context.clearRect(0,0,this.workingImageDataArray[i].width,this.workingImageDataArray[i].height);
		CANVASMANAGER.workingCanvasFrame.context.putImageData(this.workingImageDataArray[i],0,0);
		var workingImage = new Image();
		workingImage.src = CANVASMANAGER.workingCanvasFrame.canvas.toDataURL();
		this.workingImageArray[i] = workingImage;
	}
}

MovieBlock.prototype.undraw = function(dest) {
	if (this.workingImageDataArray != undefined) {
		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
				var zratio = 1
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 

				drawx = Math.round(CANVASMANAGER.width / 2 - this.width / 2 + zratio*this.x);
				drawy = Math.round(CANVASMANAGER.height / 2 - this.height / 2 + zratio*this.y);

				dest.save();
				dest.translate(drawx + this.width/2,drawy+this.height/2);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);
				dest.translate(-drawx - this.width/2,-drawy - this.height/2);

				dest.clearRect(drawx-1, drawy-1, this.width+2, this.height+2);

				dest.restore();
			}
		}
		catch (err) {
			trace(this);
			trace("error at: " + drawx + " " + drawy);
			trace(err);
			debugger;
		}
	}
	else {
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].undraw(dest);
		}
	}
}

MovieBlock.prototype.update = function(dest) {
	ActorBlock.prototype.update.call(this);

	if (this.isPlaying && ++this.currentFrame >= this.workingImageDataArray.length) {
		this.currentFrame = 0;
	}
}

MovieBlock.prototype.draw = function(dest) {
	if (this.workingImageDataArray != undefined) {
		if (this.workingImageArray == null) {
			trace("updatingWorkingImageArray");
			this.updateWorkingImageArray();
		}

		var drawx = 0;
		var drawy = 0;
		try {
			if (this.visible && this.z >= 0) {
				var zscale = 2*Math.tan(CANVASMANAGER.fov*(Math.PI/180)/2)
				var zratio = 1
				if (this.z > 0) {
					zratio = 1 / (this.z / zscale);
				} 

				if (CANVASMANAGER.width > this.width && CANVASMANAGER.height > this.height) {
					drawx = Math.round(CANVASMANAGER.width / 2 - this.width / 2 + zratio*this.x);
					drawy = Math.round(CANVASMANAGER.height / 2 - this.height / 2 + zratio*this.y);
				}
				else {
					drawx = 0;
					drawy = 0;
				}

				dest.save();
				dest.translate(drawx + this.width/2,drawy+this.height/2);
				dest.scale(zratio*this.scaleX,zratio*this.scaleY);
				dest.rotate(this.rotation*Math.PI/180);
				dest.translate(-drawx - this.width/2,-drawy - this.height/2);
				
				dest.drawImage(this.workingImageArray[this.currentFrame], drawx, drawy);

				dest.restore();
			}
		}
		catch (err) {
			trace(this);
			trace("error at: " + drawx + " " + drawy);
			trace(err);
			debugger;
		}
	}
	else {
		this.children.sort(function(a,b) { return b.z - a.z });
		for (var i = 0; i < this.children.length; i++) {
			this.children[i].draw(dest);
		}
	}
}



MovieBlock.prototype.setColorFilter = function(red,green,blue,alpha) {
	for (var i = 0; i < this.workingImageDataArray.length; i++) {
		for (var j = 0; j < this.workingImageDataArray[i].data.length; j++) {
			var color = j % 4;
			var colorValue = this.workingImageDataArray[i].data[j];
			switch(color) {
				case 0:
				if (red != undefined) {
					this.workingImageDataArray[i].data[j] = red;
				}
				break;

				case 1:
				if (green != undefined) {
					this.workingImageDataArray[i].data[j] = green;
				}
				break;

				case 2:
				if (blue != undefined) {
					this.workingImageDataArray[i].data[j] = blue;
				}
				break;

				case 3:
				if (alpha != undefined) {
					this.workingImageDataArray[i].data[j] = alpha;
				}
				break;
			}

		}
	}
	this.updateWorkingImageArray();
}

MovieBlock.prototype.resetFilters = function() {
	var imgDataArrayCopy = new Array();
	for (var i = 0; i < this.originalImageDataArray.length; i++) {
		var copy = CANVASMANAGER.workingCanvasFrame.context.createImageData(this.originalImageDataArray[i].width, this.originalImageDataArray[i].height);
		copy.data.set(this.originalImageDataArray[i].data);
		imgDataArrayCopy[i] = copy;
	}
	this.workingImageDataArray = imgDataArrayCopy;
	this.updateWorkingImageArray();
}