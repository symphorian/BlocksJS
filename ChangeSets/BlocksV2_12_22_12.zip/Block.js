var Block = function () {
	this.x = 0;
	this.y = 0;
	this.z = 0;

	this.width = 0;
	this.height = 0;

	this.scaleX = 1;
	this.scaleY = 1;

	this.rotation = 0;

	this.visible = true;

	this.parent = null;
	this.children = new Array();
};

Block.prototype.adoptChild = function(childBlock) {
	this.children.push(childBlock);
	childBlock.parent = this;
}

Block.prototype.draw = function(dest) {
	this.children.sort(function(a,b) { return b.z - a.z });
	for (var i = 0; i < this.children.length; i++) {
		this.children[i].draw(dest);
	}
};

Block.prototype.undraw = function(dest) {
	for (var i = 0; i < this.children.length; i++) {
		this.children[i].undraw(dest);
	}
};